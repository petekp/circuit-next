import type { ExecutableStageV2, FlowId, StageId } from '../domain/flow.js';
import type { ReportRef } from '../domain/report.js';
import type { RoutesV2 } from '../domain/route.js';
import type { RunFileRef } from '../domain/run-file.js';
import type { StepId } from '../domain/step.js';

export interface BaseStepV2 {
  readonly id: StepId;
  readonly stageId: StageId;
  readonly title?: string;
  readonly routes: RoutesV2;
  readonly reads?: readonly RunFileRef[];
  readonly writes?: Readonly<Record<string, RunFileRef>>;
}

export interface ComposeStepV2 extends BaseStepV2 {
  readonly kind: 'compose';
  readonly writer: string;
  readonly body?: unknown;
}

export interface VerificationStepV2 extends BaseStepV2 {
  readonly kind: 'verification';
  readonly check: string;
}

export interface CheckpointStepV2 extends BaseStepV2 {
  readonly kind: 'checkpoint';
  readonly choices: readonly string[];
}

export interface RelayStepV2 extends BaseStepV2 {
  readonly kind: 'relay';
  readonly role: string;
  readonly connector?: string;
  readonly prompt?: string;
  readonly report?: ReportRef;
}

export interface SubRunStepV2 extends BaseStepV2 {
  readonly kind: 'sub-run';
  readonly flowRef: FlowId;
  readonly goal: string;
}

export interface FanoutStepV2 extends BaseStepV2 {
  readonly kind: 'fanout';
  readonly branches: unknown;
  readonly join: unknown;
}

export type ExecutableStepV2 =
  | ComposeStepV2
  | VerificationStepV2
  | CheckpointStepV2
  | RelayStepV2
  | SubRunStepV2
  | FanoutStepV2;

export interface ExecutableFlowV2 {
  readonly id: FlowId;
  readonly version: string;
  readonly entry: StepId;
  readonly stages: readonly ExecutableStageV2[];
  readonly steps: readonly ExecutableStepV2[];
  readonly metadata?: Record<string, unknown>;
}
