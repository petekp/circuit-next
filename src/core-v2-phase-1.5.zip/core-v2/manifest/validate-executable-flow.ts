import { type RouteTarget, TERMINAL_TARGETS } from '../domain/route.js';
import type { StepId } from '../domain/step.js';
import type { ExecutableFlowV2, ExecutableStepV2 } from './executable-flow.js';

export interface ExecutableFlowValidationV2 {
  readonly ok: boolean;
  readonly issues: readonly string[];
}

function requiredRoutesForStep(step: ExecutableStepV2): readonly string[] {
  if (step.kind === 'verification') return ['pass', 'fail'];
  if (step.kind === 'checkpoint') return step.choices;
  return ['pass'];
}

function isRouteTarget(value: unknown): value is RouteTarget {
  if (typeof value !== 'object' || value === null) return false;
  const target = value as {
    readonly kind?: unknown;
    readonly stepId?: unknown;
    readonly target?: unknown;
  };
  if (target.kind === 'step') return typeof target.stepId === 'string' && target.stepId.length > 0;
  if (target.kind === 'terminal') {
    return typeof target.target === 'string' && TERMINAL_TARGETS.includes(target.target as never);
  }
  return false;
}

export function validateExecutableFlowV2(flow: ExecutableFlowV2): ExecutableFlowValidationV2 {
  const issues: string[] = [];
  const stepIds = new Set<StepId>();
  const duplicateStepIds = new Set<StepId>();
  const stageIds = new Set<string>();
  const duplicateStageIds = new Set<string>();

  for (const step of flow.steps) {
    if (stepIds.has(step.id)) duplicateStepIds.add(step.id);
    stepIds.add(step.id);
  }

  for (const stage of flow.stages) {
    if (stageIds.has(stage.id)) duplicateStageIds.add(stage.id);
    stageIds.add(stage.id);
  }

  for (const stepId of duplicateStepIds) issues.push(`duplicate step id: ${stepId}`);
  for (const stageId of duplicateStageIds) issues.push(`duplicate stage id: ${stageId}`);

  if (!stepIds.has(flow.entry)) issues.push(`entry step does not exist: ${flow.entry}`);

  for (const stage of flow.stages) {
    for (const stepId of stage.stepIds) {
      if (!stepIds.has(stepId))
        issues.push(`stage '${stage.id}' references unknown step '${stepId}'`);
    }
  }

  for (const step of flow.steps) {
    if (!stageIds.has(step.stageId)) {
      issues.push(`step '${step.id}' references unknown stage '${step.stageId}'`);
    }

    for (const requiredRoute of requiredRoutesForStep(step)) {
      if (step.routes[requiredRoute] === undefined) {
        issues.push(`step '${step.id}' is missing required route '${requiredRoute}'`);
      }
    }

    for (const [routeName, target] of Object.entries(step.routes)) {
      if (!isRouteTarget(target)) {
        issues.push(`step '${step.id}' route '${routeName}' has invalid target`);
        continue;
      }
      if (target.kind === 'step' && !stepIds.has(target.stepId)) {
        issues.push(
          `step '${step.id}' route '${routeName}' targets unknown step '${target.stepId}'`,
        );
      }
    }
  }

  return { ok: issues.length === 0, issues };
}

export function assertExecutableFlowV2(flow: ExecutableFlowV2): void {
  const validation = validateExecutableFlowV2(flow);
  if (!validation.ok) {
    throw new Error(`invalid executable flow v2: ${validation.issues.join('; ')}`);
  }
}
