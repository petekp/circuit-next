import { isAbsolute, resolve, sep } from 'node:path';

export function resolveRunFilePath(runDir: string, runRelativePath: string): string {
  if (runRelativePath.trim().length === 0) {
    throw new Error('run file path must be non-empty');
  }
  if (isAbsolute(runRelativePath)) {
    throw new Error(`run file path must be relative: ${runRelativePath}`);
  }

  const root = resolve(runDir);
  const fullPath = resolve(root, runRelativePath);
  if (fullPath !== root && !fullPath.startsWith(`${root}${sep}`)) {
    throw new Error(`run file path escapes run directory: ${runRelativePath}`);
  }
  if (fullPath === root) {
    throw new Error(`run file path must name a file: ${runRelativePath}`);
  }

  return fullPath;
}
