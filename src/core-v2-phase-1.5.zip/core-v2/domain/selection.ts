export interface Selection {
  readonly connector?: string;
  readonly provider?: string;
  readonly model?: string;
  readonly effort?: string;
}
