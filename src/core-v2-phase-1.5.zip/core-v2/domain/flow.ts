export type FlowId = string;
export type StageId = string;

export interface ExecutableStageV2 {
  readonly id: StageId;
  readonly title?: string;
  readonly stepIds: readonly string[];
}
