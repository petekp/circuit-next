import type { TerminalTarget } from '../domain/route.js';
import type { RunId, RunStatusV2 } from '../domain/run.js';
import type { RunFileStore } from '../run-files/run-file-store.js';

export interface RunResultV2 {
  readonly runId: RunId;
  readonly status: RunStatusV2;
  readonly terminalTarget?: TerminalTarget;
  readonly traceEntriesObserved: number;
}

export async function writeRunResultV2(files: RunFileStore, result: RunResultV2): Promise<string> {
  return await files.writeJson('result.json', result);
}
