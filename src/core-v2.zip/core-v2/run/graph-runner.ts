import { randomUUID } from 'node:crypto';
import { mkdir } from 'node:fs/promises';
import type { TerminalTarget } from '../domain/route.js';
import type { RunStatusV2 } from '../domain/run.js';
import { type ExecutorRegistryV2, createDefaultExecutorsV2 } from '../executors/index.js';
import type { ExecutableFlowV2 } from '../manifest/executable-flow.js';
import { assertExecutableFlowV2 } from '../manifest/validate-executable-flow.js';
import { RunFileStore } from '../run-files/run-file-store.js';
import { TraceStore } from '../trace/trace-store.js';
import { type RunResultV2, writeRunResultV2 } from './result-writer.js';
import type { RunContextV2 } from './run-context.js';

export interface GraphRunnerOptionsV2 {
  readonly runDir: string;
  readonly runId?: string;
  readonly executors?: Partial<ExecutorRegistryV2>;
  readonly maxSteps?: number;
}

export interface GraphRunResultV2 extends RunResultV2 {
  readonly resultPath: string;
}

function statusForTerminal(target: TerminalTarget): RunStatusV2 {
  if (target === '@done') return 'completed';
  if (target === '@failed') return 'failed';
  if (target === '@handoff') return 'handoff';
  return 'aborted';
}

async function closeRun(
  context: RunContextV2,
  status: RunStatusV2,
  terminalTarget?: TerminalTarget,
): Promise<GraphRunResultV2> {
  await context.trace.append({
    runId: context.runId,
    type: 'run.closed',
    data: terminalTarget === undefined ? { status } : { status, terminalTarget },
  });
  const result: RunResultV2 = {
    runId: context.runId,
    status,
    traceEntriesObserved: context.trace.getAll().length,
    ...(terminalTarget === undefined ? {} : { terminalTarget }),
  };
  const resultPath = await writeRunResultV2(context.files, result);
  return { ...result, resultPath };
}

export async function executeExecutableFlowV2(
  flow: ExecutableFlowV2,
  options: GraphRunnerOptionsV2,
): Promise<GraphRunResultV2> {
  assertExecutableFlowV2(flow);
  await mkdir(options.runDir, { recursive: true });

  const trace = new TraceStore(options.runDir);
  const files = new RunFileStore(options.runDir);
  const runId = options.runId ?? randomUUID();
  const context: RunContextV2 = { flow, runId, runDir: options.runDir, files, trace };
  const executors: ExecutorRegistryV2 = {
    ...createDefaultExecutorsV2(),
    ...options.executors,
  };
  const steps = new Map(flow.steps.map((step) => [step.id, step]));
  const maxSteps = options.maxSteps ?? Math.max(flow.steps.length * 4, 8);

  await trace.append({
    runId,
    type: 'run.started',
    data: { flowId: flow.id, version: flow.version, entry: flow.entry },
  });

  let currentStepId = flow.entry;
  for (let index = 0; index < maxSteps; index += 1) {
    const step = steps.get(currentStepId);
    if (step === undefined) {
      return await closeRun(context, 'failed');
    }

    await trace.append({ runId, type: 'step.started', stepId: step.id });

    let route: string;
    try {
      const outcome = await executors[step.kind](step, context);
      route = outcome.route;
      await trace.append({
        runId,
        type: 'step.completed',
        stepId: step.id,
        data: { route, details: outcome.details ?? {} },
      });
    } catch (error) {
      await trace.append({
        runId,
        type: 'step.failed',
        stepId: step.id,
        data: { message: (error as Error).message },
      });
      return await closeRun(context, 'failed', '@failed');
    }

    const target = step.routes[route];
    if (target === undefined) {
      await trace.append({
        runId,
        type: 'step.failed',
        stepId: step.id,
        data: { message: `route '${route}' was not declared` },
      });
      return await closeRun(context, 'failed', '@failed');
    }

    if (target.kind === 'terminal') {
      return await closeRun(context, statusForTerminal(target.target), target.target);
    }

    currentStepId = target.stepId;
  }

  return await closeRun(context, 'failed', '@failed');
}
