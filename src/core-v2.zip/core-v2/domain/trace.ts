import type { RunId } from './run.js';
import type { StepId } from './step.js';

export type TraceSequence = number;

export type TraceEntryTypeV2 =
  | 'run.started'
  | 'step.started'
  | 'step.completed'
  | 'step.failed'
  | 'run.closed';

export interface TraceEntryInputV2 {
  readonly runId: RunId;
  readonly type: TraceEntryTypeV2;
  readonly stepId?: StepId;
  readonly data?: Record<string, unknown>;
}

export interface TraceEntryV2 extends TraceEntryInputV2 {
  readonly sequence: TraceSequence;
}
