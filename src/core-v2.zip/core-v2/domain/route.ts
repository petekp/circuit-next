import type { StepId } from './step.js';

export type RouteName = string;

export type TerminalTarget = '@done' | '@failed' | '@handoff' | '@aborted';

export const TERMINAL_TARGETS: readonly TerminalTarget[] = [
  '@done',
  '@failed',
  '@handoff',
  '@aborted',
] as const;

export type RouteTarget =
  | { readonly kind: 'step'; readonly stepId: StepId }
  | { readonly kind: 'terminal'; readonly target: TerminalTarget };

export type RoutesV2 = Readonly<Record<RouteName, RouteTarget>>;
