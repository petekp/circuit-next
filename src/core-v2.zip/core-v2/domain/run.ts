export type RunId = string;

export type RunStatusV2 =
  | 'not_started'
  | 'running'
  | 'completed'
  | 'failed'
  | 'handoff'
  | 'aborted';
