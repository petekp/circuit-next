import type { RunStatusV2 } from '../domain/run.js';
import type { TraceEntryV2 } from '../domain/trace.js';

function isRunStatus(value: unknown): value is RunStatusV2 {
  return (
    value === 'not_started' ||
    value === 'running' ||
    value === 'completed' ||
    value === 'failed' ||
    value === 'handoff' ||
    value === 'aborted'
  );
}

export function projectStatusFromTraceV2(entries: readonly TraceEntryV2[]): RunStatusV2 {
  const closed = [...entries].reverse().find((entry) => entry.type === 'run.closed');
  if (closed !== undefined) {
    const status = closed.data?.status;
    if (isRunStatus(status)) return status;
    return 'failed';
  }
  if (entries.some((entry) => entry.type === 'run.started')) return 'running';
  return 'not_started';
}
