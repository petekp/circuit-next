# Circuit v2 Phase 3.5 / 4 Review Bundle

This bundle contains the files changed for the Phase 3.5 correction pass in
the current checkout.

Phase 4 has not started in this checkout. There is no Phase 4 implementation
or Phase 4 worklog entry to package. The Phase 3.5 worklog explicitly stops
before Phase 4 and recommends starting Phase 4 with manifest snapshot support.

Included Phase 3.5 scope:

- Bounded `retry` / `revise` recovery route re-entry in the v2 graph runner.
- Attempt numbers on v2 step trace entries.
- Raw compiled-flow bytes as the single source of truth for `runCompiledFlowV2`.
- Selected entry mode and depth recorded in bootstrap trace data.
- Regression tests for retry exhaustion, invalid route re-entry, and named
  entry-mode start behavior.
- Checkpoint 3 and worklog updates documenting the correction.

Validation recorded in `docs/architecture/v2-worklog.md`:

- `npm run check`: passed.
- `npm run lint`: passed after import-order correction.
- `npm run build`: passed.
- `npx vitest run tests/core-v2 tests/parity`: passed.
- `npm run test:fast`: passed.
- `npm run check-flow-drift`: passed.
- `git diff --check`: passed.
- `npm run verify`: passed.
