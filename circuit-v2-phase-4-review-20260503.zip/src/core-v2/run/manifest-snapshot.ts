import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { CompiledFlowId, RunId } from '../../schemas/ids.js';
import { ManifestSnapshot, computeManifestHash } from '../../schemas/manifest.js';
import type { FlowId } from '../domain/flow.js';
import type { RunId as RunIdV2 } from '../domain/run.js';

export const MANIFEST_SNAPSHOT_RUN_FILE = 'manifest.snapshot.json';

export function manifestSnapshotPathV2(runDir: string): string {
  return join(runDir, MANIFEST_SNAPSHOT_RUN_FILE);
}

export interface ManifestSnapshotInputV2 {
  readonly runDir: string;
  readonly runId: RunIdV2;
  readonly flowId: FlowId;
  readonly capturedAt: string;
  readonly bytes: Uint8Array;
}

export async function writeManifestSnapshotV2(
  input: ManifestSnapshotInputV2,
): Promise<ManifestSnapshot> {
  const bytes = Buffer.from(input.bytes);
  const snapshot = ManifestSnapshot.parse({
    schema_version: 1,
    run_id: RunId.parse(input.runId),
    flow_id: CompiledFlowId.parse(input.flowId),
    captured_at: input.capturedAt,
    algorithm: 'sha256-raw',
    hash: computeManifestHash(bytes),
    bytes_base64: bytes.toString('base64'),
  });
  const path = manifestSnapshotPathV2(input.runDir);
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, `${JSON.stringify(snapshot, null, 2)}\n`, { encoding: 'utf8', flag: 'wx' });
  return snapshot;
}

export async function readManifestSnapshotV2(runDir: string): Promise<ManifestSnapshot> {
  const raw = JSON.parse(await readFile(manifestSnapshotPathV2(runDir), 'utf8'));
  return ManifestSnapshot.parse(raw);
}
