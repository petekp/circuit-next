import {
  type CompiledFlow,
  CompiledFlow as CompiledFlowSchema,
} from '../../schemas/compiled-flow.js';
import type { Depth } from '../../schemas/depth.js';
import { computeManifestHash } from '../../schemas/manifest.js';
import type { ExecutorRegistryV2 } from '../executors/index.js';
import { fromCompiledFlowV1 } from '../manifest/from-compiled-flow-v1.js';
import { type GraphRunResultV2, executeExecutableFlowV2 } from './graph-runner.js';

export interface CompiledFlowRunOptionsV2 {
  readonly flowBytes: Uint8Array;
  readonly runDir: string;
  readonly runId?: string;
  readonly goal: string;
  readonly entryModeName?: string;
  readonly depth?: Depth;
  readonly now?: () => Date;
  readonly executors?: Partial<ExecutorRegistryV2>;
  readonly maxSteps?: number;
}

function selectEntryMode(
  flow: CompiledFlow,
  entryModeName: string | undefined,
): CompiledFlow['entry_modes'][number] {
  if (entryModeName === undefined) {
    const entry = flow.entry_modes[0];
    if (entry === undefined) throw new Error(`compiled flow '${flow.id}' declares no entry modes`);
    return entry;
  }
  const entry = flow.entry_modes.find((mode) => mode.name === entryModeName);
  if (entry === undefined) {
    throw new Error(`compiled flow '${flow.id}' declares no entry mode named '${entryModeName}'`);
  }
  return entry;
}

function parseCompiledFlowBytes(bytes: Uint8Array): CompiledFlow {
  const raw = JSON.parse(Buffer.from(bytes).toString('utf8'));
  return CompiledFlowSchema.parse(raw);
}

export async function runCompiledFlowV2(
  options: CompiledFlowRunOptionsV2,
): Promise<GraphRunResultV2> {
  const flow = parseCompiledFlowBytes(options.flowBytes);
  const entry = selectEntryMode(flow, options.entryModeName);
  const executable = fromCompiledFlowV1(flow);
  const depth = options.depth ?? entry.depth;
  return await executeExecutableFlowV2(
    {
      ...executable,
      entry: entry.start_at,
      metadata: {
        ...executable.metadata,
        selected_entry_mode: entry.name,
        selected_depth: depth,
      },
    },
    {
      runDir: options.runDir,
      ...(options.runId === undefined ? {} : { runId: options.runId }),
      goal: options.goal,
      manifestHash: computeManifestHash(options.flowBytes),
      manifestBytes: options.flowBytes,
      entryModeName: entry.name,
      depth,
      ...(options.now === undefined ? {} : { now: options.now }),
      ...(options.executors === undefined ? {} : { executors: options.executors }),
      ...(options.maxSteps === undefined ? {} : { maxSteps: options.maxSteps }),
    },
  );
}
