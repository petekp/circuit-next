import { randomUUID } from 'node:crypto';
import { mkdir, readdir } from 'node:fs/promises';
import { computeManifestHash } from '../../schemas/manifest.js';
import type { TerminalTarget } from '../domain/route.js';
import type { RunClosedOutcomeV2 } from '../domain/run.js';
import { type ExecutorRegistryV2, createDefaultExecutorsV2 } from '../executors/index.js';
import type { ExecutableFlowV2, ExecutableStepV2 } from '../manifest/executable-flow.js';
import { assertExecutableFlowV2 } from '../manifest/validate-executable-flow.js';
import { RunFileStore } from '../run-files/run-file-store.js';
import { TraceStore } from '../trace/trace-store.js';
import { writeManifestSnapshotV2 } from './manifest-snapshot.js';
import { type RunResultV2, writeRunResultV2 } from './result-writer.js';
import type { RunContextV2 } from './run-context.js';

export interface GraphRunnerOptionsV2 {
  readonly runDir: string;
  readonly runId?: string;
  readonly goal?: string;
  readonly manifestHash?: string;
  readonly manifestBytes?: Uint8Array;
  readonly entryModeName?: string;
  readonly depth?: string;
  readonly now?: () => Date;
  readonly executors?: Partial<ExecutorRegistryV2>;
  readonly maxSteps?: number;
}

export interface GraphRunResultV2 extends RunResultV2 {
  readonly resultPath: string;
}

const RECOVERY_ROUTE_LABELS = new Set(['retry', 'revise']);

function defaultManifestHash(flow: ExecutableFlowV2): string {
  return `core-v2:${flow.id}@${flow.version}`;
}

function resultSummary(outcome: RunClosedOutcomeV2, terminalTarget?: TerminalTarget): string {
  if (terminalTarget === undefined) return `Run closed with outcome ${outcome}.`;
  return `Run closed with outcome ${outcome} via ${terminalTarget}.`;
}

function outcomeForTerminal(target: TerminalTarget): RunClosedOutcomeV2 {
  if (target === '@complete') return 'complete';
  if (target === '@stop') return 'stopped';
  if (target === '@handoff') return 'handoff';
  return 'escalated';
}

function isRecoveryRoute(route: string | undefined): boolean {
  return route !== undefined && RECOVERY_ROUTE_LABELS.has(route);
}

function configuredMaxAttempts(step: ExecutableStepV2): number | undefined {
  const budgets = step.budgets;
  if (budgets === undefined || budgets === null || typeof budgets !== 'object') return undefined;
  const maxAttempts = (budgets as { readonly max_attempts?: unknown }).max_attempts;
  if (typeof maxAttempts !== 'number') return undefined;
  if (!Number.isInteger(maxAttempts) || maxAttempts < 1) return undefined;
  return maxAttempts;
}

function maxAttemptsForRoute(step: ExecutableStepV2, route: string | undefined): number {
  return configuredMaxAttempts(step) ?? (isRecoveryRoute(route) ? 2 : 1);
}

async function assertFreshRunDir(runDir: string): Promise<void> {
  const entries = await readdir(runDir);
  if (entries.length > 0) {
    throw new Error(
      `core-v2 baseline requires a fresh run directory; existing directory is not empty (${entries.join(', ')})`,
    );
  }
}

function resolveManifestHash(flow: ExecutableFlowV2, options: GraphRunnerOptionsV2): string {
  if (options.manifestBytes === undefined) {
    return options.manifestHash ?? defaultManifestHash(flow);
  }
  const computed = computeManifestHash(options.manifestBytes);
  if (options.manifestHash !== undefined && options.manifestHash !== computed) {
    throw new Error('manifest bytes hash differs from run manifest_hash');
  }
  return computed;
}

async function closeRun(
  context: RunContextV2,
  outcome: RunClosedOutcomeV2,
  terminalTarget?: TerminalTarget,
  reason?: string,
): Promise<GraphRunResultV2> {
  await context.trace.append({
    run_id: context.runId,
    kind: 'run.closed',
    data: {
      outcome,
      ...(terminalTarget === undefined ? {} : { terminal_target: terminalTarget }),
      ...(reason === undefined ? {} : { reason }),
    },
  });
  const result: RunResultV2 = {
    schema_version: 1,
    run_id: context.runId,
    flow_id: context.flow.id,
    goal: context.goal,
    outcome,
    summary: resultSummary(outcome, terminalTarget),
    closed_at: context.now().toISOString(),
    trace_entries_observed: context.trace.getAll().length,
    manifest_hash: context.manifestHash,
    ...(reason === undefined ? {} : { reason }),
  };
  const resultPath = await writeRunResultV2(context.files, result);
  return { ...result, resultPath };
}

export async function executeExecutableFlowV2(
  flow: ExecutableFlowV2,
  options: GraphRunnerOptionsV2,
): Promise<GraphRunResultV2> {
  assertExecutableFlowV2(flow);
  await mkdir(options.runDir, { recursive: true });
  await assertFreshRunDir(options.runDir);

  const trace = new TraceStore(options.runDir);
  const existingTrace = await trace.load();
  if (existingTrace.length > 0) {
    throw new Error('core-v2 baseline requires a fresh run directory');
  }

  const files = new RunFileStore(options.runDir);
  const runId = options.runId ?? randomUUID();
  const context: RunContextV2 = {
    flow,
    runId,
    runDir: options.runDir,
    goal: options.goal ?? '',
    manifestHash: resolveManifestHash(flow, options),
    ...(options.entryModeName === undefined ? {} : { entryModeName: options.entryModeName }),
    ...(options.depth === undefined ? {} : { depth: options.depth }),
    now: options.now ?? (() => new Date()),
    files,
    trace,
  };
  const executors: ExecutorRegistryV2 = {
    ...createDefaultExecutorsV2(),
    ...options.executors,
  };
  const steps = new Map(flow.steps.map((step) => [step.id, step]));
  const completedStepCounts = new Map<string, number>();
  const maxSteps = options.maxSteps ?? Math.max(flow.steps.length * 4, 8);

  const bootstrapRecordedAt = context.now().toISOString();
  if (options.manifestBytes !== undefined) {
    await writeManifestSnapshotV2({
      runDir: options.runDir,
      runId,
      flowId: flow.id,
      capturedAt: bootstrapRecordedAt,
      bytes: options.manifestBytes,
    });
  }

  await trace.append({
    run_id: runId,
    kind: 'run.bootstrapped',
    data: {
      flow_id: flow.id,
      version: flow.version,
      entry: flow.entry,
      manifest_hash: context.manifestHash,
      ...(context.entryModeName === undefined ? {} : { entry_mode: context.entryModeName }),
      ...(context.depth === undefined ? {} : { depth: context.depth }),
    },
  });

  let currentStepId = flow.entry;
  let incomingRouteTaken: string | undefined;
  for (let index = 0; index < maxSteps; index += 1) {
    const step = steps.get(currentStepId);
    if (step === undefined) {
      return await closeRun(
        context,
        'aborted',
        undefined,
        `route target '${currentStepId}' is not a known step id`,
      );
    }

    const completedCount = completedStepCounts.get(step.id) ?? 0;
    const maxAttempts = maxAttemptsForRoute(step, incomingRouteTaken);
    const attempt = completedCount + 1;
    if (
      completedCount > 0 &&
      (!isRecoveryRoute(incomingRouteTaken) || completedCount >= maxAttempts)
    ) {
      const reason =
        incomingRouteTaken === undefined
          ? `route cycle detected at step '${step.id}'; aborting before re-entering an already completed step`
          : `route '${incomingRouteTaken}' for step '${step.id}' exhausted max_attempts=${maxAttempts}`;
      await trace.append({
        run_id: runId,
        kind: 'step.aborted',
        step_id: step.id,
        attempt,
        reason,
        data: { message: reason },
      });
      return await closeRun(context, 'aborted', undefined, reason);
    }

    await trace.append({ run_id: runId, kind: 'step.entered', step_id: step.id, attempt });

    let route: string;
    let details: Record<string, unknown>;
    try {
      const outcome = await executors[step.kind](step, context);
      route = outcome.route;
      details = outcome.details ?? {};
    } catch (error) {
      const message = (error as Error).message;
      await trace.append({
        run_id: runId,
        kind: 'step.aborted',
        step_id: step.id,
        attempt,
        reason: message,
        data: { message },
      });
      return await closeRun(
        context,
        'aborted',
        undefined,
        `step '${step.id}' handler threw: ${message}`,
      );
    }

    const target = step.routes[route];
    if (target === undefined) {
      const reason = `step '${step.id}' selected undeclared route '${route}'`;
      await trace.append({
        run_id: runId,
        kind: 'step.aborted',
        step_id: step.id,
        attempt,
        reason,
        data: { message: reason },
      });
      return await closeRun(context, 'aborted', undefined, reason);
    }

    if (target.kind === 'step' && target.stepId === step.id && route === 'pass') {
      const reason = `route cycle detected: step '${step.id}' routes via '${route}' to itself`;
      await trace.append({
        run_id: runId,
        kind: 'step.aborted',
        step_id: step.id,
        attempt,
        route_taken: route,
        reason,
        data: { message: reason },
      });
      return await closeRun(context, 'aborted', undefined, reason);
    }

    if (target.kind === 'step') {
      const targetCompletedCount = completedStepCounts.get(target.stepId) ?? 0;
      const targetStep = steps.get(target.stepId);
      const targetMaxAttempts =
        targetStep === undefined
          ? maxAttemptsForRoute(step, route)
          : maxAttemptsForRoute(targetStep, route);
      if (
        targetCompletedCount > 0 &&
        (!isRecoveryRoute(route) || targetCompletedCount >= targetMaxAttempts)
      ) {
        const reason = isRecoveryRoute(route)
          ? `route '${route}' for step '${target.stepId}' exhausted max_attempts=${targetMaxAttempts}`
          : `route cycle detected: step '${step.id}' routes via '${route}' to already completed step '${target.stepId}'`;
        await trace.append({
          run_id: runId,
          kind: 'step.aborted',
          step_id: step.id,
          attempt,
          route_taken: route,
          reason,
          data: { message: reason },
        });
        return await closeRun(context, 'aborted', undefined, reason);
      }
    }

    await trace.append({
      run_id: runId,
      kind: 'step.completed',
      step_id: step.id,
      attempt,
      route_taken: route,
      data: { route, details },
    });
    completedStepCounts.set(step.id, completedCount + 1);

    if (target.kind === 'terminal') {
      return await closeRun(context, outcomeForTerminal(target.target), target.target);
    }

    currentStepId = target.stepId;
    incomingRouteTaken = route;
  }

  return await closeRun(context, 'aborted', undefined, `maxSteps exceeded: ${maxSteps}`);
}
