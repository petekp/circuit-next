import { join as joinPath } from 'node:path';
import type { RunFileRef } from '../domain/run-file.js';
import type { StepOutcomeV2 } from '../domain/step.js';
import { buildFanoutAggregateV2 } from '../fanout/aggregate-report.js';
import {
  branchNeedsWorktree,
  executeRelayFanoutBranchV2,
  executeSubRunFanoutBranchV2,
} from '../fanout/branch-execution.js';
import { expandFanoutBranchesV2 } from '../fanout/branch-expansion.js';
import { evaluateFanoutJoinPolicyV2 } from '../fanout/join-policy.js';
import type { BranchOutcomeV2, FanoutJoinPolicyV2 } from '../fanout/types.js';
import { gitWorktreeRunnerV2 } from '../fanout/worktree.js';
import type { FanoutStepV2 } from '../manifest/executable-flow.js';
import type { RunContextV2 } from '../run/run-context.js';
import type { RelayConnectorV2 } from './relay.js';

function aggregateRef(step: FanoutStepV2): RunFileRef {
  const aggregate = step.writes?.aggregate;
  if (aggregate !== undefined) return aggregate;
  const joinAggregate = (step.join as { readonly aggregate?: RunFileRef }).aggregate;
  if (joinAggregate !== undefined) return joinAggregate;
  throw new Error(`fanout step '${step.id}' is missing writes.aggregate`);
}

function branchesDir(step: FanoutStepV2): string {
  const branchesDirRef = step.writes?.branches_dir;
  if (branchesDirRef !== undefined) return branchesDirRef.path;
  throw new Error(`fanout step '${step.id}' is missing writes.branches_dir`);
}

function joinPolicy(step: FanoutStepV2): FanoutJoinPolicyV2 {
  const policy = (step.check as { readonly join?: { readonly policy?: unknown } }).join?.policy;
  if (policy === 'pick-winner' || policy === 'disjoint-merge' || policy === 'aggregate-only') {
    return policy;
  }
  throw new Error(`fanout step '${step.id}' has unsupported join policy`);
}

function admitOrder(step: FanoutStepV2): readonly string[] {
  const admit = (step.check as { readonly verdicts?: { readonly admit?: unknown } }).verdicts
    ?.admit;
  return Array.isArray(admit)
    ? admit.filter((entry): entry is string => typeof entry === 'string')
    : [];
}

function concurrencyLimit(step: FanoutStepV2): number | 'unbounded' {
  const concurrency = step.concurrency as { readonly kind?: unknown; readonly max?: unknown };
  if (concurrency?.kind === 'unbounded') return 'unbounded';
  if (concurrency?.kind === 'bounded' && typeof concurrency.max === 'number') {
    return concurrency.max;
  }
  return 4;
}

async function runWithConcurrency<T>(
  items: readonly T[],
  limit: number | 'unbounded',
  worker: (item: T, abortSignal: { value: boolean }) => Promise<void>,
): Promise<void> {
  const abortSignal = { value: false };
  if (limit === 'unbounded') {
    await Promise.all(items.map((item) => worker(item, abortSignal)));
    return;
  }
  let cursor = 0;
  const workers: Promise<void>[] = [];
  for (let i = 0; i < Math.min(limit, items.length); i += 1) {
    workers.push(
      (async () => {
        while (!abortSignal.value) {
          const index = cursor;
          cursor += 1;
          const item = items[index];
          if (item === undefined) return;
          await worker(item, abortSignal);
        }
      })(),
    );
  }
  await Promise.all(workers);
}

export async function executeFanoutV2(
  step: FanoutStepV2,
  context: RunContextV2,
  relayConnector?: RelayConnectorV2,
): Promise<StepOutcomeV2> {
  const branchDirRoot = branchesDir(step);
  const aggregate = aggregateRef(step);
  const branches = await expandFanoutBranchesV2(step, context.files);
  if (branches.length === 0) {
    throw new Error(`fanout step '${step.id}': branch resolution produced zero branches`);
  }
  const policy = joinPolicy(step);
  if (policy === 'disjoint-merge' && branches.some((branch) => branch.kind !== 'sub-run')) {
    throw new Error(
      `fanout step '${step.id}': disjoint-merge is only supported for sub-run branches with worktrees`,
    );
  }
  const branchIds = branches.map((branch) => branch.branch_id);
  await context.trace.append({
    run_id: context.runId,
    kind: 'fanout.started',
    step_id: step.id,
    branch_ids: branchIds,
    data: { on_child_failure: step.onChildFailure ?? 'abort-all' },
  });

  const worktreeRunner = context.worktreeRunner ?? gitWorktreeRunnerV2;
  const provisioned: string[] = [];
  const outcomes: BranchOutcomeV2[] = [];
  const onChildFailure = step.onChildFailure ?? 'abort-all';
  let branchFiles: ReadonlyMap<string, readonly string[]> | undefined;
  let branchFilesError: string | undefined;

  try {
    await runWithConcurrency(branches, concurrencyLimit(step), async (branch, abortSignal) => {
      if (abortSignal.value) return;
      const branchDirRel = `${branchDirRoot}/${branch.branch_id}`;
      const branchDirAbs = context.files.resolve(branchDirRel);
      let outcome: BranchOutcomeV2;
      if (branch.kind === 'relay') {
        outcome = await executeRelayFanoutBranchV2(
          step,
          context,
          branch,
          relayConnector,
          branchDirRel,
          branchDirAbs,
        );
      } else {
        if (context.projectRoot === undefined) {
          throw new Error(
            `fanout step '${step.id}': projectRoot is required to anchor per-branch worktrees`,
          );
        }
        const worktreePath = joinPath(
          context.projectRoot,
          '.circuit-next',
          'worktrees',
          context.runId,
          step.id,
          branch.branch_id,
        );
        if (branchNeedsWorktree(branch)) provisioned.push(worktreePath);
        outcome = await executeSubRunFanoutBranchV2(
          step,
          context,
          branch,
          worktreeRunner,
          branchDirRel,
          worktreePath,
        );
      }
      outcomes.push(outcome);
      if (!outcome.admitted && onChildFailure === 'abort-all') {
        abortSignal.value = true;
      }
    });

    if (policy === 'disjoint-merge' && outcomes.every((outcome) => outcome.admitted)) {
      try {
        const collected = await Promise.all(
          outcomes.map(async (outcome) => {
            const files = worktreeRunner.changedFiles
              ? await Promise.resolve(worktreeRunner.changedFiles(outcome.worktree_path, 'HEAD'))
              : [];
            return [outcome.branch_id, files] as const;
          }),
        );
        branchFiles = new Map(collected);
      } catch (error) {
        branchFilesError = (error as Error).message;
      }
    }
  } finally {
    for (const worktreePath of provisioned) {
      try {
        await Promise.resolve(worktreeRunner.remove(worktreePath));
      } catch {
        // Cleanup is best-effort here, matching the v1 runtime. A leftover
        // worktree is operator-visible but should not hide the primary failure.
      }
    }
  }

  const joinResult = evaluateFanoutJoinPolicyV2({
    policy,
    stepId: step.id,
    admitOrder: admitOrder(step),
    outcomes: outcomes.map((outcome) => ({
      branch_id: outcome.branch_id,
      child_outcome: outcome.child_outcome,
      verdict: outcome.verdict,
      admitted: outcome.admitted,
      ...(outcome.result_body === undefined ? {} : { result_body: outcome.result_body }),
      ...(outcome.failure_reason === undefined ? {} : { failure_reason: outcome.failure_reason }),
    })),
    ...(branchFiles === undefined ? {} : { branchFiles }),
    ...(branchFilesError === undefined ? {} : { branchFilesError }),
  });

  await context.files.writeJson(
    aggregate,
    buildFanoutAggregateV2(policy, outcomes, joinResult.winnerBranchId),
  );
  await context.trace.append({
    run_id: context.runId,
    kind: 'step.report_written',
    step_id: step.id,
    report_path: aggregate.path,
    ...(aggregate.schema === undefined ? {} : { report_schema: aggregate.schema }),
  });
  const branchesCompleted = outcomes.filter(
    (outcome) => outcome.child_outcome === 'complete',
  ).length;
  await context.trace.append({
    run_id: context.runId,
    kind: 'fanout.joined',
    step_id: step.id,
    policy,
    ...(joinResult.winnerBranchId === undefined
      ? {}
      : { selected_branch_id: joinResult.winnerBranchId }),
    aggregate_path: aggregate.path,
    branches_completed: branchesCompleted,
    branches_failed: outcomes.length - branchesCompleted,
  });

  if (joinResult.joinedSuccessfully) {
    await context.trace.append({
      run_id: context.runId,
      kind: 'check.evaluated',
      step_id: step.id,
      check_kind: 'fanout_aggregate',
      outcome: 'pass',
    });
    return { route: 'pass', details: { aggregate: aggregate.path } };
  }

  const reason =
    joinResult.failureReason ?? `fanout step '${step.id}': join policy '${policy}' did not pass`;
  await context.trace.append({
    run_id: context.runId,
    kind: 'check.evaluated',
    step_id: step.id,
    check_kind: 'fanout_aggregate',
    outcome: 'fail',
    reason,
  });
  throw new Error(reason);
}
