# Circuit v2 Runtime Import Inventory

Generated for Phase 4.22 retained-runtime narrowing prep. This file records current command output and targeted ownership evidence for deletion-readiness review. The inventory excludes this generated file from the rg scans so it does not cite itself.

## Runtime file tree

```bash
find src/runtime -type f | sort
```

```text
src/runtime/append-and-derive.ts
src/runtime/catalog-derivations.ts
src/runtime/compile-schematic-to-flow.ts
src/runtime/config-loader.ts
src/runtime/connectors/claude-code.ts
src/runtime/connectors/codex.ts
src/runtime/connectors/custom.ts
src/runtime/connectors/relay-materializer.ts
src/runtime/connectors/shared.ts
src/runtime/manifest-snapshot-writer.ts
src/runtime/operator-summary-writer.ts
src/runtime/policy/flow-kind-policy.ts
src/runtime/progress-projector.ts
src/runtime/reducer.ts
src/runtime/registries/checkpoint-writers/registry.ts
src/runtime/registries/checkpoint-writers/types.ts
src/runtime/registries/close-writers/registry.ts
src/runtime/registries/close-writers/shared.ts
src/runtime/registries/close-writers/types.ts
src/runtime/registries/compose-writers/registry.ts
src/runtime/registries/compose-writers/types.ts
src/runtime/registries/cross-report-validators.ts
src/runtime/registries/report-schemas.ts
src/runtime/registries/shape-hints/registry.ts
src/runtime/registries/shape-hints/types.ts
src/runtime/registries/verification-writers/registry.ts
src/runtime/registries/verification-writers/types.ts
src/runtime/relay-selection.ts
src/runtime/relay-support.ts
src/runtime/result-writer.ts
src/runtime/router.ts
src/runtime/run-relative-path.ts
src/runtime/run-status-projection.ts
src/runtime/runner-types.ts
src/runtime/runner.ts
src/runtime/selection-resolver.ts
src/runtime/snapshot-writer.ts
src/runtime/step-handlers/checkpoint.ts
src/runtime/step-handlers/compose.ts
src/runtime/step-handlers/fanout.ts
src/runtime/step-handlers/fanout/aggregate.ts
src/runtime/step-handlers/fanout/branch-resolution.ts
src/runtime/step-handlers/fanout/join-policy.ts
src/runtime/step-handlers/fanout/types.ts
src/runtime/step-handlers/index.ts
src/runtime/step-handlers/recovery-route.ts
src/runtime/step-handlers/relay.ts
src/runtime/step-handlers/shared.ts
src/runtime/step-handlers/sub-run.ts
src/runtime/step-handlers/types.ts
src/runtime/step-handlers/verification.ts
src/runtime/trace-reader.ts
src/runtime/trace-writer.ts
src/runtime/write-capable-worker-disclosure.ts
```

## Phase 4.18 Targeted Connector And Registry Inventory

Phase 4.18 did not move connector subprocess modules, relay materialization, or registries. The targeted inventory below records why those boundaries are still live.

### Connector / materializer references

```text
src/core-v2/executors/relay.ts imports relayClaudeCode, relayCodex, and relayCustom from src/runtime/connectors/*.
src/runtime/relay-selection.ts dynamically imports relayClaudeCode, relayCodex, and relayCustom for retained runtime relay resolution.
src/runtime/connectors/relay-materializer.ts imports RelayResult and sha256Hex through the runtime connector compatibility surface.
src/runtime/runner.ts imports sha256Hex through the runtime connector compatibility surface for retained relay/checkpoint verification.
tests/runner/agent-relay-roundtrip.test.ts and tests/runner/codex-relay-roundtrip.test.ts import materializeRelay directly.
tests/runner/agent-connector-smoke.test.ts and tests/runner/codex-connector-smoke.test.ts import the subprocess connector modules directly.
tests/runner/custom-connector-runtime.test.ts imports relayCustom directly.
```

### Connector smoke fingerprint source lists

```text
tests/runner/codex-relay-roundtrip.test.ts fingerprints:
- src/runtime/connectors/codex.ts
- src/shared/connector-relay.ts
- src/shared/connector-helpers.ts
- src/runtime/connectors/shared.ts
- src/runtime/connectors/relay-materializer.ts
- src/runtime/runner.ts
- src/runtime/registries/report-schemas.ts

tests/runner/explore-e2e-parity.test.ts fingerprints:
- src/runtime/connectors/claude-code.ts
- src/shared/connector-relay.ts
- src/shared/connector-helpers.ts
- src/runtime/connectors/shared.ts
- src/runtime/connectors/relay-materializer.ts
- src/runtime/runner.ts
- src/runtime/registries/report-schemas.ts
```

### Registry references

```text
src/core-v2/executors/compose.ts imports compose and close writer registries.
src/core-v2/executors/checkpoint.ts imports checkpoint writer registry.
src/core-v2/executors/verification.ts imports verification writer registry.
src/core-v2/executors/relay.ts imports cross-report validators and report schemas.
src/shared/relay-support.ts imports the shape-hint registry.
src/runtime/runner.ts imports compose, close, and checkpoint writer registries.
src/runtime/step-handlers/checkpoint.ts imports checkpoint writer registry.
src/runtime/step-handlers/verification.ts imports verification writer registry.
src/runtime/step-handlers/relay.ts and fanout.ts import report schemas and cross-report validators.
src/flows/** writers import registry type surfaces and close-writer path helpers.
src/flows/** relay-hints import shape-hint type surfaces.
src/flows/types.ts imports all writer, shape-hint, and cross-report validator type surfaces.
tests/runner/catalog-derivations.test.ts, compose-builder-registry.test.ts, close-builder-registry.test.ts, relay-shape-hint-registry.test.ts, cross-report-validators.test.ts, and tests/properties/visible/cross-report-validator.test.ts import registry surfaces directly.
```

## Phase 4.19 Targeted Flow-Kind Policy Inventory

Phase 4.19 moved the TypeScript flow-kind policy wrapper out of the runtime namespace without changing the canonical JS policy table.

```text
src/shared/flow-kind-policy.ts owns validateCompiledFlowKindPolicy.
src/runtime/policy/flow-kind-policy.ts re-exports the shared helper for compatibility.
src/cli/circuit.ts imports validateCompiledFlowKindPolicy from src/shared/flow-kind-policy.ts.
src/cli/create.ts imports validateCompiledFlowKindPolicy from src/shared/flow-kind-policy.ts.
tests/contracts/flow-kind-policy.test.ts imports both shared and runtime paths and asserts wrapper compatibility.
tests/runner/explore-e2e-parity.test.ts imports validateCompiledFlowKindPolicy from the shared path.
scripts/policy/flow-kind-policy.mjs remains the canonical JS table and is still Zod-free.
```

## Phase 4.20 Targeted Manifest Snapshot Inventory

Phase 4.20 moved the old runtime manifest snapshot implementation out of the runtime namespace without changing byte-match semantics.

```text
src/shared/manifest-snapshot.ts owns manifestSnapshotPath, writeManifestSnapshot, readManifestSnapshot, and verifyManifestSnapshotBytes.
src/runtime/manifest-snapshot-writer.ts re-exports the shared helper for compatibility.
src/cli/handoff.ts imports readManifestSnapshot from the shared path.
src/runtime/run-status-projection.ts imports verifyManifestSnapshotBytes from the shared path.
tests/runner/run-status-projection.test.ts imports writeManifestSnapshot from the shared path.
src/runtime/runner.ts still imports the runtime wrapper for retained runner compatibility.
tests/unit/runtime/event-log-round-trip.test.ts imports both shared and runtime paths and asserts wrapper compatibility.
src/core-v2/run/manifest-snapshot.ts remains the v2 raw-byte snapshot implementation.
```

## Phase 4.21 Targeted Operator Summary Inventory

Phase 4.21 moved operator summary writing out of the runtime namespace without changing summary wording or file output.

```text
src/shared/operator-summary-writer.ts owns writeOperatorSummary.
src/runtime/operator-summary-writer.ts re-exports the shared writer for compatibility.
src/cli/circuit.ts imports writeOperatorSummary from the shared path.
tests/runner/operator-summary-writer.test.ts imports both shared and runtime paths and asserts wrapper compatibility.
scripts/release/emit-current-capabilities.mjs lists src/shared/operator-summary-writer.ts as release evidence for final summary disclosure.
```

## Phase 4.22 Targeted Config Loader Inventory

Phase 4.22 moved config discovery out of the runtime namespace without changing layer order or schema validation.

```text
src/shared/config-loader.ts owns discoverConfigLayers, userGlobalConfigPath, and projectConfigPath.
src/runtime/config-loader.ts re-exports the shared loader for compatibility.
src/cli/circuit.ts imports discoverConfigLayers from the shared path.
tests/runner/config-loader.test.ts imports both shared and runtime paths and asserts wrapper compatibility.
```

## Runtime import references

```bash
rg -n "from ['\"].*runtime/|../runtime|../../runtime|runtime/" README.md commands plugins .claude-plugin generated docs specs scripts src tests package.json -g "!docs/architecture/v2-runtime-import-inventory.md"
```

```text
commands/run.md:206:- `src/runtime/router.ts` (current deterministic classifier)
tests/helpers/failure-message.ts:20:import type { StepHandlerResult } from '../../src/runtime/step-handlers/types.js';
src/flows/catalog.ts:13:import { runtimeProofCompiledFlowPackage } from './runtime-proof/index.js';
commands/build.md:117:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
tests/helpers/failure-message.test.ts:17:import type { StepHandlerResult } from '../../src/runtime/step-handlers/types.js';
src/flows/build/relay-hints.ts:3:import type { SchemaShapeHint } from '../../runtime/registries/shape-hints/types.js';
commands/explore.md:111:- `src/runtime/` (current runner)
src/flows/build/command.md:117:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
specs/reference/legacy-circuit/review-characterization.md:34:~/Code/circuit/scripts/runtime/bin/dispatch.js  # the CLI (bundled)
specs/reference/legacy-circuit/review-characterization.md:173:existing step kinds at `src/runtime/runner.ts` are `dispatch` and
specs/reference/legacy-circuit/review-characterization.md:230:adapter surface (`src/runtime/adapters/`). The shape is cited here for
docs/flows/authoring-model.md:19:- `src/runtime/compile-schematic-to-flow.ts` for schematic to compiled-flow projection.
docs/generated-surfaces.md:37:| `runtime-proof` | `internal` | `src/flows/runtime-proof/schematic.json` | `generated/flows/runtime-proof/circuit.json` | none; internal flow | none | none | Edit the flow package; host mirrors must not exist. |
commands/fix.md:123:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
docs/architecture/v2-checkpoint-4.22.md:21:- `src/runtime/config-loader.ts`
docs/architecture/v2-checkpoint-4.22.md:40:`src/runtime/config-loader.ts` is now a compatibility wrapper. Keep it until
plugins/circuit/skills/run/SKILL.md:194:- `src/runtime/router.ts` (current deterministic classifier)
scripts/release/emit-current-capabilities.mjs:499:    evidence: ['src/runtime/router.ts'],
scripts/release/emit-current-capabilities.mjs:544:    evidence: ['src/schemas/connector.ts', 'src/runtime/relay-selection.ts'],
scripts/release/emit-current-capabilities.mjs:702:      evidence: ['src/runtime/runner.ts', 'src/cli/circuit.ts'],
scripts/release/emit-current-capabilities.mjs:717:      evidence: ['src/runtime/snapshot-writer.ts', 'src/runtime/runner.ts', 'src/cli/handoff.ts'],
scripts/release/emit-current-capabilities.mjs:733:      evidence: ['src/runtime/router.ts', 'tests/contracts/flow-router.test.ts'],
scripts/release/emit-current-capabilities.mjs:777:        'src/runtime/write-capable-worker-disclosure.ts',
scripts/release/emit-current-capabilities.mjs:778:        'src/runtime/runner.ts',
scripts/release/emit-current-capabilities.mjs:779:        'src/runtime/operator-summary-writer.ts',
scripts/release/emit-current-capabilities.mjs:800:      evidence: ['src/runtime/compile-schematic-to-flow.ts'],
docs/architecture/v2-checkpoint-4.16.md:23:`src/runtime/connectors/shared.ts` remains as a compatibility surface for those
docs/architecture/v2-checkpoint-4.16.md:31:Connector-only helpers remain in `src/runtime/connectors/shared.ts`:
src/flows/build/writers/plan.ts:10:} from '../../../runtime/registries/compose-writers/types.js';
scripts/release/capture-golden-run-proofs.mjs:16:import { writeComposeReport } from '../../dist/runtime/runner.js';
plugins/circuit/skills/build/SKILL.md:121:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
src/flows/build/writers/verification.ts:10:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/build/writers/verification.ts:16:} from '../../../runtime/registries/verification-writers/types.js';
src/flows/build/writers/close.ts:8:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/build/writers/close.ts:12:} from '../../../runtime/registries/close-writers/types.js';
docs/architecture/v2-migration-plan.md:12:`src/runtime/`, `src/cli/`, `src/schemas/`, `src/flows/`, `docs/contracts/`,
docs/architecture/v2-migration-plan.md:128:`src/runtime/compile-schematic-to-flow.ts`, `src/schemas/step.ts`, flow
docs/architecture/v2-migration-plan.md:176:Files likely involved: old `src/runtime/*`, old runner imports, CLI runtime
plugins/circuit/skills/explore/SKILL.md:116:- `src/runtime/` (current runner)
src/flows/build/writers/checkpoint-brief.ts:22:} from '../../../runtime/registries/checkpoint-writers/types.js';
docs/architecture/v2-checkpoint-4.12.md:23:`src/runtime/relay-selection.ts` re-exports those helpers for compatibility.
docs/architecture/v2-checkpoint-4.12.md:29:`src/runtime/relay-selection.ts` still owns retained relayer resolution,
scripts/release/lib.mjs:103:  return import(resolve(projectRoot, 'dist/runtime/router.js'));
docs/architecture/v2-connector-materializer-plan.md:11:- `src/runtime/connectors/shared.ts` is now a compatibility re-export surface.
docs/architecture/v2-connector-materializer-plan.md:20:| `src/runtime/connectors/claude-code.ts` | retained relay selection, core-v2 relay bridge, connector smoke tests, old runner tests | Owns Claude CLI argv, tool-surface restrictions, timeout and process-group kill behavior, stdout/stderr caps, provider/model/effort compatibility, JSON extraction at connector edge | Produces the shared `RelayResult` shape; does not write relay transcript files directly | `tests/runner/agent-connector-smoke.test.ts`, `tests/runner/agent-relay-roundtrip.test.ts`, `tests/runner/explore-e2e-parity.test.ts`, `tests/contracts/connector-schema.test.ts`, full `npm run verify` | Keep in `src/runtime/connectors/` until a dedicated connector-safety move is reviewed |
docs/architecture/v2-connector-materializer-plan.md:21:| `src/runtime/connectors/codex.ts` | core-v2 relay bridge, retained relay selection, Codex connector contract tests, Codex smoke tests | Owns Codex CLI argv, read-only sandbox policy, forbidden argv checks, version capture, JSONL parse discipline, timeout and process-group kill behavior, provider/model/effort compatibility | Produces the shared `RelayResult` shape; does not write relay transcript files directly | `tests/contracts/codex-connector-schema.test.ts`, `tests/runner/codex-connector-smoke.test.ts`, `tests/runner/codex-relay-roundtrip.test.ts`, full `npm run verify` | Keep in `src/runtime/connectors/` until a dedicated connector-safety move is reviewed |
docs/architecture/v2-connector-materializer-plan.md:22:| `src/runtime/connectors/custom.ts` | core-v2 relay bridge, retained relay selection, custom connector tests | Owns configured command invocation, prompt-file transport, temp-dir lifecycle, timeout and process-group kill behavior, output-size caps, JSON extraction at connector edge | Produces the shared `RelayResult` shape; writes temporary prompt/output files only, then removes the temp directory | `tests/runner/custom-connector-runtime.test.ts`, CLI custom connector precedence tests, full `npm run verify` | Keep in `src/runtime/connectors/` until custom connector execution policy is reviewed |
docs/architecture/v2-connector-materializer-plan.md:23:| `src/runtime/connectors/relay-materializer.ts` | retained relay handler tests, relay provenance tests, run-relative path tests, live smoke roundtrip tests | Owns translation from validated connector result to trace entries and durable relay slots; cross-checks role/provenance consistency | Writes request, receipt, result, and optional report files; emits the durable relay transcript sequence | `tests/runner/agent-relay-roundtrip.test.ts`, `tests/runner/codex-relay-roundtrip.test.ts`, `tests/runner/runner-relay-provenance.test.ts`, `tests/runner/run-relative-path.test.ts`, `tests/runner/materializer-schema-parse.test.ts` | Keep until a materialization-contract plan proves byte-for-byte and trace-shape parity after a move |
docs/architecture/v2-connector-materializer-plan.md:24:| `src/runtime/connectors/shared.ts` | retained runtime imports, tests that still use the old connector surface | No subprocess behavior; compatibility only | No direct writes or trace entries | `tests/runner/connector-shared-compat.test.ts`, full `npm run verify` | Keep as a wrapper until old-path imports are migrated or intentionally retained |
docs/architecture/v2-connector-materializer-plan.md:33:- `src/runtime/connectors/codex.ts`;
docs/architecture/v2-connector-materializer-plan.md:36:- `src/runtime/connectors/shared.ts`;
docs/architecture/v2-connector-materializer-plan.md:37:- `src/runtime/connectors/relay-materializer.ts`;
docs/architecture/v2-connector-materializer-plan.md:38:- `src/runtime/runner.ts`;
docs/architecture/v2-connector-materializer-plan.md:39:- `src/runtime/registries/report-schemas.ts`.
docs/architecture/v2-connector-materializer-plan.md:43:- `src/runtime/connectors/claude-code.ts`;
docs/architecture/v2-connector-materializer-plan.md:46:- `src/runtime/connectors/shared.ts`;
docs/architecture/v2-connector-materializer-plan.md:47:- `src/runtime/connectors/relay-materializer.ts`;
docs/architecture/v2-connector-materializer-plan.md:48:- `src/runtime/runner.ts`;
docs/architecture/v2-connector-materializer-plan.md:49:- `src/runtime/registries/report-schemas.ts`.
docs/architecture/v2-connector-materializer-plan.md:94:   src/runtime/connectors for now.
plugins/circuit/skills/fix/SKILL.md:127:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
src/flows/sweep/relay-hints.ts:3:import type { SchemaShapeHint } from '../../runtime/registries/shape-hints/types.js';
plugins/circuit/commands/run.md:205:- `src/runtime/router.ts` (current deterministic classifier)
specs/reports.json:75:      "description": "Authoring-layer schematic shape for assembling reusable flow blocks into runnable compiled flows. Captures schematic steps, stage bindings, execution labels, typed evidence contracts, contract aliases, named route targets, and per-depth route_overrides. Compiled to generated/flows/<id>/circuit.json (and per-mode <mode>.json siblings) by src/runtime/compile-schematic-to-flow.ts at build time.",
specs/reports.json:252:      "trust_boundary": "operator-local derived state; state.json is written only by the reducer-derived snapshot writer at src/runtime/snapshot-writer.ts (never by step executors). A byte-match against a fresh reducer pass over run.trace is the re-entry check. Slice 27c lands the writer; re-entry byte-match enforcement in resume lands in Slice 27d+ per plan.",
specs/reports.json:279:      "trust_boundary": "operator-local persisted state; written once at bootstrap by the manifest snapshot writer at src/runtime/manifest-snapshot-writer.ts. Hash algorithm: SHA-256 over the exact persisted manifest snapshot bytes (`algorithm: 'sha256-raw'`), per ADR-0001 Addendum B §Stage 1.5 Close Criteria #8. Parse-time superRefine rejects any snapshot whose declared hash disagrees with sha256 over decoded bytes_base64; a second reader cannot be tricked into accepting a tampered byte-body under the declared hash.",
specs/reports.json:832:      "trust_boundary": "engine-computed at Close by the registered explore.result@v1 compose writer from schema-parsed compose.json and review-verdict.json plus flow-declared evidence link paths; terminal report — no in-run readers; cross-run reader is the run result consumer only; path-distinct from run.result so the engine's result-writer (src/runtime/result-writer.ts RESULT-I1 — single writer to result.json) and the orchestrator's close-step (flow-semantic aggregate at explore-result.json) do not collide",
generated/release/current-capabilities.json:520:      "evidence": ["src/schemas/connector.ts", "src/runtime/relay-selection.ts"],
generated/release/current-capabilities.json:536:      "evidence": ["src/schemas/connector.ts", "src/runtime/relay-selection.ts"],
generated/release/current-capabilities.json:552:      "evidence": ["src/schemas/connector.ts", "src/runtime/relay-selection.ts"],
generated/release/current-capabilities.json:569:      "evidence": ["src/runtime/runner.ts", "src/cli/circuit.ts"],
generated/release/current-capabilities.json:586:      "evidence": ["src/runtime/snapshot-writer.ts", "src/runtime/runner.ts", "src/cli/handoff.ts"],
generated/release/current-capabilities.json:603:      "evidence": ["src/runtime/router.ts", "tests/contracts/flow-router.test.ts"],
generated/release/current-capabilities.json:1647:      "evidence": ["src/runtime/compile-schematic-to-flow.ts"],
generated/release/current-capabilities.json:1662:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1677:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1692:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1707:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1722:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1737:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1752:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1806:        "src/runtime/write-capable-worker-disclosure.ts",
generated/release/current-capabilities.json:1807:        "src/runtime/runner.ts",
generated/release/current-capabilities.json:1808:        "src/runtime/operator-summary-writer.ts"
docs/architecture/v2-deletion-plan.md:50:| `src/runtime/runner.ts` | retained execution path | The CLI still imports `runCompiledFlow` for unsupported modes, rollback, arbitrary fixtures, `composeWriter`, and checkpoint resume. Release proof scripts and many runner tests still use it. |
docs/architecture/v2-deletion-plan.md:51:| `src/runtime/runner-types.ts` | compatibility re-export plus retained runtime types | core-v2 imports shared relay/progress/run callback types from `src/shared/relay-runtime-types.ts`. Keep this file until retained runtime and tests stop importing the old surface. |
docs/architecture/v2-deletion-plan.md:52:| `src/runtime/step-handlers/checkpoint.ts` | checkpoint pause/resume and retained checkpoint modes | v2 handles fresh safe checkpoint choices, but checkpoint waiting and resume stay retained-runtime-owned. |
docs/architecture/v2-deletion-plan.md:53:| `src/runtime/step-handlers/compose.ts` | retained fallback and programmatic compose writer hook | core-v2 uses catalog writers, but `main(..., { composeWriter })` intentionally falls back to retained runtime. |
docs/architecture/v2-deletion-plan.md:54:| `src/runtime/step-handlers/relay.ts` | retained relay handler and oracle tests | core-v2 no longer imports this file directly, but retained runtime and handler tests still do. |
docs/architecture/v2-deletion-plan.md:55:| `src/runtime/step-handlers/sub-run.ts` | retained fallback and oracle tests | core-v2 has sub-run coverage, but unsupported fallback paths and old tests still rely on the old handler. |
docs/architecture/v2-deletion-plan.md:56:| `src/runtime/step-handlers/fanout.ts` and `src/runtime/step-handlers/fanout/*` | retained fallback and fanout oracle tests | core-v2 has fanout slices, but old fanout behavior remains the comparison oracle. |
docs/architecture/v2-deletion-plan.md:57:| `src/runtime/step-handlers/verification.ts` | retained fallback and verification oracle tests | core-v2 can run flow-owned verification writers, but old verification tests remain useful until migration. |
docs/architecture/v2-deletion-plan.md:58:| `src/runtime/step-handlers/recovery-route.ts` | retained runner recovery behavior | core-v2 has bounded recovery tests, but old runner tests still cover the retained path. |
docs/architecture/v2-deletion-plan.md:59:| `src/runtime/step-handlers/shared.ts`, `src/runtime/step-handlers/types.ts`, `src/runtime/step-handlers/index.ts` | retained handler support | Delete only with the old handler cluster. |
docs/architecture/v2-deletion-plan.md:67:These files live under `src/runtime/`, but they are not simply old graph-runner
docs/architecture/v2-deletion-plan.md:72:| `src/runtime/compile-schematic-to-flow.ts` | keep / compiler infrastructure | `scripts/emit-flows.mjs`, compiler tests, and generated flow output still use it. |
docs/architecture/v2-deletion-plan.md:73:| `src/runtime/catalog-derivations.ts` | keep / catalog infrastructure | Router, generated surfaces, and catalog tests depend on catalog-derived data. |
docs/architecture/v2-deletion-plan.md:74:| `src/runtime/registries/**` | keep / later move | Flow packages, v2 report validation, writer discovery, cross-report validators, and shape hints depend on these registries. |
docs/architecture/v2-deletion-plan.md:75:| `src/runtime/connectors/**` | keep / later move | core-v2 reuses real connector subprocesses, relay materialization, and argv validation. The relay data/hash surface moved to `src/shared/connector-relay.ts` in Phase 4.16, and connector parsing/model helpers moved to `src/shared/connector-helpers.ts` in Phase 4.17. Subprocess modules and materialization remain production safety infrastructure. |
docs/architecture/v2-deletion-plan.md:76:| `src/runtime/relay-support.ts` | compatibility re-export | Relay prompt and check helpers moved to `src/shared/relay-support.ts` in Phase 4.13. Keep this wrapper until retained relay handler imports and old tests stop using the old path. |
docs/architecture/v2-deletion-plan.md:77:| `src/runtime/config-loader.ts` | compatibility re-export | Config discovery moved to `src/shared/config-loader.ts` in Phase 4.22. Keep this wrapper until old-path tests and external imports stop using it. |
docs/architecture/v2-deletion-plan.md:78:| `src/runtime/router.ts` | keep / later move | Natural-language flow selection still uses the current router. |
docs/architecture/v2-deletion-plan.md:79:| `src/runtime/relay-selection.ts` | retained relay decision bridge | Selection-depth helpers moved to `src/shared/relay-selection.ts` in Phase 4.12. Keep this file for retained relayer resolution, connector bridge behavior, old relay handler imports, and relay provenance tests. |
docs/architecture/v2-deletion-plan.md:80:| `src/runtime/selection-resolver.ts` | compatibility re-export | Selection precedence logic moved to `src/shared/selection-resolver.ts` in Phase 4.11. Keep this wrapper until retained runtime tests and external imports stop using the old path. |
docs/architecture/v2-deletion-plan.md:81:| `src/runtime/result-writer.ts` | retain until old result tests migrate | core-v2 has its own result writer, but retained runtime and old result tests still use this one. |
docs/architecture/v2-deletion-plan.md:82:| `src/runtime/manifest-snapshot-writer.ts` | compatibility re-export | Manifest snapshot byte-match helper moved to `src/shared/manifest-snapshot.ts` in Phase 4.20. Keep this wrapper while retained runner and old snapshot tests use the old path. |
docs/architecture/v2-deletion-plan.md:83:| `src/runtime/snapshot-writer.ts` | retain for state snapshots and continuity | Used by retained runner, checkpoint handler, `append-and-derive`, `cli/handoff`, event-log round-trip tests, fresh-run-root tests, release evidence, and state snapshot behavior. |
docs/architecture/v2-deletion-plan.md:84:| `src/runtime/operator-summary-writer.ts` | compatibility re-export | Operator summary writing moved to `src/shared/operator-summary-writer.ts` in Phase 4.21. Keep this wrapper until old-path tests and release evidence stop using it. |
docs/architecture/v2-deletion-plan.md:85:| `src/runtime/run-status-projection.ts` | keep | This is now the compatibility projector for both v1 and v2 run folders. |
docs/architecture/v2-deletion-plan.md:86:| `src/runtime/progress-projector.ts` | retained trace-to-progress projection | core-v2 imports shared helpers from `src/shared/progress-output.ts`. Keep this file for old trace projection, retained runtime imports, and old progress tests. |
docs/architecture/v2-deletion-plan.md:87:| `src/runtime/reducer.ts`, `src/runtime/append-and-derive.ts`, `src/runtime/trace-reader.ts`, `src/runtime/trace-writer.ts` | retain until trace/projection tests migrate | Old trace infrastructure remains the v1 oracle and status/progress source for retained runs. |
docs/architecture/v2-deletion-plan.md:88:| `src/runtime/policy/flow-kind-policy.ts` | compatibility re-export | Flow-kind policy moved to `src/shared/flow-kind-policy.ts` in Phase 4.19. Keep this wrapper until old-path imports and documentation references stop using it. |
docs/architecture/v2-deletion-plan.md:89:| `src/runtime/write-capable-worker-disclosure.ts` | compatibility re-export | Disclosure helper moved to `src/shared/write-capable-worker-disclosure.ts` in Phase 4.14. Keep this wrapper while retained runtime and operator summary imports use the old path. |
docs/architecture/v2-deletion-plan.md:90:| `src/runtime/run-relative-path.ts` | compatibility re-export | Run-relative path helper moved to `src/shared/run-relative-path.ts` in Phase 4.15. Keep this wrapper while retained runtime, connector materialization, old handlers, projection, and operator summary imports use the old path. |
docs/architecture/v2-deletion-plan.md:97:../runtime
docs/architecture/v2-deletion-plan.md:98:../../runtime
docs/architecture/v2-deletion-plan.md:99:runtime/
docs/architecture/v2-deletion-plan.md:107:| `runtime/runner` | `src/cli/circuit.ts`, release proof script, many `tests/runner/*`, selected contract tests | retained execution | Keep until unsupported modes, rollback, `composeWriter`, fixtures, and checkpoint resume have explicit replacement or retained-module ownership. |
docs/architecture/v2-deletion-plan.md:108:| `runtime/runner-types` | retained runtime, `src/cli/circuit.ts`, tests | compatibility re-export | core-v2 no longer imports this file. Keep until retained runtime and tests stop importing the old type surface. |
docs/architecture/v2-deletion-plan.md:109:| `runtime/step-handlers` | direct handler tests and retained runner | retained execution oracle | Migrate tests only after v2 owns the behavior or the behavior stays retained by policy. |
docs/architecture/v2-deletion-plan.md:110:| `runtime/registries` | flow packages, core-v2 report validation, tests | live infrastructure | Move to neutral flow-package infrastructure before deleting any runtime namespace. |
docs/architecture/v2-deletion-plan.md:111:| `runtime/connectors` | core-v2 relay bridge, retained runtime, connector tests | live connector infrastructure | Keep. Shared relay data/hash ownership moved to `src/shared/connector-relay.ts`, and connector helper ownership moved to `src/shared/connector-helpers.ts`, but subprocess modules and materialization remain production safety infrastructure. |
docs/architecture/v2-deletion-plan.md:112:| `runtime/relay-support` | old relay handler and compatibility imports | compatibility re-export | core-v2 no longer imports this file. Shared helper ownership now lives in `src/shared/relay-support.ts`. |
docs/architecture/v2-deletion-plan.md:113:| `runtime/relay-selection` | retained relay handler, old runner, and old relay tests | retained relay decision bridge | core-v2 no longer imports this file. Keep until retained relayer resolution and connector bridge behavior move or stay behind an explicit retained module. |
docs/architecture/v2-deletion-plan.md:114:| `runtime/selection-resolver` | retained tests and compatibility imports | compatibility re-export | Neutral ownership now lives in `src/shared/selection-resolver.ts`; keep wrapper until old-path imports migrate. |
docs/architecture/v2-deletion-plan.md:176:find src/runtime -type f | sort
docs/architecture/v2-deletion-plan.md:177:rg -n "from ['\"].*runtime/|../runtime|../../runtime|runtime/" src tests scripts docs specs package.json
docs/architecture/v2-deletion-plan.md:191:| Move shared relay/progress types out of `src/runtime/runner-types.ts` | Done in Phase 4.9 for `RelayFn`, `RelayInput`, `ProgressReporter`, and `RuntimeEvidencePolicy`. `runner-types.ts` remains as a compatibility re-export plus retained runtime invocation/result types. | Keep full validation green while retained runtime and tests continue importing the old surface. |
docs/architecture/v2-deletion-plan.md:192:| Move progress helper functions out of `src/runtime/progress-projector.ts` | Done in Phase 4.10 for `progressDisplay` and `reportProgress`. `progress-projector.ts` re-exports them for compatibility and still owns old trace-to-progress projection. | Keep progress schema tests, old progress-projector tests, CLI v2 progress tests, and full validation green. |
docs/architecture/v2-deletion-plan.md:193:| Move relay selection support to a neutral module | Mostly done in Phases 4.11 and 4.12 for selection ownership: `src/shared/selection-resolver.ts` owns `resolveSelectionForRelay`, and `src/shared/relay-selection.ts` owns depth-bound selection derivation. `src/runtime/relay-selection.ts` remains for retained relayer resolution and connector bridge behavior. | Config loader tests, selection contract tests, relay provenance tests, core-v2 connector tests, CLI custom connector precedence tests, full `npm run verify`. |
docs/architecture/v2-deletion-plan.md:194:| Move run-relative path helper out of `src/runtime/run-relative-path.ts` | Done in Phase 4.15 for `resolveRunRelative`. Flow writers and shared relay support now import `src/shared/run-relative-path.ts`; the runtime file remains a compatibility re-export for retained runtime surfaces. | Keep run-relative path containment tests, materializer tests, report writer tests, CLI v2 tests, and full validation green. |
docs/architecture/v2-deletion-plan.md:195:| Move connector relay data/hash helper out of `src/runtime/connectors/shared.ts` | Done in Phase 4.16 for `ConnectorRelayInput`, `RelayResult`, and `sha256Hex`. `src/runtime/connectors/shared.ts` remains for compatibility re-exports plus connector-only parsing/model helpers. | Keep connector wrapper compatibility tests, relay/materializer tests, connector selection tests, connector smoke source fingerprint lists, and full validation green. |
docs/architecture/v2-deletion-plan.md:196:| Move connector-only helpers out of `src/runtime/connectors/shared.ts` | Done in Phase 4.17 for `selectedModelForProvider` and `extractJsonObject`. `src/runtime/connectors/shared.ts` remains as a compatibility re-export surface. | Keep connector helper compatibility tests, extraction tests, connector smoke source fingerprint lists, subprocess connector smoke tests, and full validation green. |
docs/architecture/v2-deletion-plan.md:198:| Move flow-kind policy wrapper out of `src/runtime/policy/flow-kind-policy.ts` | Done in Phase 4.19. The neutral wrapper lives in `src/shared/flow-kind-policy.ts`; the runtime path remains a compatibility re-export. | Keep flow-kind policy tests, CLI fixture policy tests, generated-surface drift checks, and full validation green. |
docs/architecture/v2-deletion-plan.md:199:| Move manifest snapshot helper out of `src/runtime/manifest-snapshot-writer.ts` | Done in Phase 4.20. The byte-match implementation lives in `src/shared/manifest-snapshot.ts`; the runtime path remains a compatibility re-export. | Keep event-log round-trip tests, run-status projection tests, fresh-run-root tests, handoff tests, and full validation green. |
docs/architecture/v2-deletion-plan.md:200:| Move operator summary writer out of `src/runtime/operator-summary-writer.ts` | Done in Phase 4.21. The implementation lives in `src/shared/operator-summary-writer.ts`; the runtime path remains a compatibility re-export. | Keep operator summary tests, CLI v2 runtime tests, release evidence checks, and full validation green. |
docs/architecture/v2-deletion-plan.md:201:| Move config loader out of `src/runtime/config-loader.ts` | Done in Phase 4.22. The schema-backed config discovery implementation lives in `src/shared/config-loader.ts`; the runtime path remains a compatibility re-export. | Keep config-loader tests, CLI v2 runtime tests, connector selection tests, and full validation green. |
scripts/emit-flows.mjs:5:// src/runtime/compile-schematic-to-flow.ts (consumed here through
scripts/emit-flows.mjs:644:  // dist/runtime/compile-schematic-to-flow.js is produced by `npm run
scripts/emit-flows.mjs:647:  const distPath = resolve(projectRoot, 'dist/runtime/compile-schematic-to-flow.js');
plugins/circuit/commands/build.md:116:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
tests/properties/visible/flow-router-tiebreak.test.ts:3:// src/runtime/router.ts.
tests/properties/visible/flow-router-tiebreak.test.ts:32:import type { RoutablePackage } from '../../../src/runtime/catalog-derivations.js';
tests/properties/visible/flow-router-tiebreak.test.ts:33:import { classifyTaskAgainstRoutables } from '../../../src/runtime/router.js';
docs/architecture/v2-checkpoint-4.7.md:49:Several files under `src/runtime/` are not old execution code and should be
src/cli/circuit.ts:18:import { classifyCompiledFlowTask } from '../runtime/router.js';
src/cli/circuit.ts:26:} from '../runtime/runner.js';
src/flows/sweep/cross-report-validators.ts:19:} from '../../runtime/registries/close-writers/shared.js';
src/flows/sweep/cross-report-validators.ts:20:import type { CrossReportResult } from '../../runtime/registries/cross-report-validators.js';
src/flows/review/relay-hints.ts:10:import type { StructuralShapeHint } from '../../runtime/registries/shape-hints/types.js';
tests/properties/visible/cross-report-validator.test.ts:16:import { reportPathForSchemaInCompiledFlow } from '../../../src/runtime/registries/close-writers/shared.js';
tests/properties/visible/cross-report-validator.test.ts:17:import { runCrossReportValidator } from '../../../src/runtime/registries/cross-report-validators.js';
docs/architecture/v2-checkpoint-4.13.md:24:`src/runtime/relay-support.ts` remains as a compatibility re-export.
docs/architecture/v2-checkpoint-4.13.md:33:- `src/runtime/registries/shape-hints/registry.ts`
docs/architecture/v2-checkpoint-4.13.md:34:- `src/runtime/run-relative-path.ts`
plugins/circuit/commands/explore.md:110:- `src/runtime/` (current runner)
src/cli/handoff.ts:6:import { deriveSnapshot } from '../runtime/snapshot-writer.js';
tests/properties/visible/fanout-join-policy.test.ts:3:// `evaluateFanoutJoinPolicy` helper in src/runtime/step-handlers/fanout.ts.
tests/properties/visible/fanout-join-policy.test.ts:33:} from '../../../src/runtime/step-handlers/fanout.js';
src/flows/review/writers/intake.ts:14:} from '../../../runtime/registries/compose-writers/types.js';
src/cli/runs.ts:4:} from '../runtime/run-status-projection.js';
src/flows/review/writers/result.ts:14:} from '../../../runtime/registries/compose-writers/types.js';
docs/architecture/v2-checkpoint-4.6.md:60:fresh runs; it only includes runtime/runtime_reason fields in CLI JSON output.
src/flows/sweep/writers/queue.ts:12:} from '../../../runtime/registries/compose-writers/types.js';
plugins/circuit/commands/fix.md:122:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
docs/architecture/v2-checkpoint-4.17.md:22:`src/runtime/connectors/shared.ts` remains as a compatibility surface for those
src/flows/sweep/writers/verification.ts:12:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/sweep/writers/verification.ts:18:} from '../../../runtime/registries/verification-writers/types.js';
src/flows/migrate/relay-hints.ts:3:import type { SchemaShapeHint } from '../../runtime/registries/shape-hints/types.js';
docs/architecture/v2-checkpoint-4.2.md:36:The complex flows still have direct v2 runtime/parity coverage, but the CLI
src/flows/sweep/writers/close.ts:11:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/sweep/writers/close.ts:15:} from '../../../runtime/registries/close-writers/types.js';
tests/unit/compile-schematic-per-mode.test.ts:10:import { compileSchematicToCompiledFlow } from '../../src/runtime/compile-schematic-to-flow.js';
src/schemas/result.ts:15:// src/runtime/result-writer.ts); this schema only enforces shape.
tests/contracts/terminology-product-surface.test.ts:174:        'internal/runtime names belong inside backticks or fenced code,',
tests/contracts/terminology-product-surface.test.ts:214:    expect(raw).not.toMatch(/\bsrc\/runtime\/compile-recipe-to-flow\.ts\b/);
tests/contracts/terminology-product-surface.test.ts:219:    expect(raw).toMatch(/\bsrc\/runtime\/compile-schematic-to-flow\.ts\b/);
docs/architecture/v2-checkpoint-4.md:30:- `src/runtime/runner.ts`
docs/architecture/v2-checkpoint-4.md:31:- `src/runtime/runner-types.ts`
docs/architecture/v2-checkpoint-4.md:32:- `src/runtime/step-handlers/checkpoint.ts`
docs/architecture/v2-checkpoint-4.md:33:- `src/runtime/step-handlers/compose.ts`
docs/architecture/v2-checkpoint-4.md:34:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-checkpoint-4.md:35:- `src/runtime/step-handlers/sub-run.ts`
docs/architecture/v2-checkpoint-4.md:36:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-checkpoint-4.md:37:- `src/runtime/step-handlers/fanout/aggregate.ts`
docs/architecture/v2-checkpoint-4.md:38:- `src/runtime/step-handlers/fanout/branch-resolution.ts`
docs/architecture/v2-checkpoint-4.md:39:- `src/runtime/step-handlers/fanout/join-policy.ts`
docs/architecture/v2-checkpoint-4.md:40:- `src/runtime/step-handlers/fanout/types.ts`
docs/architecture/v2-checkpoint-4.md:41:- `src/runtime/step-handlers/verification.ts`
docs/architecture/v2-checkpoint-4.md:42:- `src/runtime/step-handlers/recovery-route.ts`
docs/architecture/v2-checkpoint-4.md:43:- `src/runtime/step-handlers/shared.ts`
docs/architecture/v2-checkpoint-4.md:44:- `src/runtime/step-handlers/types.ts`
docs/architecture/v2-checkpoint-4.md:46:The deletion should be a narrow approved slice, not a whole-tree `src/runtime/`
docs/architecture/v2-checkpoint-4.md:53:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-checkpoint-4.md:54:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-checkpoint-4.md:55:- `src/runtime/registries/**`
docs/architecture/v2-checkpoint-4.md:56:- `src/runtime/connectors/**`
docs/architecture/v2-checkpoint-4.md:57:- `src/runtime/config-loader.ts`
docs/architecture/v2-checkpoint-4.md:58:- `src/runtime/router.ts`
docs/architecture/v2-checkpoint-4.md:59:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.md:60:- `src/runtime/snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.md:61:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-checkpoint-4.md:62:- `src/runtime/progress-projector.ts`
docs/architecture/v2-checkpoint-4.md:63:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-checkpoint-4.md:64:- `src/runtime/reducer.ts`
docs/architecture/v2-checkpoint-4.md:65:- `src/runtime/trace-reader.ts`
docs/architecture/v2-checkpoint-4.md:66:- `src/runtime/trace-writer.ts`
docs/architecture/v2-checkpoint-4.md:67:- `src/runtime/append-and-derive.ts`
docs/architecture/v2-checkpoint-4.md:68:- `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-checkpoint-4.md:69:- `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-checkpoint-4.md:70:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-checkpoint-4.md:82:| `runtime/runner` | production CLI, release proof script, old runner tests, a few contract tests | replace with v2 before deleting runner |
docs/architecture/v2-checkpoint-4.md:83:| `runtime/step-handlers` | direct handler tests and property tests | delete or rewrite after v2 executor coverage is accepted |
docs/architecture/v2-checkpoint-4.md:84:| `runtime/registries` | flow packages, writer types, report schema helpers, catalog tests | retain or move before whole-runtime cleanup |
docs/architecture/v2-checkpoint-4.md:85:| `runtime/catalog-derivations` | catalog and router tests | retain or move |
docs/architecture/v2-checkpoint-4.md:86:| `runtime/compile-schematic-to-flow` | emit script and compiler tests | retain until compiler replacement |
docs/architecture/v2-checkpoint-4.md:87:| `runtime/relay-selection` | old relay provenance tests | replace with v2 connector/config tests |
docs/architecture/v2-checkpoint-4.md:88:| `runtime/selection-resolver` | flow model/effort contract test | replace with v2 config precedence tests |
docs/architecture/v2-checkpoint-4.md:94:rg -n "runCompiledFlow|executeCompiledFlow|compileSchematicToFlow|CompiledFlow|flow-schematic|runtime/runner|runtime/step-handlers|runtime/catalog-derivations|runtime/registries|relay-selection|selection-resolver" src tests docs specs scripts commands plugins .claude-plugin generated README.md package.json
docs/architecture/v2-checkpoint-4.md:95:rg -n "from ['\"].*runtime/(runner|step-handlers|catalog-derivations|registries|relay-selection|selection-resolver)|from ['\"].*runtime/(compile-schematic-to-flow)" src tests scripts
docs/architecture/v2-checkpoint-4.md:96:rg -l "from ['\"].*runtime/runner" src tests scripts
docs/architecture/v2-checkpoint-4.md:97:rg -l "from ['\"].*runtime/step-handlers" src tests scripts
docs/architecture/v2-checkpoint-4.md:98:rg -l "from ['\"].*runtime/registries" src tests scripts
docs/architecture/v2-checkpoint-4.md:99:rg -l "from ['\"].*runtime/(catalog-derivations|relay-selection|selection-resolver|compile-schematic-to-flow)" src tests scripts
docs/architecture/v2-checkpoint-4.md:209:- Deleting all of `src/runtime/` would remove live compiler/catalog/report/config
src/flows/sweep/writers/brief.ts:12:} from '../../../runtime/registries/compose-writers/types.js';
tests/contracts/flow-router.test.ts:3:import { ROUTABLE_WORKFLOWS, classifyCompiledFlowTask } from '../../src/runtime/router.js';
docs/architecture/v2-rigor-audit.md:11:| Trace sequence authority | `src/runtime/runner.ts`, `src/schemas/run.ts`, `docs/contracts/run.md` | Trace corruption, duplicate sequence numbers, status projection drift | Reducer, progress projector, run status, reports | Runner `push()` assigns sequence numbers before append | keep | `trace/trace-store.ts` | `tests/runner/push-sequence-authority.test.ts`, `tests/contracts/runtrace-schema.test.ts` | One component must own sequence assignment. |
docs/architecture/v2-rigor-audit.md:12:| Run bootstrap rules | `src/runtime/runner.ts`, `src/schemas/run.ts`, `docs/contracts/run.md` | Ambiguous run identity, missing manifest snapshot, invalid resume base | CLI, run reducer, status reader | `run.bootstrapped` first entry, manifest snapshot writer, strict trace schema | keep | `run/run-context.ts` and trace store | Run trace schema tests, status projection tests | Bootstrap should stay explicit and single. |
docs/architecture/v2-rigor-audit.md:13:| Run close rules | `src/runtime/runner.ts`, `src/runtime/result-writer.ts`, `src/schemas/run.ts` | Runs that keep accepting entries after completion, wrong terminal result | CLI, status projection, operator summary | `run.closed`, result writer, trace close validation | keep | `run/graph-runner.ts` and `run/result-writer.ts` | Run trace and runner tests | Close should be a graph-runner responsibility, with result writing isolated. |
docs/architecture/v2-rigor-audit.md:14:| Resume rules | `src/runtime/runner.ts`, checkpoint handler, run status projection | Resuming the wrong checkpoint, stale request reuse, mismatched manifest | CLI resume path, checkpoint waiting state | Saved manifest, checkpoint request validation, resume choice checks | keep | `run/resume.ts` | Checkpoint and status projection tests | Keep behavior. Split resume from main runner. |
docs/architecture/v2-rigor-audit.md:15:| Connector capability rules | `docs/contracts/connector.md`, `src/schemas/connector.ts`, `src/runtime/connectors/` | Wrong connector writes, sandbox bypass, unsafe argv, unknown provider effort | Relay runtime, config resolution, tests | Schema checks, argv guards, subprocess flags, provider effort allowlists | keep | `connectors/resolver.ts` and connector modules | Connector schema, Codex, custom connector, identity tests | This is load-bearing and should not be loosened for migration speed. |
docs/architecture/v2-rigor-audit.md:16:| Selection/config precedence | `src/runtime/selection-resolver.ts`, `src/runtime/relay-selection.ts`, `docs/contracts/selection.md`, `docs/contracts/config.md` | Ambiguous model/effort/connector choice, hidden overrides | Relay prompt builder, CLI config loader | Layered config fold with applied provenance | keep | `domain/selection.ts` plus connector resolver | Config loader and selection tests | Preserve precedence. Simplify by making provenance a v2 first-class value. |
docs/architecture/v2-rigor-audit.md:18:| Schematic step validation | `src/schemas/flow-schematic.ts`, `src/runtime/compile-schematic-to-flow.ts` | Missing kind-specific fields, invalid reads/writes/checks | Compiler, flow packages | Flat optional authoring shape plus manual cross-field validation | simplify | Phase 5 authoring schemas, then adapter/compiler output validation | Flow schematic and compiler tests | Keep validation strength, reduce optional-field reasoning. |
docs/architecture/v2-rigor-audit.md:21:| Report schema validation | Flow package `reports.ts`, `src/runtime/registries/*`, connector materializer | Invalid report trusted downstream, bad relay result accepted | Relay executor, report readers, generated manifests | Flow-owned schemas and runtime parsing | keep | Flow-owned validators called by executors | Flow report schema tests and relay tests | Preserve flow package ownership. |
docs/architecture/v2-rigor-audit.md:22:| Checkpoint behavior | `src/runtime/step-handlers/checkpoint.ts`, checkpoint writers, Build writer | Bad pause/resume, wrong auto-resolution, invalid checkpoint report | Runner, CLI resume, status projection | Handler policy, checkpoint files, trace entries, flow-owned writers | simplify | `executors/checkpoint.ts`, `run/resume.ts`, flow-owned policy | Checkpoint handler, Build checkpoint tests | Preserve behavior but remove generic knowledge of Build-specific report shape. |
docs/architecture/v2-rigor-audit.md:23:| Fanout behavior | `src/runtime/step-handlers/fanout.ts`, `src/runtime/step-handlers/fanout/*` | Branch loss, partial failure mishandling, missing aggregate report, leaked worktree | Explore and Sweep flows, run status, report consumers | Large handler plus helper modules | simplify | `fanout/branch-expansion.ts`, `branch-execution.ts`, `worktree.ts`, `join-policy.ts`, `aggregate-report.ts`, `cleanup.ts` | Fanout runtime and property tests | Behavior is load-bearing; file shape needs decomposition. |
docs/architecture/v2-rigor-audit.md:24:| Sub-run behavior | `src/runtime/step-handlers/sub-run.ts` | Child run ambiguity, missing copied result, parent/child trace confusion | Migrate/Sweep flows, parent runner | Child run folder creation, child resolver, copied report/result | keep | `executors/sub-run.ts` plus `run/graph-runner.ts` child context | Sub-run runtime and recursion tests | Preserve identity and materialization rules. |
docs/architecture/v2-rigor-audit.md:26:| Runtime-proof flow | `src/flows/runtime-proof/`, generated internal flow | Runtime checks become public product shape or stale proof relic | Tests and generated internal manifest | Internal flow package | demote | Focused core-v2 test fixtures | Current catalog/generated tests | Keep only if it remains a useful internal fixture. Do not make it v2 architecture. |
docs/architecture/v2-rigor-audit.md:31:| Run file path safety | `src/schemas/scalars.ts`, `src/runtime/run-relative-path.ts`, step schema | Path traversal, symlink escape, write collision | Runtime writers, connectors, reports | Run-relative path parser and containment checks | keep | `run-files/paths.ts` and `run-file-store.ts` | Scalar and runner path tests | Keep explicit paths in executable manifests. |
docs/architecture/v2-rigor-audit.md:32:| Progress/status projection | `src/runtime/reducer.ts`, `src/runtime/progress-projector.ts`, `src/runtime/run-status-projection.ts` | Independent truth stores disagree with trace | CLI progress, run status, operator summary | Reducer and projection modules read trace and files | simplify | `projections/status.ts`, `progress.ts`, `task-state.ts`, `user-input.ts` | Progress projector and status tests | Preserve trace-first rule. Split projection from runner wording. |
docs/architecture/v2-rigor-audit.md:33:| Manifest snapshot and hash | `src/runtime/manifest-snapshot-writer.ts`, runner bootstrap | Resume against different flow bytes, impossible run audit | Resume path, status readers, tests | Snapshot writer and bootstrap metadata | keep | `manifest/` plus `run/run-context.ts` | Runner and resume tests | v2 should snapshot the executable manifest actually run. |
tests/unit/runtime/event-log-round-trip.test.ts:19:} from '../../../src/runtime/manifest-snapshot-writer.js';
tests/unit/runtime/event-log-round-trip.test.ts:20:import { reduce } from '../../../src/runtime/reducer.js';
tests/unit/runtime/event-log-round-trip.test.ts:21:import { appendAndDerive, bootstrapRun, initRunFolder } from '../../../src/runtime/runner.js';
tests/unit/runtime/event-log-round-trip.test.ts:26:} from '../../../src/runtime/snapshot-writer.js';
tests/unit/runtime/event-log-round-trip.test.ts:27:import { readRunTrace } from '../../../src/runtime/trace-reader.js';
tests/unit/runtime/event-log-round-trip.test.ts:28:import { appendTraceEntry, traceEntryLogPath } from '../../../src/runtime/trace-writer.js';
docs/architecture/v2-checkpoint-4.14.md:22:`src/runtime/write-capable-worker-disclosure.ts` remains as a compatibility
src/flows/fix/command.md:123:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
tests/unit/runtime/progress-projector.test.ts:6:import { projectTraceEntryToProgress } from '../../../src/runtime/progress-projector.js';
docs/architecture/v2-checkpoint-4.9.md:23:`src/runtime/runner-types.ts` remains as a compatibility re-export and still
docs/architecture/v2-checkpoint-4.9.md:28:core-v2 no longer imports `src/runtime/runner-types.ts` for relay/progress
docs/architecture/v2-checkpoint-4.9.md:38:`src/runtime/runner-types.ts` or `src/runtime/runner.ts`.
docs/architecture/v2-registry-ownership-plan.md:7:The current registry modules live under `src/runtime/`, but they are not old
docs/architecture/v2-registry-ownership-plan.md:18:- `src/runtime/catalog-derivations.ts`;
docs/architecture/v2-registry-ownership-plan.md:19:- `src/runtime/registries/**`.
docs/architecture/v2-registry-ownership-plan.md:22:the package shape. `src/runtime/catalog-derivations.ts` turns packages into
docs/architecture/v2-registry-ownership-plan.md:30:| `src/runtime/catalog-derivations.ts` | Pure derivation layer from flow packages to registries and routable packages | router, registry modules, catalog tests, flow-router property tests | Duplicate detection, default route selection, schema/hint derivation, and report registry construction still depend on it | `src/flows/catalog-derivations.ts` or `src/flow-packages/catalog-derivations.ts` |
docs/architecture/v2-registry-ownership-plan.md:31:| `src/runtime/registries/compose-writers/*` | Compose writer lookup and read-path resolution | retained runner, core-v2 compose executor, flow writers/tests | Flow-owned compose reports are written through this lookup in both runtimes | `src/flows/registries/compose-writers/*` |
docs/architecture/v2-registry-ownership-plan.md:32:| `src/runtime/registries/close-writers/*` | Close/result writer lookup and report-path helper | retained runner, core-v2 compose/close executor, flow close writers, cross-report validators, tests | Result writers and evidence-link path generation depend on it | `src/flows/registries/close-writers/*` |
docs/architecture/v2-registry-ownership-plan.md:33:| `src/runtime/registries/verification-writers/*` | Verification writer lookup and writer type surface | retained verification handler, core-v2 verification executor, flow verification writers, tests | Verification report writing is shared runtime behavior | `src/flows/registries/verification-writers/*` |
docs/architecture/v2-registry-ownership-plan.md:34:| `src/runtime/registries/checkpoint-writers/*` | Checkpoint brief writer lookup and writer type surface | retained checkpoint handler, core-v2 checkpoint executor, run status projection, Build checkpoint writer, tests | Checkpoint brief writing and status projection still rely on it | `src/flows/registries/checkpoint-writers/*` |
docs/architecture/v2-registry-ownership-plan.md:35:| `src/runtime/registries/report-schemas.ts` | Relay report schema parse registry | retained relay/fanout handlers, core-v2 relay executor, report composition tests, connector smoke fingerprints | Fail-closed report parsing is a runtime safety boundary | `src/flows/registries/report-schemas.ts` |
docs/architecture/v2-registry-ownership-plan.md:36:| `src/runtime/registries/cross-report-validators.ts` | Cross-report validator registry | retained relay/fanout handlers, core-v2 relay executor, Sweep validators/tests | Enforces multi-report invariants that Zod cannot express alone | `src/flows/registries/cross-report-validators.ts` |
docs/architecture/v2-registry-ownership-plan.md:37:| `src/runtime/registries/shape-hints/*` | Relay shape hint lookup | shared relay prompt support, flow relay hints, tests | Prompt materialization still depends on flow-owned shape hints | `src/flows/registries/shape-hints/*` |
docs/architecture/v2-registry-ownership-plan.md:56:infrastructure. Reducing `src/runtime/` namespace pressure should not be
docs/architecture/v2-registry-ownership-plan.md:68:2. Move type-only registry surfaces first, with `src/runtime/registries/**`
docs/architecture/v2-registry-ownership-plan.md:71:   `src/runtime/catalog-derivations.ts`.
docs/architecture/v2-checkpoint-4.1.md:42:- `src/runtime/runner.ts`
docs/architecture/v2-checkpoint-4.1.md:43:- `src/runtime/runner-types.ts`
docs/architecture/v2-checkpoint-4.1.md:44:- `src/runtime/step-handlers/checkpoint.ts`
docs/architecture/v2-checkpoint-4.1.md:45:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-checkpoint-4.1.md:46:- `src/runtime/step-handlers/verification.ts`
docs/architecture/v2-checkpoint-4.1.md:47:- `src/runtime/relay-selection.ts`
docs/architecture/v2-checkpoint-4.1.md:48:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-checkpoint-4.1.md:49:- `src/runtime/result-writer.ts`
src/flows/migrate/writers/verification.ts:12:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/migrate/writers/verification.ts:18:} from '../../../runtime/registries/verification-writers/types.js';
tests/contracts/codex-connector-schema.test.ts:15:} from '../../src/runtime/connectors/codex.js';
tests/contracts/codex-connector-schema.test.ts:22://   (A) `src/runtime/connectors/codex.ts` module shape + capability-
tests/contracts/codex-connector-schema.test.ts:40:describe('Codex connector — src/runtime/connectors/codex.ts module shape', () => {
tests/unit/emit-flows-drift.test.ts:22:const runtimeProofClaudeDir = resolve(projectRoot, '.claude-plugin/skills/runtime-proof');
tests/unit/emit-flows-drift.test.ts:23:const runtimeProofCodexDir = resolve(projectRoot, 'plugins/circuit/flows/runtime-proof');
tests/unit/emit-flows-drift.test.ts:105:    expect(combined).toContain('.claude-plugin/skills/runtime-proof');
tests/unit/emit-flows-drift.test.ts:106:    expect(combined).toContain('plugins/circuit/flows/runtime-proof');
tests/unit/emit-flows-drift.test.ts:123:      'removed internal host mirror .claude-plugin/skills/runtime-proof',
tests/unit/emit-flows-drift.test.ts:126:      'removed internal host mirror plugins/circuit/flows/runtime-proof',
docs/architecture/v2-checkpoint-4.18.md:29:- old connector shared path: `src/runtime/connectors/shared.ts` compatibility
docs/architecture/v2-checkpoint-4.18.md:34:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-checkpoint-4.18.md:35:- `src/runtime/connectors/codex.ts`
docs/architecture/v2-checkpoint-4.18.md:36:- `src/runtime/connectors/custom.ts`
docs/architecture/v2-checkpoint-4.18.md:37:- `src/runtime/connectors/relay-materializer.ts`
docs/architecture/v2-checkpoint-4.18.md:44:`src/runtime/registries/**` is shared flow-package and report infrastructure,
src/flows/migrate/writers/close.ts:14:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/migrate/writers/close.ts:18:} from '../../../runtime/registries/close-writers/types.js';
docs/architecture/v2-checkpoint-4.21.md:21:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-checkpoint-4.21.md:38:`src/runtime/operator-summary-writer.ts` is now a compatibility wrapper. Keep it
src/shared/relay-support.ts:2:import { findRelayShapeHint } from '../runtime/registries/shape-hints/registry.js';
docs/architecture/v2-checkpoint-4.19.md:21:- `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-checkpoint-4.19.md:43:`src/runtime/policy/flow-kind-policy.ts` is now a compatibility wrapper. Keep
src/flows/fix/writers/verification.ts:11:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/fix/writers/verification.ts:17:} from '../../../runtime/registries/verification-writers/types.js';
src/flows/migrate/writers/brief.ts:13:} from '../../../runtime/registries/compose-writers/types.js';
docs/architecture/v2-checkpoint-4.15.md:20:`src/runtime/run-relative-path.ts` remains as a compatibility re-export.
docs/architecture/v2-checkpoint-1.md:136:- `src/runtime/runner.ts`
docs/architecture/v2-checkpoint-1.md:137:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-checkpoint-1.md:138:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-checkpoint-1.md:139:- `src/runtime/relay-selection.ts`
docs/architecture/v2-checkpoint-1.md:140:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-checkpoint-1.md:141:- `src/runtime/reducer.ts`
docs/architecture/v2-checkpoint-1.md:142:- `src/runtime/progress-projector.ts`
docs/architecture/v2-checkpoint-1.md:143:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-checkpoint-1.md:144:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-checkpoint-1.md:145:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-1.md:146:- `src/runtime/router.ts`
docs/architecture/v2-checkpoint-1.md:147:- `src/runtime/connectors/codex.ts`
docs/architecture/v2-checkpoint-1.md:148:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-checkpoint-1.md:149:- `src/runtime/connectors/custom.ts`
docs/architecture/v2-checkpoint-1.md:150:- `src/runtime/step-handlers/checkpoint.ts`
docs/architecture/v2-checkpoint-1.md:151:- `src/runtime/step-handlers/sub-run.ts`
docs/architecture/v2-checkpoint-1.md:152:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-checkpoint-1.md:153:- `src/runtime/step-handlers/fanout/aggregate.ts`
docs/architecture/v2-checkpoint-1.md:154:- `src/runtime/step-handlers/fanout/branch-resolution.ts`
docs/architecture/v2-checkpoint-1.md:155:- `src/runtime/step-handlers/fanout/join-policy.ts`
docs/architecture/v2-checkpoint-1.md:156:- `src/runtime/step-handlers/fanout/types.ts`
src/flows/fix/writers/close.ts:14:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/fix/writers/close.ts:18:} from '../../../runtime/registries/close-writers/types.js';
src/flows/migrate/writers/coexistence.ts:12:} from '../../../runtime/registries/compose-writers/types.js';
src/core-v2/executors/relay.ts:3:import { relayClaudeCode } from '../../runtime/connectors/claude-code.js';
src/core-v2/executors/relay.ts:4:import { relayCodex } from '../../runtime/connectors/codex.js';
src/core-v2/executors/relay.ts:5:import { relayCustom } from '../../runtime/connectors/custom.js';
src/core-v2/executors/relay.ts:6:import { runCrossReportValidator } from '../../runtime/registries/cross-report-validators.js';
src/core-v2/executors/relay.ts:7:import { parseReport } from '../../runtime/registries/report-schemas.js';
src/core-v2/executors/verification.ts:4:import { findVerificationWriter } from '../../runtime/registries/verification-writers/registry.js';
src/core-v2/executors/verification.ts:5:import type { VerificationCommand } from '../../runtime/registries/verification-writers/types.js';
tests/contracts/engine-flow-boundary.test.ts:1:// Architecture boundary: src/runtime/ may not import from any
tests/contracts/engine-flow-boundary.test.ts:14:const RUNTIME_ROOT = 'src/runtime';
tests/contracts/engine-flow-boundary.test.ts:69:  it('no file under src/runtime/ imports a flow source other than the catalog or types', () => {
tests/contracts/engine-flow-boundary.test.ts:76:      'src/runtime walk returned unexpectedly few files — discovery loop is likely broken',
src/flows/fix/writers/brief.ts:12:} from '../../../runtime/registries/compose-writers/types.js';
docs/architecture/v2-worklog.md:17:- `src/runtime/`
docs/architecture/v2-worklog.md:18:- `src/runtime/connectors/`
docs/architecture/v2-worklog.md:19:- `src/runtime/step-handlers/`
docs/architecture/v2-worklog.md:65:  lives in generic schema/runtime surfaces.
docs/architecture/v2-worklog.md:188:- `src/runtime/result-writer.ts`
docs/architecture/v2-worklog.md:301:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:350:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:398:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:399:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:400:- `src/runtime/result-writer.ts`
docs/architecture/v2-worklog.md:401:- `src/runtime/step-handlers/`
docs/architecture/v2-worklog.md:476:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:525:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:587:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:588:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-worklog.md:642:- `src/runtime/**`
docs/architecture/v2-worklog.md:643:- current imports referencing `src/runtime/`
docs/architecture/v2-worklog.md:669:- `src/runtime/runner.ts` remains live for retained fallback, rollback,
docs/architecture/v2-worklog.md:672:- Several `src/runtime/` modules are shared infrastructure and should be moved
docs/architecture/v2-worklog.md:685:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:686:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:688:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:725:shared relay/progress callback types out of `src/runtime/runner-types.ts`.
docs/architecture/v2-worklog.md:729:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:740:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:763:Behavior changed? No runtime behavior changed. `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:779:the shared progress output helpers out of `src/runtime/progress-projector.ts`.
docs/architecture/v2-worklog.md:783:- `src/runtime/progress-projector.ts`
docs/architecture/v2-worklog.md:791:- `src/runtime/progress-projector.ts`
docs/architecture/v2-worklog.md:818:- `src/runtime/progress-projector.ts` remains live for retained runtime and old
docs/architecture/v2-worklog.md:827:precedence resolver out of `src/runtime/selection-resolver.ts`.
docs/architecture/v2-worklog.md:831:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:832:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:840:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:841:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:871:- `src/runtime/relay-selection.ts` remains live for retained relay decision
docs/architecture/v2-worklog.md:875:leaving retained relayer resolution in `runtime/relay-selection.ts`.
docs/architecture/v2-worklog.md:879:Goal: reduce core-v2's dependency on `src/runtime/relay-selection.ts` by moving
docs/architecture/v2-worklog.md:885:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:886:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:887:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:896:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:918:`src/shared/relay-selection.ts`; `src/runtime/relay-selection.ts` re-exports
docs/architecture/v2-worklog.md:924:- `src/runtime/relay-selection.ts` remains live for retained relayer resolution,
docs/architecture/v2-worklog.md:933:Goal: reduce core-v2's dependency on `src/runtime/relay-support.ts` by moving
docs/architecture/v2-worklog.md:938:- `src/runtime/relay-support.ts`
docs/architecture/v2-worklog.md:939:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:940:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-worklog.md:947:- `src/runtime/relay-support.ts`
docs/architecture/v2-worklog.md:969:`src/runtime/relay-support.ts` re-exports them for retained runtime
docs/architecture/v2-worklog.md:983:Goal: reduce core-v2's dependency on `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:988:- `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:990:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:991:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:997:- `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:1019:`src/runtime/write-capable-worker-disclosure.ts` re-exports them for retained
docs/architecture/v2-worklog.md:1027:Next recommended action: inspect `src/runtime/run-relative-path.ts` as the next
docs/architecture/v2-worklog.md:1034:`src/runtime/run-relative-path.ts` without changing path safety semantics.
docs/architecture/v2-worklog.md:1038:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-worklog.md:1047:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-worklog.md:1071:in `src/shared/run-relative-path.ts`; `src/runtime/run-relative-path.ts`
docs/architecture/v2-worklog.md:1087:`src/runtime/connectors/shared.ts` without moving connector subprocess modules
docs/architecture/v2-worklog.md:1092:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1103:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1131:`src/runtime/connectors/shared.ts` re-exports them for retained runtime and
docs/architecture/v2-worklog.md:1152:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1153:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-worklog.md:1154:- `src/runtime/connectors/codex.ts`
docs/architecture/v2-worklog.md:1155:- `src/runtime/connectors/custom.ts`
docs/architecture/v2-worklog.md:1163:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1164:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-worklog.md:1165:- `src/runtime/connectors/codex.ts`
docs/architecture/v2-worklog.md:1166:- `src/runtime/connectors/custom.ts`
docs/architecture/v2-worklog.md:1194:`src/runtime/connectors/shared.ts` re-exports them for retained runtime and old
docs/architecture/v2-worklog.md:1215:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-worklog.md:1216:- `src/runtime/connectors/codex.ts`
docs/architecture/v2-worklog.md:1217:- `src/runtime/connectors/custom.ts`
docs/architecture/v2-worklog.md:1218:- `src/runtime/connectors/relay-materializer.ts`
docs/architecture/v2-worklog.md:1219:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1220:- `src/runtime/registries/**`
docs/architecture/v2-worklog.md:1221:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-worklog.md:1279:- `src/runtime/config-loader.ts`
docs/architecture/v2-worklog.md:1287:- `src/runtime/config-loader.ts`
docs/architecture/v2-worklog.md:1300:`src/shared/config-loader.ts`; `src/runtime/config-loader.ts` re-exports it for
docs/architecture/v2-worklog.md:1321:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:1330:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:1351:lives in `src/shared/operator-summary-writer.ts`; `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:1373:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-worklog.md:1375:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1377:- `tests/unit/runtime/event-log-round-trip.test.ts`
docs/architecture/v2-worklog.md:1383:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-worklog.md:1384:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1386:- `tests/unit/runtime/event-log-round-trip.test.ts`
docs/architecture/v2-worklog.md:1396:- `npx vitest run tests/unit/runtime/event-log-round-trip.test.ts tests/runner/run-status-projection.test.ts tests/runner/fresh-run-root.test.ts tests/runner/handoff-hook-adapters.test.ts`
docs/architecture/v2-worklog.md:1404:`src/runtime/manifest-snapshot-writer.ts` re-exports it for compatibility.
docs/architecture/v2-worklog.md:1427:- `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-worklog.md:1439:- `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-worklog.md:1463:now lives in `src/shared/flow-kind-policy.ts`; `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-worklog.md:1486:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1497:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1541:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1554:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1699:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:1700:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:1709:- `src/runtime/relay-support.ts`
docs/architecture/v2-worklog.md:1710:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:1736:- `RelayFn` still lives in `src/runtime/runner-types.ts` and should move to a
docs/architecture/v2-worklog.md:2078:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-worklog.md:2135:- `src/runtime/`
docs/architecture/v2-worklog.md:2136:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:2137:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:2138:- `src/runtime/step-handlers/`
docs/architecture/v2-worklog.md:2139:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-worklog.md:2140:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-worklog.md:2141:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:2142:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:2143:- `src/runtime/registries/`
docs/architecture/v2-worklog.md:2176:- Some files under `src/runtime/` are still live compiler, catalog, registry,
docs/architecture/v2-worklog.md:2232:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-worklog.md:2315:- `src/runtime/step-handlers/sub-run.ts`
docs/architecture/v2-worklog.md:2316:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-worklog.md:2317:- `src/runtime/step-handlers/fanout/branch-resolution.ts`
docs/architecture/v2-worklog.md:2318:- `src/runtime/step-handlers/fanout/join-policy.ts`
docs/architecture/v2-worklog.md:2319:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:2320:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-worklog.md:2321:- `src/runtime/connectors/codex.ts`
src/flows/types.ts:14:import type { CheckpointBriefBuilder } from '../runtime/registries/checkpoint-writers/types.js';
src/flows/types.ts:15:import type { CloseBuilder } from '../runtime/registries/close-writers/types.js';
src/flows/types.ts:16:import type { ComposeBuilder } from '../runtime/registries/compose-writers/types.js';
src/flows/types.ts:17:import type { CrossReportValidator } from '../runtime/registries/cross-report-validators.js';
src/flows/types.ts:18:import type { StructuralShapeHint } from '../runtime/registries/shape-hints/types.js';
src/flows/types.ts:19:import type { VerificationBuilder } from '../runtime/registries/verification-writers/types.js';
src/flows/explore/relay-hints.ts:3:import type { SchemaShapeHint } from '../../runtime/registries/shape-hints/types.js';
tests/contracts/explore-report-composition.test.ts:5:import { findCloseBuilder } from '../../src/runtime/registries/close-writers/registry.js';
tests/contracts/explore-report-composition.test.ts:6:import { findComposeBuilder } from '../../src/runtime/registries/compose-writers/registry.js';
tests/contracts/explore-report-composition.test.ts:7:import { parseReport } from '../../src/runtime/registries/report-schemas.js';
docs/architecture/v2-checkpoint-4.8.md:16:First, `src/runtime/selection-resolver.ts` is not just a test oracle. It is
docs/architecture/v2-checkpoint-4.8.md:18:core-v2 relay through `src/runtime/relay-selection.ts`.
docs/architecture/v2-checkpoint-4.8.md:20:Second, `src/runtime/progress-projector.ts` is not only old runtime/test
docs/architecture/v2-checkpoint-4.8.md:33:find src/runtime -type f | sort
docs/architecture/v2-checkpoint-4.8.md:34:rg -n "from ['\"].*runtime/|../runtime|../../runtime|runtime/" src tests scripts docs specs package.json
docs/architecture/v2-checkpoint-4.8.md:47:1. Move shared relay/progress types out of `src/runtime/runner-types.ts`.
docs/architecture/v2-checkpoint-4.8.md:48:2. Move shared progress helper functions out of `src/runtime/progress-projector.ts`.
docs/architecture/v2-checkpoint-4.8.md:49:3. Move relay selection support out of `src/runtime/relay-selection.ts` and
docs/architecture/v2-checkpoint-4.8.md:50:   `src/runtime/selection-resolver.ts`.
src/core-v2/executors/checkpoint.ts:2:import { findCheckpointBriefBuilder } from '../../runtime/registries/checkpoint-writers/registry.js';
docs/positioning-and-strategy.md:163:| Within-run continuity (pause/resume single run) | **Real** (`runtime/checkpoint.ts`, `schemas/continuity.ts`) |
docs/architecture/v2-checkpoint-4.11.md:21:`src/runtime/selection-resolver.ts` remains as a compatibility re-export.
docs/architecture/v2-checkpoint-4.11.md:25:`src/runtime/relay-selection.ts` now imports selection precedence from the
tests/contracts/orphan-blocks.test.ts:24:} from '../../src/runtime/compile-schematic-to-flow.js';
tests/contracts/orphan-blocks.test.ts:25:import { runCompiledFlow, writePrototypeComposeReport } from '../../src/runtime/runner.js';
src/flows/explore/command.md:111:- `src/runtime/` (current runner)
docs/architecture/v2-checkpoint-4.1.1.md:25:  `src/runtime/relay-support.ts`, so `core-v2` no longer imports
docs/architecture/v2-checkpoint-4.1.1.md:26:  `src/runtime/step-handlers/relay.ts` directly.
docs/architecture/v2-checkpoint-4.1.1.md:32:- `src/runtime/runner.ts` remains the production CLI runner.
docs/architecture/v2-checkpoint-4.1.1.md:33:- `src/runtime/step-handlers/relay.ts` remains for the old runtime path and old
docs/architecture/v2-checkpoint-4.1.1.md:35:- `src/runtime/runner-types.ts` remains because `RelayFn` is still shared by the
tests/contracts/flow-model-effort.test.ts:6:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/contracts/flow-model-effort.test.ts:7:import { type RelayFn, type RelayInput, runCompiledFlow } from '../../src/runtime/runner.js';
src/flows/explore/writers/analysis.ts:10:} from '../../../runtime/registries/compose-writers/types.js';
src/core-v2/executors/compose.ts:5:} from '../../runtime/registries/close-writers/registry.js';
src/core-v2/executors/compose.ts:9:} from '../../runtime/registries/compose-writers/registry.js';
src/flows/explore/contract.md:369:`src/runtime/registries/report-schemas.ts`. The canonical report at
src/flows/explore/contract.md:387:`src/runtime/registries/report-schemas.ts` carries the strict
src/flows/explore/contract.md:394:`src/runtime/runner.ts` name the exact JSON shapes the connectors must
src/flows/explore/writers/close.ts:10:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/explore/writers/close.ts:14:} from '../../../runtime/registries/close-writers/types.js';
tests/contracts/compile-schematic-to-flow.test.ts:7:} from '../../src/runtime/compile-schematic-to-flow.js';
docs/contracts/selection.md:142:  `src/runtime/connectors/*.ts` for connector-specific honoring.
docs/contracts/selection.md:271:## Property ids (Stage 2 runtime/property coverage)
src/flows/explore/writers/decision.ts:11:} from '../../../runtime/registries/compose-writers/types.js';
docs/contracts/connector.md:126:    `src/runtime/connectors/codex.ts`; ADR-0009 §Consequences.Enabling is
docs/contracts/connector.md:175:  `src/runtime/connectors/custom.ts`.
src/flows/explore/writers/decision-options.ts:10:} from '../../../runtime/registries/compose-writers/types.js';
docs/contracts/step.md:145:  `src/runtime/run-relative-path.ts` path is a retained compatibility wrapper.
src/flows/explore/writers/brief.ts:11:} from '../../../runtime/registries/compose-writers/types.js';
docs/architecture/v2-checkpoint-4.10.md:21:`src/runtime/progress-projector.ts` remains as the old trace-to-progress
docs/architecture/v2-checkpoint-4.10.md:30:It no longer imports `src/runtime/progress-projector.ts`.
src/flows/runtime-proof/index.ts:9:    schematic: 'src/flows/runtime-proof/schematic.json',
src/runtime/runner.ts:441:// under src/runtime/registries/compose-writers/ and is registered by
src/runtime/runner.ts:443:// src/runtime/registries/close-writers/. The runner stays flow-
src/runtime/runner.ts:741:// src/runtime/step-handlers/.
tests/contracts/relay-transcript-schema.test.ts:11:import { reduce } from '../../src/runtime/reducer.js';
src/flows/runtime-proof/writers/compose.ts:4:} from '../../../runtime/registries/compose-writers/types.js';
tests/contracts/flow-kind-policy.test.ts:12:} from '../../src/runtime/policy/flow-kind-policy.js';
tests/contracts/flow-kind-policy.test.ts:322:    expect(result.detail).toMatch(/runtime-proof.*exempt/);
src/runtime/operator-summary-writer.ts:11:// importing the old path while ownership narrows out of `src/runtime/`.
docs/architecture/v2-checkpoint-4.20.md:21:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.20.md:44:`src/runtime/manifest-snapshot-writer.ts` is now a compatibility wrapper. Keep
docs/architecture/v2-checkpoint-4.20.md:62:- `npx vitest run tests/unit/runtime/event-log-round-trip.test.ts tests/runner/run-status-projection.test.ts tests/runner/fresh-run-root.test.ts tests/runner/handoff-hook-adapters.test.ts` passed.
tests/contracts/build-report-schemas.test.ts:342:            file_refs: ['src/runtime/runner.ts'],
src/runtime/manifest-snapshot-writer.ts:11:// importing the old path while ownership narrows out of `src/runtime/`.
tests/contracts/codex-host-plugin.test.ts:17:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/contracts/codex-host-plugin.test.ts:18:import type { RelayInput } from '../../src/runtime/runner.js';
tests/contracts/codex-host-plugin.test.ts:460:    expect(existsSync(resolve(PLUGIN_ROOT, 'flows/runtime-proof'))).toBe(false);
tests/contracts/codex-host-plugin.test.ts:461:    expect(existsSync(resolve(REPO_ROOT, '.claude-plugin/skills/runtime-proof'))).toBe(false);
tests/runner/fanout-handler-direct.test.ts:18:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/fanout-handler-direct.test.ts:25:} from '../../src/runtime/runner.js';
tests/runner/fanout-handler-direct.test.ts:26:import { runFanoutStep } from '../../src/runtime/step-handlers/fanout.js';
tests/runner/fanout-handler-direct.test.ts:27:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
src/runtime/registries/compose-writers/types.ts:17:// src/runtime/registries/close-writers/. The two registries are intentionally
tests/runner/terminal-outcome-mapping.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/terminal-outcome-mapping.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/terminal-outcome-mapping.test.ts:12:} from '../../src/runtime/runner.js';
tests/runner/terminal-outcome-mapping.test.ts:13:import { readRunTrace } from '../../src/runtime/trace-reader.js';
src/runtime/connectors/shared.ts:12:// materialization remain in `src/runtime/connectors/`.
src/runtime/connectors/relay-materializer.ts:28:// Why live in `src/runtime/connectors/` and not `src/runtime/` proper.
src/runtime/connectors/relay-materializer.ts:31:// scope is `src/runtime/connectors/**`, and this module's only external
src/runtime/connectors/relay-materializer.ts:93:// `src/runtime/runner.ts::evaluateRelayCheck` + the `parseReport`
src/runtime/connectors/relay-materializer.ts:97:// registry at `src/runtime/registries/report-schemas.ts`; unknown schema names
src/runtime/step-handlers/checkpoint.ts:109:// means adding a builder under src/runtime/registries/checkpoint-writers/.
tests/runner/fanout-runtime.test.ts:6:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/fanout-runtime.test.ts:15:} from '../../src/runtime/runner.js';
tests/runner/fanout-runtime.test.ts:801:      reason: /runtime-proof-strict@v1/,
src/runtime/compile-schematic-to-flow.ts:71:        `schematic item '${item.id}' has verification kind but writes '${item.output}'; no verification writer is registered for that schema (see src/runtime/registries/verification-writers/registry.ts)`,
src/runtime/compile-schematic-to-flow.ts:78:        `schematic item '${item.id}' has checkpoint kind writing report '${item.output}'; no checkpoint writer is registered for that schema (see src/runtime/registries/checkpoint-writers/registry.ts)`,
tests/runner/relay-handler-direct.test.ts:16:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/relay-handler-direct.test.ts:17:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/relay-handler-direct.test.ts:18:import { runRelayStep } from '../../src/runtime/step-handlers/relay.js';
tests/runner/relay-handler-direct.test.ts:19:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/fix-report-writer.test.ts:22:import { writeComposeReport } from '../../src/runtime/runner.js';
tests/runner/relay-shape-hint-registry.test.ts:20:} from '../../src/runtime/registries/shape-hints/registry.js';
tests/runner/relay-shape-hint-registry.test.ts:21:import type { RelayStep } from '../../src/runtime/registries/shape-hints/types.js';
tests/runner/codex-relay-roundtrip.test.ts:8:import { type CodexRelayResult, relayCodex } from '../../src/runtime/connectors/codex.js';
tests/runner/codex-relay-roundtrip.test.ts:9:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/codex-relay-roundtrip.test.ts:10:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/codex-relay-roundtrip.test.ts:11:import { reduce } from '../../src/runtime/reducer.js';
tests/runner/codex-relay-roundtrip.test.ts:12:import { appendAndDerive, bootstrapRun } from '../../src/runtime/runner.js';
tests/runner/codex-relay-roundtrip.test.ts:13:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/codex-relay-roundtrip.test.ts:60://   (a) src/runtime/connectors/codex.ts — relayCodex + parseCodexStdout
tests/runner/codex-relay-roundtrip.test.ts:65://   (d) src/runtime/connectors/shared.ts — compatibility re-exports used by
tests/runner/codex-relay-roundtrip.test.ts:67://   (e) src/runtime/connectors/relay-materializer.ts — five-trace_entry
tests/runner/codex-relay-roundtrip.test.ts:80:  resolve('src/runtime/connectors/codex.ts'),
tests/runner/codex-relay-roundtrip.test.ts:83:  resolve('src/runtime/connectors/shared.ts'),
tests/runner/codex-relay-roundtrip.test.ts:84:  resolve('src/runtime/connectors/relay-materializer.ts'),
tests/runner/codex-relay-roundtrip.test.ts:85:  resolve('src/runtime/runner.ts'),
tests/runner/codex-relay-roundtrip.test.ts:86:  resolve('src/runtime/registries/report-schemas.ts'),
tests/runner/explore-report-writer.test.ts:13:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-report-writer.test.ts:14:import { type RelayFn, type RelayInput, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/sub-run-handler-direct.test.ts:20:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/sub-run-handler-direct.test.ts:26:} from '../../src/runtime/runner.js';
tests/runner/sub-run-handler-direct.test.ts:27:import { runSubRunStep } from '../../src/runtime/step-handlers/sub-run.js';
tests/runner/sub-run-handler-direct.test.ts:28:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/build-checkpoint-exec.test.ts:8:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/build-checkpoint-exec.test.ts:9:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/build-checkpoint-exec.test.ts:15:} from '../../src/runtime/runner.js';
tests/runner/runner-relay-connector-identity.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/runner-relay-connector-identity.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/runner-relay-connector-identity.test.ts:8:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/runner-relay-connector-identity.test.ts:30:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/plugin-command-invocation.test.ts:139:        expect(body).not.toMatch(/dist\/cli\/runtime-proof\.js/);
tests/runner/close-builder-registry.test.ts:21:import { findCloseBuilder } from '../../src/runtime/registries/close-writers/registry.js';
tests/runner/close-builder-registry.test.ts:22:import type { CloseBuilder } from '../../src/runtime/registries/close-writers/types.js';
tests/runner/close-builder-registry.test.ts:23:import { runCompiledFlow, writePrototypeComposeReport } from '../../src/runtime/runner.js';
tests/runner/connector-shared-compat.test.ts:6:} from '../../src/runtime/connectors/shared.js';
tests/runner/connector-shared-compat.test.ts:7:import { sha256Hex as runtimeSha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/pass-route-cycle-guard.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/pass-route-cycle-guard.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/pass-route-cycle-guard.test.ts:8:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/pass-route-cycle-guard.test.ts:9:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/pass-route-cycle-guard.test.ts:17:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/checkpoint-handler-direct.test.ts:16:import { runCheckpointStep } from '../../src/runtime/step-handlers/checkpoint.js';
tests/runner/checkpoint-handler-direct.test.ts:17:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/checkpoint-handler-direct.test.ts:18:import { traceEntryLogPath } from '../../src/runtime/trace-writer.js';
tests/runner/fresh-run-root.test.ts:14:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/fresh-run-root.test.ts:15:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/fresh-run-root.test.ts:16:import { manifestSnapshotPath } from '../../src/runtime/manifest-snapshot-writer.js';
tests/runner/fresh-run-root.test.ts:17:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/fresh-run-root.test.ts:23:} from '../../src/runtime/runner.js';
tests/runner/fresh-run-root.test.ts:24:import { snapshotPath } from '../../src/runtime/snapshot-writer.js';
tests/runner/fresh-run-root.test.ts:25:import { traceEntryLogPath } from '../../src/runtime/trace-writer.js';
tests/runner/fresh-run-root.test.ts:30:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/runtime-smoke.test.ts:14:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/runtime-smoke.test.ts:15:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/runtime-smoke.test.ts:16:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/runtime-smoke.test.ts:17:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/runtime-smoke.test.ts:30:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/migrate-runtime-wiring.test.ts:15:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/migrate-runtime-wiring.test.ts:16:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/migrate-runtime-wiring.test.ts:17:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/migrate-runtime-wiring.test.ts:25:} from '../../src/runtime/runner.js';
tests/runner/handler-throw-recovery.test.ts:11:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/handler-throw-recovery.test.ts:12:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/handler-throw-recovery.test.ts:13:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/handler-throw-recovery.test.ts:14:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/handler-throw-recovery.test.ts:25:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/explore-tournament-runtime.test.ts:6:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-tournament-runtime.test.ts:12:} from '../../src/runtime/runner.js';
tests/runner/cross-report-validators.test.ts:6:import { reportPathForSchemaInCompiledFlow } from '../../src/runtime/registries/close-writers/shared.js';
tests/runner/cross-report-validators.test.ts:7:import { runCrossReportValidator } from '../../src/runtime/registries/cross-report-validators.js';
tests/runner/cli-v2-runtime.test.ts:32:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/cli-v2-runtime.test.ts:33:import type { ComposeWriterFn, RelayFn, RelayInput } from '../../src/runtime/runner.js';
tests/runner/cli-v2-runtime.test.ts:1547:      /checkpoint-waiting depth 'deep' remains on the retained checkpoint runtime/,
tests/runner/cli-router.test.ts:9:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/cli-router.test.ts:10:import type { RelayFn, RelayInput } from '../../src/runtime/runner.js';
tests/runner/check-evaluation.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/check-evaluation.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/check-evaluation.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/check-evaluation.test.ts:29:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/fix-runtime-wiring.test.ts:17:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/fix-runtime-wiring.test.ts:18:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/fix-runtime-wiring.test.ts:24:} from '../../src/runtime/runner.js';
tests/runner/operator-summary-writer.test.ts:6:import { writeOperatorSummary as runtimeWriteOperatorSummary } from '../../src/runtime/operator-summary-writer.js';
tests/runner/agent-connector-smoke.test.ts:4:import { relayClaudeCode, sha256Hex } from '../../src/runtime/connectors/claude-code.js';
tests/runner/terminal-verdict-derivation.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/terminal-verdict-derivation.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/terminal-verdict-derivation.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/terminal-verdict-derivation.test.ts:31:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/codex-connector-smoke.test.ts:3:import { relayCodex } from '../../src/runtime/connectors/codex.js';
tests/runner/codex-connector-smoke.test.ts:4:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/fanout-real-recursion.test.ts:13:// itself (per src/runtime/runner.ts:633), so each branch recurses
tests/runner/fanout-real-recursion.test.ts:24:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/fanout-real-recursion.test.ts:25:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/fanout-real-recursion.test.ts:31:} from '../../src/runtime/runner.js';
tests/runner/build-runtime-wiring.test.ts:12:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/build-runtime-wiring.test.ts:13:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/build-runtime-wiring.test.ts:14:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/catalog-derivations.test.ts:20:} from '../../src/runtime/catalog-derivations.js';
tests/runner/catalog-derivations.test.ts:21:import type { CheckpointBriefBuilder } from '../../src/runtime/registries/checkpoint-writers/types.js';
tests/runner/catalog-derivations.test.ts:22:import type { CloseBuilder } from '../../src/runtime/registries/close-writers/types.js';
tests/runner/catalog-derivations.test.ts:23:import type { ComposeBuilder } from '../../src/runtime/registries/compose-writers/types.js';
tests/runner/catalog-derivations.test.ts:24:import type { StructuralShapeHint } from '../../src/runtime/registries/shape-hints/types.js';
tests/runner/catalog-derivations.test.ts:25:import type { VerificationBuilder } from '../../src/runtime/registries/verification-writers/types.js';
tests/runner/catalog-derivations.test.ts:461:      '../../src/runtime/registries/compose-writers/registry.js'
tests/runner/catalog-derivations.test.ts:464:      '../../src/runtime/registries/close-writers/registry.js'
tests/runner/catalog-derivations.test.ts:467:      '../../src/runtime/registries/verification-writers/registry.js'
tests/runner/catalog-derivations.test.ts:470:      '../../src/runtime/registries/checkpoint-writers/registry.js'
tests/runner/run-relative-path.test.ts:14:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/run-relative-path.test.ts:15:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/run-relative-path.test.ts:16:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/run-relative-path.test.ts:17:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/run-relative-path.test.ts:23:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/runner-relay-provenance.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/runner-relay-provenance.test.ts:7:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/runner-relay-provenance.test.ts:8:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/runner-relay-provenance.test.ts:9:import { resolveRelayDecision } from '../../src/runtime/relay-selection.js';
tests/runner/runner-relay-provenance.test.ts:10:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/runner-relay-provenance.test.ts:25:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/build-report-writer.test.ts:19:} from '../../src/runtime/runner.js';
tests/runner/build-report-writer.test.ts:334:        changed_files: ['src/runtime/runner.ts'],
tests/runner/config-loader.test.ts:11:} from '../../src/runtime/config-loader.js';
tests/runner/config-loader.test.ts:12:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/config-loader.test.ts:13:import type { RelayFn, RelayInput } from '../../src/runtime/runner.js';
tests/runner/explore-e2e-parity.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-e2e-parity.test.ts:12:import { type RelayFn, type RelayInput, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/explore-e2e-parity.test.ts:50:  'src/runtime/connectors/claude-code.ts',
tests/runner/explore-e2e-parity.test.ts:53:  'src/runtime/connectors/shared.ts',
tests/runner/explore-e2e-parity.test.ts:54:  'src/runtime/connectors/relay-materializer.ts',
tests/runner/explore-e2e-parity.test.ts:55:  'src/runtime/runner.ts',
tests/runner/explore-e2e-parity.test.ts:56:  'src/runtime/registries/report-schemas.ts',
tests/runner/custom-connector-runtime.test.ts:3:import { relayCustom } from '../../src/runtime/connectors/custom.js';
tests/runner/materializer-schema-parse.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/materializer-schema-parse.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/materializer-schema-parse.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/materializer-schema-parse.test.ts:41:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/materializer-schema-parse.test.ts:200:    expect(ge.reason).toMatch(/runtime-proof-strict@v1/);
tests/runner/compose-builder-registry.test.ts:15:import { findComposeBuilder } from '../../src/runtime/registries/compose-writers/registry.js';
tests/runner/compose-builder-registry.test.ts:16:import type { ComposeBuilder } from '../../src/runtime/registries/compose-writers/types.js';
tests/runner/compose-builder-registry.test.ts:17:import { runCompiledFlow, writeComposeReport } from '../../src/runtime/runner.js';
tests/runner/router-routing-invariants.test.ts:15:import { classifyTaskAgainstRoutables, deriveRoutingForTesting } from '../../src/runtime/router.js';
tests/runner/relay-invocation-failure.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/relay-invocation-failure.test.ts:7:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/relay-invocation-failure.test.ts:8:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/relay-invocation-failure.test.ts:16:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/run-status-projection.test.ts:6:import { projectRunStatusFromRunFolder } from '../../src/runtime/run-status-projection.js';
tests/runner/run-status-projection.test.ts:7:import { appendTraceEntry } from '../../src/runtime/trace-writer.js';
tests/runner/push-sequence-authority.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/push-sequence-authority.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/push-sequence-authority.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/push-sequence-authority.test.ts:13:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/push-sequence-authority.test.ts:26:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/review-runtime-wiring.test.ts:28:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/review-runtime-wiring.test.ts:29:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/review-runtime-wiring.test.ts:30:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/sub-run-real-recursion.test.ts:25:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/sub-run-real-recursion.test.ts:26:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/sub-run-real-recursion.test.ts:31:} from '../../src/runtime/runner.js';
tests/runner/agent-relay-roundtrip.test.ts:9:} from '../../src/runtime/connectors/claude-code.js';
tests/runner/agent-relay-roundtrip.test.ts:10:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/agent-relay-roundtrip.test.ts:11:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/agent-relay-roundtrip.test.ts:12:import { reduce } from '../../src/runtime/reducer.js';
tests/runner/agent-relay-roundtrip.test.ts:13:import { appendAndDerive, bootstrapRun } from '../../src/runtime/runner.js';
tests/runner/agent-relay-roundtrip.test.ts:14:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/build-verification-exec.test.ts:16:import { type ComposeWriterFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/verification-handler-direct.test.ts:25:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/verification-handler-direct.test.ts:26:import { runVerificationStep } from '../../src/runtime/step-handlers/verification.js';
tests/runner/sub-run-runtime.test.ts:6:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/sub-run-runtime.test.ts:14:} from '../../src/runtime/runner.js';
tests/runner/sweep-runtime-wiring.test.ts:15:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/sweep-runtime-wiring.test.ts:16:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/sweep-runtime-wiring.test.ts:17:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
```

## Targeted path references

```bash
rg -n "src/runtime/connectors/shared.ts|src/shared/connector-helpers.ts|src/shared/connector-relay.ts|src/runtime/connectors/relay-materializer.ts|src/runtime/registries/|src/shared/flow-kind-policy.ts|src/runtime/policy/flow-kind-policy.ts|src/shared/manifest-snapshot.ts|src/runtime/manifest-snapshot-writer.ts|src/shared/operator-summary-writer.ts|src/runtime/operator-summary-writer.ts|src/shared/config-loader.ts|src/runtime/config-loader.ts" README.md commands plugins .claude-plugin generated docs specs scripts src tests package.json -g "!docs/architecture/v2-runtime-import-inventory.md"
```

```text
scripts/policy/flow-kind-policy.d.mts:6: *   - src/shared/flow-kind-policy.ts — runtime-level
scripts/policy/flow-kind-policy.mjs:3:// Consumed by src/shared/flow-kind-policy.ts, which wraps these
scripts/policy/flow-kind-policy.mjs:236: * in src/shared/flow-kind-policy.ts so this stays Zod-free and
specs/reports.json:279:      "trust_boundary": "operator-local persisted state; written once at bootstrap by the manifest snapshot writer at src/runtime/manifest-snapshot-writer.ts. Hash algorithm: SHA-256 over the exact persisted manifest snapshot bytes (`algorithm: 'sha256-raw'`), per ADR-0001 Addendum B §Stage 1.5 Close Criteria #8. Parse-time superRefine rejects any snapshot whose declared hash disagrees with sha256 over decoded bytes_base64; a second reader cannot be tricked into accepting a tampered byte-body under the declared hash.",
scripts/release/emit-current-capabilities.mjs:776:        'src/shared/operator-summary-writer.ts',
scripts/release/emit-current-capabilities.mjs:779:        'src/runtime/operator-summary-writer.ts',
docs/architecture/v2-checkpoint-4.22.md:17:- `src/shared/config-loader.ts`
docs/architecture/v2-checkpoint-4.22.md:21:- `src/runtime/config-loader.ts`
docs/architecture/v2-checkpoint-4.22.md:40:`src/runtime/config-loader.ts` is now a compatibility wrapper. Keep it until
generated/release/current-capabilities.json:1805:        "src/shared/operator-summary-writer.ts",
generated/release/current-capabilities.json:1808:        "src/runtime/operator-summary-writer.ts"
docs/architecture/v2-checkpoint-4.16.md:15:- `src/shared/connector-relay.ts`
docs/architecture/v2-checkpoint-4.16.md:23:`src/runtime/connectors/shared.ts` remains as a compatibility surface for those
docs/architecture/v2-checkpoint-4.16.md:29:now import the moved surface from `src/shared/connector-relay.ts`.
docs/architecture/v2-checkpoint-4.16.md:31:Connector-only helpers remain in `src/runtime/connectors/shared.ts`:
docs/architecture/v2-checkpoint-4.16.md:45:`src/shared/connector-relay.ts`, so future changes to the moved relay contract
docs/architecture/v2-connector-materializer-plan.md:9:- relay data/hash lives in `src/shared/connector-relay.ts`;
docs/architecture/v2-connector-materializer-plan.md:10:- connector parsing/model helpers live in `src/shared/connector-helpers.ts`;
docs/architecture/v2-connector-materializer-plan.md:11:- `src/runtime/connectors/shared.ts` is now a compatibility re-export surface.
docs/architecture/v2-connector-materializer-plan.md:23:| `src/runtime/connectors/relay-materializer.ts` | retained relay handler tests, relay provenance tests, run-relative path tests, live smoke roundtrip tests | Owns translation from validated connector result to trace entries and durable relay slots; cross-checks role/provenance consistency | Writes request, receipt, result, and optional report files; emits the durable relay transcript sequence | `tests/runner/agent-relay-roundtrip.test.ts`, `tests/runner/codex-relay-roundtrip.test.ts`, `tests/runner/runner-relay-provenance.test.ts`, `tests/runner/run-relative-path.test.ts`, `tests/runner/materializer-schema-parse.test.ts` | Keep until a materialization-contract plan proves byte-for-byte and trace-shape parity after a move |
docs/architecture/v2-connector-materializer-plan.md:24:| `src/runtime/connectors/shared.ts` | retained runtime imports, tests that still use the old connector surface | No subprocess behavior; compatibility only | No direct writes or trace entries | `tests/runner/connector-shared-compat.test.ts`, full `npm run verify` | Keep as a wrapper until old-path imports are migrated or intentionally retained |
docs/architecture/v2-connector-materializer-plan.md:34:- `src/shared/connector-relay.ts`;
docs/architecture/v2-connector-materializer-plan.md:35:- `src/shared/connector-helpers.ts`;
docs/architecture/v2-connector-materializer-plan.md:36:- `src/runtime/connectors/shared.ts`;
docs/architecture/v2-connector-materializer-plan.md:37:- `src/runtime/connectors/relay-materializer.ts`;
docs/architecture/v2-connector-materializer-plan.md:39:- `src/runtime/registries/report-schemas.ts`.
docs/architecture/v2-connector-materializer-plan.md:44:- `src/shared/connector-relay.ts`;
docs/architecture/v2-connector-materializer-plan.md:45:- `src/shared/connector-helpers.ts`;
docs/architecture/v2-connector-materializer-plan.md:46:- `src/runtime/connectors/shared.ts`;
docs/architecture/v2-connector-materializer-plan.md:47:- `src/runtime/connectors/relay-materializer.ts`;
docs/architecture/v2-connector-materializer-plan.md:49:- `src/runtime/registries/report-schemas.ts`.
src/runtime/policy/flow-kind-policy.ts:11:// `src/shared/flow-kind-policy.ts`.
docs/architecture/v2-deletion-plan.md:74:| `src/runtime/registries/**` | keep / later move | Flow packages, v2 report validation, writer discovery, cross-report validators, and shape hints depend on these registries. |
docs/architecture/v2-deletion-plan.md:75:| `src/runtime/connectors/**` | keep / later move | core-v2 reuses real connector subprocesses, relay materialization, and argv validation. The relay data/hash surface moved to `src/shared/connector-relay.ts` in Phase 4.16, and connector parsing/model helpers moved to `src/shared/connector-helpers.ts` in Phase 4.17. Subprocess modules and materialization remain production safety infrastructure. |
docs/architecture/v2-deletion-plan.md:77:| `src/runtime/config-loader.ts` | compatibility re-export | Config discovery moved to `src/shared/config-loader.ts` in Phase 4.22. Keep this wrapper until old-path tests and external imports stop using it. |
docs/architecture/v2-deletion-plan.md:82:| `src/runtime/manifest-snapshot-writer.ts` | compatibility re-export | Manifest snapshot byte-match helper moved to `src/shared/manifest-snapshot.ts` in Phase 4.20. Keep this wrapper while retained runner and old snapshot tests use the old path. |
docs/architecture/v2-deletion-plan.md:84:| `src/runtime/operator-summary-writer.ts` | compatibility re-export | Operator summary writing moved to `src/shared/operator-summary-writer.ts` in Phase 4.21. Keep this wrapper until old-path tests and release evidence stop using it. |
docs/architecture/v2-deletion-plan.md:88:| `src/runtime/policy/flow-kind-policy.ts` | compatibility re-export | Flow-kind policy moved to `src/shared/flow-kind-policy.ts` in Phase 4.19. Keep this wrapper until old-path imports and documentation references stop using it. |
docs/architecture/v2-deletion-plan.md:111:| `runtime/connectors` | core-v2 relay bridge, retained runtime, connector tests | live connector infrastructure | Keep. Shared relay data/hash ownership moved to `src/shared/connector-relay.ts`, and connector helper ownership moved to `src/shared/connector-helpers.ts`, but subprocess modules and materialization remain production safety infrastructure. |
docs/architecture/v2-deletion-plan.md:138:- `src/shared/connector-relay.ts`
docs/architecture/v2-deletion-plan.md:139:- `src/shared/connector-helpers.ts`
docs/architecture/v2-deletion-plan.md:147:- `src/shared/flow-kind-policy.ts`
docs/architecture/v2-deletion-plan.md:195:| Move connector relay data/hash helper out of `src/runtime/connectors/shared.ts` | Done in Phase 4.16 for `ConnectorRelayInput`, `RelayResult`, and `sha256Hex`. `src/runtime/connectors/shared.ts` remains for compatibility re-exports plus connector-only parsing/model helpers. | Keep connector wrapper compatibility tests, relay/materializer tests, connector selection tests, connector smoke source fingerprint lists, and full validation green. |
docs/architecture/v2-deletion-plan.md:196:| Move connector-only helpers out of `src/runtime/connectors/shared.ts` | Done in Phase 4.17 for `selectedModelForProvider` and `extractJsonObject`. `src/runtime/connectors/shared.ts` remains as a compatibility re-export surface. | Keep connector helper compatibility tests, extraction tests, connector smoke source fingerprint lists, subprocess connector smoke tests, and full validation green. |
docs/architecture/v2-deletion-plan.md:198:| Move flow-kind policy wrapper out of `src/runtime/policy/flow-kind-policy.ts` | Done in Phase 4.19. The neutral wrapper lives in `src/shared/flow-kind-policy.ts`; the runtime path remains a compatibility re-export. | Keep flow-kind policy tests, CLI fixture policy tests, generated-surface drift checks, and full validation green. |
docs/architecture/v2-deletion-plan.md:199:| Move manifest snapshot helper out of `src/runtime/manifest-snapshot-writer.ts` | Done in Phase 4.20. The byte-match implementation lives in `src/shared/manifest-snapshot.ts`; the runtime path remains a compatibility re-export. | Keep event-log round-trip tests, run-status projection tests, fresh-run-root tests, handoff tests, and full validation green. |
docs/architecture/v2-deletion-plan.md:200:| Move operator summary writer out of `src/runtime/operator-summary-writer.ts` | Done in Phase 4.21. The implementation lives in `src/shared/operator-summary-writer.ts`; the runtime path remains a compatibility re-export. | Keep operator summary tests, CLI v2 runtime tests, release evidence checks, and full validation green. |
docs/architecture/v2-deletion-plan.md:201:| Move config loader out of `src/runtime/config-loader.ts` | Done in Phase 4.22. The schema-backed config discovery implementation lives in `src/shared/config-loader.ts`; the runtime path remains a compatibility re-export. | Keep config-loader tests, CLI v2 runtime tests, connector selection tests, and full validation green. |
src/runtime/runner.ts:441:// under src/runtime/registries/compose-writers/ and is registered by
src/runtime/runner.ts:443:// src/runtime/registries/close-writers/. The runner stays flow-
src/runtime/step-handlers/checkpoint.ts:109:// means adding a builder under src/runtime/registries/checkpoint-writers/.
docs/architecture/v2-checkpoint-4.13.md:33:- `src/runtime/registries/shape-hints/registry.ts`
src/runtime/operator-summary-writer.ts:10:// `src/shared/operator-summary-writer.ts`; retained runtime callers can keep
docs/architecture/v2-checkpoint-1.md:145:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.20.md:17:- `src/shared/manifest-snapshot.ts`
docs/architecture/v2-checkpoint-4.20.md:21:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.20.md:44:`src/runtime/manifest-snapshot-writer.ts` is now a compatibility wrapper. Keep
docs/architecture/v2-checkpoint-4.17.md:15:- `src/shared/connector-helpers.ts`
docs/architecture/v2-checkpoint-4.17.md:22:`src/runtime/connectors/shared.ts` remains as a compatibility surface for those
docs/architecture/v2-checkpoint-4.17.md:45:`src/shared/connector-helpers.ts`, so future changes to connector parsing/model
src/runtime/compile-schematic-to-flow.ts:71:        `schematic item '${item.id}' has verification kind but writes '${item.output}'; no verification writer is registered for that schema (see src/runtime/registries/verification-writers/registry.ts)`,
src/runtime/compile-schematic-to-flow.ts:78:        `schematic item '${item.id}' has checkpoint kind writing report '${item.output}'; no checkpoint writer is registered for that schema (see src/runtime/registries/checkpoint-writers/registry.ts)`,
src/runtime/config-loader.ts:9:// `src/shared/config-loader.ts`; old imports can keep using this wrapper.
docs/architecture/v2-checkpoint-4.md:55:- `src/runtime/registries/**`
docs/architecture/v2-checkpoint-4.md:57:- `src/runtime/config-loader.ts`
docs/architecture/v2-checkpoint-4.md:59:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.md:61:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-checkpoint-4.md:68:- `src/runtime/policy/flow-kind-policy.ts`
tests/properties/visible/cross-report-validator.test.ts:16:import { reportPathForSchemaInCompiledFlow } from '../../../src/runtime/registries/close-writers/shared.js';
tests/properties/visible/cross-report-validator.test.ts:17:import { runCrossReportValidator } from '../../../src/runtime/registries/cross-report-validators.js';
src/runtime/manifest-snapshot-writer.ts:10:// live in `src/shared/manifest-snapshot.ts`; retained runtime callers can keep
docs/architecture/v2-rigor-audit.md:21:| Report schema validation | Flow package `reports.ts`, `src/runtime/registries/*`, connector materializer | Invalid report trusted downstream, bad relay result accepted | Relay executor, report readers, generated manifests | Flow-owned schemas and runtime parsing | keep | Flow-owned validators called by executors | Flow report schema tests and relay tests | Preserve flow package ownership. |
docs/architecture/v2-rigor-audit.md:33:| Manifest snapshot and hash | `src/runtime/manifest-snapshot-writer.ts`, runner bootstrap | Resume against different flow bytes, impossible run audit | Resume path, status readers, tests | Snapshot writer and bootstrap metadata | keep | `manifest/` plus `run/run-context.ts` | Runner and resume tests | v2 should snapshot the executable manifest actually run. |
docs/architecture/v2-checkpoint-4.21.md:17:- `src/shared/operator-summary-writer.ts`
docs/architecture/v2-checkpoint-4.21.md:21:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-checkpoint-4.21.md:38:`src/runtime/operator-summary-writer.ts` is now a compatibility wrapper. Keep it
docs/architecture/v2-checkpoint-4.18.md:27:- relay data/hash: `src/shared/connector-relay.ts`
docs/architecture/v2-checkpoint-4.18.md:28:- parsing/model helpers: `src/shared/connector-helpers.ts`
docs/architecture/v2-checkpoint-4.18.md:29:- old connector shared path: `src/runtime/connectors/shared.ts` compatibility
docs/architecture/v2-checkpoint-4.18.md:37:- `src/runtime/connectors/relay-materializer.ts`
docs/architecture/v2-checkpoint-4.18.md:44:`src/runtime/registries/**` is shared flow-package and report infrastructure,
docs/architecture/v2-registry-ownership-plan.md:19:- `src/runtime/registries/**`.
docs/architecture/v2-registry-ownership-plan.md:31:| `src/runtime/registries/compose-writers/*` | Compose writer lookup and read-path resolution | retained runner, core-v2 compose executor, flow writers/tests | Flow-owned compose reports are written through this lookup in both runtimes | `src/flows/registries/compose-writers/*` |
docs/architecture/v2-registry-ownership-plan.md:32:| `src/runtime/registries/close-writers/*` | Close/result writer lookup and report-path helper | retained runner, core-v2 compose/close executor, flow close writers, cross-report validators, tests | Result writers and evidence-link path generation depend on it | `src/flows/registries/close-writers/*` |
docs/architecture/v2-registry-ownership-plan.md:33:| `src/runtime/registries/verification-writers/*` | Verification writer lookup and writer type surface | retained verification handler, core-v2 verification executor, flow verification writers, tests | Verification report writing is shared runtime behavior | `src/flows/registries/verification-writers/*` |
docs/architecture/v2-registry-ownership-plan.md:34:| `src/runtime/registries/checkpoint-writers/*` | Checkpoint brief writer lookup and writer type surface | retained checkpoint handler, core-v2 checkpoint executor, run status projection, Build checkpoint writer, tests | Checkpoint brief writing and status projection still rely on it | `src/flows/registries/checkpoint-writers/*` |
docs/architecture/v2-registry-ownership-plan.md:35:| `src/runtime/registries/report-schemas.ts` | Relay report schema parse registry | retained relay/fanout handlers, core-v2 relay executor, report composition tests, connector smoke fingerprints | Fail-closed report parsing is a runtime safety boundary | `src/flows/registries/report-schemas.ts` |
docs/architecture/v2-registry-ownership-plan.md:36:| `src/runtime/registries/cross-report-validators.ts` | Cross-report validator registry | retained relay/fanout handlers, core-v2 relay executor, Sweep validators/tests | Enforces multi-report invariants that Zod cannot express alone | `src/flows/registries/cross-report-validators.ts` |
docs/architecture/v2-registry-ownership-plan.md:37:| `src/runtime/registries/shape-hints/*` | Relay shape hint lookup | shared relay prompt support, flow relay hints, tests | Prompt materialization still depends on flow-owned shape hints | `src/flows/registries/shape-hints/*` |
docs/architecture/v2-registry-ownership-plan.md:68:2. Move type-only registry surfaces first, with `src/runtime/registries/**`
src/runtime/registries/compose-writers/types.ts:17:// src/runtime/registries/close-writers/. The two registries are intentionally
docs/architecture/v2-worklog.md:588:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-worklog.md:991:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:1087:`src/runtime/connectors/shared.ts` without moving connector subprocess modules
docs/architecture/v2-worklog.md:1092:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1102:- `src/shared/connector-relay.ts`
docs/architecture/v2-worklog.md:1103:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1130:`RelayResult`, and `sha256Hex` now live in `src/shared/connector-relay.ts`;
docs/architecture/v2-worklog.md:1131:`src/runtime/connectors/shared.ts` re-exports them for retained runtime and
docs/architecture/v2-worklog.md:1152:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1162:- `src/shared/connector-helpers.ts`
docs/architecture/v2-worklog.md:1163:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1193:`extractJsonObject` now live in `src/shared/connector-helpers.ts`;
docs/architecture/v2-worklog.md:1194:`src/runtime/connectors/shared.ts` re-exports them for retained runtime and old
docs/architecture/v2-worklog.md:1218:- `src/runtime/connectors/relay-materializer.ts`
docs/architecture/v2-worklog.md:1219:- `src/runtime/connectors/shared.ts`
docs/architecture/v2-worklog.md:1220:- `src/runtime/registries/**`
docs/architecture/v2-worklog.md:1279:- `src/runtime/config-loader.ts`
docs/architecture/v2-worklog.md:1286:- `src/shared/config-loader.ts`
docs/architecture/v2-worklog.md:1287:- `src/runtime/config-loader.ts`
docs/architecture/v2-worklog.md:1300:`src/shared/config-loader.ts`; `src/runtime/config-loader.ts` re-exports it for
docs/architecture/v2-worklog.md:1321:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:1329:- `src/shared/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:1330:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:1351:lives in `src/shared/operator-summary-writer.ts`; `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:1373:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-worklog.md:1382:- `src/shared/manifest-snapshot.ts`
docs/architecture/v2-worklog.md:1383:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-worklog.md:1403:read/write/hash helper now lives in `src/shared/manifest-snapshot.ts`;
docs/architecture/v2-worklog.md:1404:`src/runtime/manifest-snapshot-writer.ts` re-exports it for compatibility.
docs/architecture/v2-worklog.md:1427:- `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-worklog.md:1438:- `src/shared/flow-kind-policy.ts`
docs/architecture/v2-worklog.md:1439:- `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-worklog.md:1463:now lives in `src/shared/flow-kind-policy.ts`; `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-worklog.md:2143:- `src/runtime/registries/`
src/cli/circuit.ts:400:  // Validator: src/shared/flow-kind-policy.ts.
src/runtime/connectors/relay-materializer.ts:97:// registry at `src/runtime/registries/report-schemas.ts`; unknown schema names
src/runtime/connectors/shared.ts:10:// `src/shared/connector-relay.ts`; connector parsing/model helpers live in
src/runtime/connectors/shared.ts:11:// `src/shared/connector-helpers.ts`. Subprocess connector modules and relay
src/flows/explore/contract.md:369:`src/runtime/registries/report-schemas.ts`. The canonical report at
src/flows/explore/contract.md:387:`src/runtime/registries/report-schemas.ts` carries the strict
tests/runner/relay-shape-hint-registry.test.ts:20:} from '../../src/runtime/registries/shape-hints/registry.js';
tests/runner/relay-shape-hint-registry.test.ts:21:import type { RelayStep } from '../../src/runtime/registries/shape-hints/types.js';
tests/runner/close-builder-registry.test.ts:21:import { findCloseBuilder } from '../../src/runtime/registries/close-writers/registry.js';
tests/runner/close-builder-registry.test.ts:22:import type { CloseBuilder } from '../../src/runtime/registries/close-writers/types.js';
tests/runner/compose-builder-registry.test.ts:15:import { findComposeBuilder } from '../../src/runtime/registries/compose-writers/registry.js';
tests/runner/compose-builder-registry.test.ts:16:import type { ComposeBuilder } from '../../src/runtime/registries/compose-writers/types.js';
tests/runner/catalog-derivations.test.ts:21:import type { CheckpointBriefBuilder } from '../../src/runtime/registries/checkpoint-writers/types.js';
tests/runner/catalog-derivations.test.ts:22:import type { CloseBuilder } from '../../src/runtime/registries/close-writers/types.js';
tests/runner/catalog-derivations.test.ts:23:import type { ComposeBuilder } from '../../src/runtime/registries/compose-writers/types.js';
tests/runner/catalog-derivations.test.ts:24:import type { StructuralShapeHint } from '../../src/runtime/registries/shape-hints/types.js';
tests/runner/catalog-derivations.test.ts:25:import type { VerificationBuilder } from '../../src/runtime/registries/verification-writers/types.js';
tests/runner/catalog-derivations.test.ts:461:      '../../src/runtime/registries/compose-writers/registry.js'
tests/runner/catalog-derivations.test.ts:464:      '../../src/runtime/registries/close-writers/registry.js'
tests/runner/catalog-derivations.test.ts:467:      '../../src/runtime/registries/verification-writers/registry.js'
tests/runner/catalog-derivations.test.ts:470:      '../../src/runtime/registries/checkpoint-writers/registry.js'
tests/runner/codex-relay-roundtrip.test.ts:62://   (b) src/shared/connector-relay.ts — sha256Hex + RelayResult
tests/runner/codex-relay-roundtrip.test.ts:64://   (c) src/shared/connector-helpers.ts — connector parsing/model helpers
tests/runner/codex-relay-roundtrip.test.ts:65://   (d) src/runtime/connectors/shared.ts — compatibility re-exports used by
tests/runner/codex-relay-roundtrip.test.ts:67://   (e) src/runtime/connectors/relay-materializer.ts — five-trace_entry
tests/runner/codex-relay-roundtrip.test.ts:81:  resolve('src/shared/connector-relay.ts'),
tests/runner/codex-relay-roundtrip.test.ts:82:  resolve('src/shared/connector-helpers.ts'),
tests/runner/codex-relay-roundtrip.test.ts:83:  resolve('src/runtime/connectors/shared.ts'),
tests/runner/codex-relay-roundtrip.test.ts:84:  resolve('src/runtime/connectors/relay-materializer.ts'),
tests/runner/codex-relay-roundtrip.test.ts:86:  resolve('src/runtime/registries/report-schemas.ts'),
tests/contracts/explore-report-composition.test.ts:5:import { findCloseBuilder } from '../../src/runtime/registries/close-writers/registry.js';
tests/contracts/explore-report-composition.test.ts:6:import { findComposeBuilder } from '../../src/runtime/registries/compose-writers/registry.js';
tests/contracts/explore-report-composition.test.ts:7:import { parseReport } from '../../src/runtime/registries/report-schemas.js';
tests/runner/cross-report-validators.test.ts:6:import { reportPathForSchemaInCompiledFlow } from '../../src/runtime/registries/close-writers/shared.js';
tests/runner/cross-report-validators.test.ts:7:import { runCrossReportValidator } from '../../src/runtime/registries/cross-report-validators.js';
docs/architecture/v2-checkpoint-4.19.md:17:- `src/shared/flow-kind-policy.ts`
docs/architecture/v2-checkpoint-4.19.md:21:- `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-checkpoint-4.19.md:43:`src/runtime/policy/flow-kind-policy.ts` is now a compatibility wrapper. Keep
tests/runner/explore-e2e-parity.test.ts:51:  'src/shared/connector-relay.ts',
tests/runner/explore-e2e-parity.test.ts:52:  'src/shared/connector-helpers.ts',
tests/runner/explore-e2e-parity.test.ts:53:  'src/runtime/connectors/shared.ts',
tests/runner/explore-e2e-parity.test.ts:54:  'src/runtime/connectors/relay-materializer.ts',
tests/runner/explore-e2e-parity.test.ts:56:  'src/runtime/registries/report-schemas.ts',
```
