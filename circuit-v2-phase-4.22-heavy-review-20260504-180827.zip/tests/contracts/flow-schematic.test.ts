import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

import { FlowBlockCatalog } from '../../src/schemas/flow-blocks.js';
import {
  FlowSchematic,
  validateFlowSchematicCatalogCompatibility,
} from '../../src/schemas/flow-schematic.js';
import { StepId } from '../../src/schemas/ids.js';

const blockCatalogPath = 'docs/flows/block-catalog.json';
const fixSchematicPath = 'src/flows/fix/schematic.json';

function readJson(path: string): unknown {
  return JSON.parse(readFileSync(path, 'utf8')) as unknown;
}

function parseBlockCatalog() {
  return FlowBlockCatalog.parse(readJson(blockCatalogPath));
}

function parseFixSchematic() {
  return FlowSchematic.parse(readJson(fixSchematicPath));
}

describe('flow schematic schema — active Fix schematic', () => {
  it('parses the active Fix schematic', () => {
    const schematic = parseFixSchematic();
    expect(schematic.schema_version).toBe('1');
    expect(schematic.id as unknown as string).toBe('fix');
    expect(schematic.status).toBe('active');
    expect(schematic.starts_at as unknown as string).toBe('fix-frame');
  });

  it('keeps the Fix schematic compatible with the block catalog', () => {
    const issues = validateFlowSchematicCatalogCompatibility(
      parseFixSchematic(),
      parseBlockCatalog(),
    );
    expect(issues).toEqual([]);
  });

  it('keeps Fix human-decision evidence bound through a generic evidence alias', () => {
    const schematic = parseFixSchematic();
    expect(schematic.contract_aliases).toContainEqual({
      generic: 'flow.evidence@v1',
      actual: 'fix.diagnosis@v1',
    });
  });

  it('uses the expected Fix block sequence', () => {
    const schematic = parseFixSchematic();
    expect(schematic.items.map((item) => item.block)).toEqual([
      'frame',
      'gather-context',
      'diagnose',
      'human-decision',
      'act',
      'run-verification',
      'review',
      'close-with-evidence',
      'close-with-evidence',
      'handoff',
    ]);
  });

  it('keeps Fix stage bindings aligned with the intended flow shape', () => {
    const schematic = parseFixSchematic();
    expect(schematic.items.map((item) => [item.id as unknown as string, item.stage])).toEqual([
      ['fix-frame', 'frame'],
      ['fix-gather-context', 'analyze'],
      ['fix-diagnose', 'analyze'],
      ['fix-no-repro-decision', 'analyze'],
      ['fix-act', 'act'],
      ['fix-verify', 'verify'],
      ['fix-review', 'review'],
      ['fix-close-lite', 'close'],
      ['fix-close', 'close'],
      ['fix-handoff', 'close'],
    ]);
  });

  it('keeps Fix execution bindings aligned with the intended compiler shape', () => {
    const schematic = parseFixSchematic();
    expect(schematic.items.map((item) => [item.id as unknown as string, item.execution])).toEqual([
      ['fix-frame', { kind: 'compose' }],
      ['fix-gather-context', { kind: 'relay', role: 'researcher' }],
      ['fix-diagnose', { kind: 'relay', role: 'researcher' }],
      ['fix-no-repro-decision', { kind: 'checkpoint' }],
      ['fix-act', { kind: 'relay', role: 'implementer' }],
      ['fix-verify', { kind: 'verification' }],
      ['fix-review', { kind: 'relay', role: 'reviewer' }],
      ['fix-close-lite', { kind: 'compose' }],
      ['fix-close', { kind: 'compose' }],
      ['fix-handoff', { kind: 'compose' }],
    ]);
  });

  it('keeps Fix close inputs aligned with the evidence path (lite skips review)', () => {
    const schematic = parseFixSchematic();
    const closeLite = schematic.items.find(
      (item) => (item.id as unknown as string) === 'fix-close-lite',
    );
    const close = schematic.items.find((item) => (item.id as unknown as string) === 'fix-close');
    if (closeLite === undefined) throw new Error('fix-close-lite missing');
    if (close === undefined) throw new Error('fix-close missing');

    expect(closeLite.input).toMatchObject({
      brief: 'fix.brief@v1',
      context: 'fix.context@v1',
      diagnosis: 'fix.diagnosis@v1',
      change: 'fix.change@v1',
      verification: 'fix.verification@v1',
    });
    expect(closeLite.input).not.toHaveProperty('review');
    expect(close.input).toMatchObject({
      brief: 'fix.brief@v1',
      context: 'fix.context@v1',
      diagnosis: 'fix.diagnosis@v1',
      change: 'fix.change@v1',
      verification: 'fix.verification@v1',
      review: 'fix.review@v1',
    });
  });

  it('routes Lite verification directly to a no-review close item via route_overrides', () => {
    const schematic = parseFixSchematic();
    const verify = schematic.items.find((item) => (item.id as unknown as string) === 'fix-verify');
    if (verify === undefined) throw new Error('fix-verify missing');

    expect(verify.routes.continue).toBe('fix-review');
    expect(verify.route_overrides).toEqual({
      continue: {
        lite: 'fix-close-lite',
      },
    });
  });

  it('rejects an unknown route target at parse time', () => {
    const raw = readJson(fixSchematicPath) as Record<string, unknown>;
    const items = raw.items as Array<Record<string, unknown>>;
    const first = items[0];
    if (first === undefined) throw new Error('fixture missing first item');
    first.routes = { continue: 'missing-item' };
    const result = FlowSchematic.safeParse(raw);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(/unknown schematic item id/);
    }
  });

  it('rejects an unknown route override target at parse time', () => {
    const raw = readJson(fixSchematicPath) as Record<string, unknown>;
    const items = raw.items as Array<Record<string, unknown>>;
    const verify = items.find((item) => item.id === 'fix-verify');
    if (verify === undefined) throw new Error('fixture missing verify item');
    verify.route_overrides = { continue: { lite: 'missing-item' } };
    const result = FlowSchematic.safeParse(raw);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(
        /route override target references unknown schematic item/,
      );
    }
  });

  it('rejects route overrides for undeclared route outcomes', () => {
    const raw = readJson(fixSchematicPath) as Record<string, unknown>;
    const items = raw.items as Array<Record<string, unknown>>;
    const verify = items.find((item) => item.id === 'fix-verify');
    if (verify === undefined) throw new Error('fixture missing verify item');
    verify.route_overrides = { split: { lite: 'fix-close-lite' } };
    const result = FlowSchematic.safeParse(raw);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(/route override must target a declared route outcome/);
    }
  });

  it('rejects duplicate evidence requirements at parse time', () => {
    const raw = readJson(fixSchematicPath) as Record<string, unknown>;
    const items = raw.items as Array<Record<string, unknown>>;
    const diagnose = items.find((item) => item.id === 'fix-diagnose');
    if (diagnose === undefined) throw new Error('fixture missing diagnose item');
    diagnose.evidence_requirements = ['confidence', 'confidence'];

    const result = FlowSchematic.safeParse(raw);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(/duplicate evidence requirement/);
    }
  });

  it('rejects relay execution without a role at parse time', () => {
    const raw = readJson(fixSchematicPath) as Record<string, unknown>;
    const items = raw.items as Array<Record<string, unknown>>;
    const act = items.find((item) => item.id === 'fix-act');
    if (act === undefined) throw new Error('fixture missing act item');
    act.execution = { kind: 'relay' };

    const result = FlowSchematic.safeParse(raw);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(/"path":\s*\[\s*"items",\s*4,\s*"execution",\s*"role"/);
      expect(result.error.message).toMatch(/Required/);
    }
  });

  it('rejects relay roles on non-relay execution at parse time', () => {
    const raw = readJson(fixSchematicPath) as Record<string, unknown>;
    const items = raw.items as Array<Record<string, unknown>>;
    const frame = items.find((item) => item.id === 'fix-frame');
    if (frame === undefined) throw new Error('fixture missing frame item');
    frame.execution = { kind: 'compose', role: 'researcher' };

    const result = FlowSchematic.safeParse(raw);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(/Unrecognized key\(s\) in object: 'role'/);
    }
  });

  it('reports route outcomes that the selected block does not allow', () => {
    const schematic = parseFixSchematic();
    const frame = schematic.items.find((item) => (item.id as unknown as string) === 'fix-frame');
    if (frame === undefined) throw new Error('fix-frame missing');
    frame.routes = { ...frame.routes, complete: '@complete' };
    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toContainEqual({
      item_id: 'fix-frame',
      message: 'route "complete" is not allowed by block "frame"',
    });
  });

  it('reports schematic items that omit block evidence requirements', () => {
    const schematic = parseFixSchematic();
    const diagnose = schematic.items.find(
      (item) => (item.id as unknown as string) === 'fix-diagnose',
    );
    if (diagnose === undefined) throw new Error('fix-diagnose missing');
    diagnose.evidence_requirements = ['cause hypothesis'];

    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toContainEqual({
      item_id: 'fix-diagnose',
      message:
        'evidence requirement "confidence" from block "diagnose" is not declared by schematic item',
    });
  });

  it('reports execution kinds that do not match the selected block surface', () => {
    const schematic = parseFixSchematic();
    const act = schematic.items.find((item) => (item.id as unknown as string) === 'fix-act');
    if (act === undefined) throw new Error('fix-act missing');
    act.execution = { kind: 'checkpoint' };

    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toContainEqual({
      item_id: 'fix-act',
      message:
        'execution kind "checkpoint" is not compatible with block "act"; expected one of relay, compose, fanout',
    });
  });

  it('reports stage bindings that do not match the selected block', () => {
    const schematic = parseFixSchematic();
    const act = schematic.items.find((item) => (item.id as unknown as string) === 'fix-act');
    if (act === undefined) throw new Error('fix-act missing');
    act.stage = 'analyze';

    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toContainEqual({
      item_id: 'fix-act',
      message: 'stage "analyze" is not compatible with block "act"; expected one of act',
    });
  });

  it('reports run-verification items that do not bind to verification execution', () => {
    const schematic = parseFixSchematic();
    const verify = schematic.items.find((item) => (item.id as unknown as string) === 'fix-verify');
    if (verify === undefined) throw new Error('fix-verify missing');
    verify.execution = { kind: 'compose' };

    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toContainEqual({
      item_id: 'fix-verify',
      message:
        'execution kind "compose" is not compatible with block "run-verification"; expected one of verification',
    });
  });

  it('reports unavailable input contracts in schematic order', () => {
    const schematic = parseFixSchematic();
    const diagnose = schematic.items.find(
      (item) => (item.id as unknown as string) === 'fix-diagnose',
    );
    if (diagnose === undefined) throw new Error('fix-diagnose missing');
    diagnose.input.context = 'missing.context@v1';
    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toContainEqual({
      item_id: 'fix-diagnose',
      message:
        'input "context" references unavailable contract "missing.context@v1" on at least one reachable route',
    });
    expect(issues).toContainEqual({
      item_id: 'fix-diagnose',
      message:
        'inputs do not satisfy block "diagnose"; expected one of [flow.brief@v1, context.packet@v1]',
    });
  });

  it('reports schematic items that omit every accepted block input set', () => {
    const schematic = parseFixSchematic();
    const act = schematic.items.find((item) => (item.id as unknown as string) === 'fix-act');
    if (act === undefined) throw new Error('fix-act missing');
    act.input = { brief: 'fix.brief@v1' };

    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toContainEqual({
      item_id: 'fix-act',
      message:
        'inputs do not satisfy block "act"; expected one of [flow.brief@v1, diagnosis.result@v1] or [flow.brief@v1, plan.strategy@v1] or [flow.brief@v1, plan.strategy@v1, diagnosis.result@v1]',
    });
  });

  it('reports inputs that are skipped by a reachable route', () => {
    const schematic = parseFixSchematic();
    const verify = schematic.items.find((item) => (item.id as unknown as string) === 'fix-verify');
    if (verify === undefined) throw new Error('fix-verify missing');
    verify.routes.continue = StepId.parse('fix-close');

    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toContainEqual({
      item_id: 'fix-close',
      message:
        'input "review" references unavailable contract "fix.review@v1" on at least one reachable route',
    });
  });

  it('reports schematic items that cannot be reached from starts_at', () => {
    const schematic = parseFixSchematic();
    const frame = schematic.items.find((item) => (item.id as unknown as string) === 'fix-frame');
    if (frame === undefined) throw new Error('fix-frame missing');
    frame.routes = { stop: '@stop' };

    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toContainEqual({
      item_id: 'fix-gather-context',
      message: 'schematic item is unreachable from starts_at',
    });
  });

  it('reports outputs that are not block outputs or declared aliases', () => {
    const schematic = parseFixSchematic();
    const close = schematic.items.find((item) => (item.id as unknown as string) === 'fix-close');
    if (close === undefined) throw new Error('fix-close missing');
    close.output = 'wrong.result@v1';
    const issues = validateFlowSchematicCatalogCompatibility(schematic, parseBlockCatalog());
    expect(issues).toEqual([
      {
        item_id: 'fix-close',
        message: 'output "wrong.result@v1" is not compatible with block output "flow.result@v1"',
      },
    ]);
  });
});

// Compiler-required metadata. These fields are optional at parse time to
// avoid breaking candidate schematics mid-upgrade, but their cross-field
// shape (kind ↔ writes, kind ↔ check, checkpoint_policy ↔ checkpoint kind)
// is enforced when present so authors get clear feedback.
describe('flow schematic compiler-required metadata', () => {
  function frameItemWithExtras(extras: Record<string, unknown>): Record<string, unknown> {
    return {
      id: 'a-frame',
      block: 'frame',
      title: 'Frame',
      stage: 'frame',
      input: {},
      output: 'flow.brief@v1',
      evidence_requirements: ['scope boundary', 'constraints', 'proof plan'],
      execution: { kind: 'compose' },
      routes: { continue: '@complete' },
      ...extras,
    };
  }

  function actItemWithExtras(extras: Record<string, unknown>): Record<string, unknown> {
    return {
      id: 'a-act',
      block: 'act',
      title: 'Act',
      stage: 'act',
      input: { brief: 'flow.brief@v1', plan: 'plan.strategy@v1' },
      output: 'change.evidence@v1',
      evidence_requirements: ['changed files', 'change rationale', 'declared follow-up proof'],
      execution: { kind: 'relay', role: 'implementer' },
      routes: { continue: '@complete' },
      ...extras,
    };
  }

  function baseSchematic(items: Array<Record<string, unknown>>): Record<string, unknown> {
    return {
      schema_version: '1',
      id: 'demo',
      title: 'Demo',
      purpose: 'demo',
      status: 'candidate',
      starts_at: items[0]?.id,
      initial_contracts: [],
      contract_aliases: [],
      items,
    };
  }

  it('accepts a compose item with required check, schema-sections writes, and protocol', () => {
    const schematic = baseSchematic([
      frameItemWithExtras({
        protocol: 'demo-frame@v1',
        writes: { report_path: 'reports/brief.json' },
        check: { required: ['scope', 'constraints'] },
      }),
    ]);
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(true);
  });

  it('rejects compose item missing writes.report_path', () => {
    const schematic = baseSchematic([
      frameItemWithExtras({
        writes: {},
        check: { required: ['scope'] },
      }),
    ]);
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(/compose execution requires writes\.report_path/);
    }
  });

  it('rejects compose item with check.allow (checkpoint-only field)', () => {
    const schematic = baseSchematic([
      frameItemWithExtras({
        writes: { report_path: 'reports/brief.json' },
        check: { required: ['scope'], allow: ['continue'] },
      }),
    ]);
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(/check\.allow is only allowed for checkpoint execution/);
    }
  });

  it('accepts a relay item with full path slots and check.pass', () => {
    const schematic = baseSchematic([
      actItemWithExtras({
        protocol: 'demo-act@v1',
        writes: {
          report_path: 'reports/change.json',
          request_path: 'reports/relay/act.request.json',
          receipt_path: 'reports/relay/act.receipt.txt',
          result_path: 'reports/relay/act.result.json',
        },
        check: { pass: ['accept'] },
      }),
    ]);
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(true);
  });

  it('rejects relay item missing receipt_path', () => {
    const schematic = baseSchematic([
      actItemWithExtras({
        writes: {
          request_path: 'reports/relay/act.request.json',
          result_path: 'reports/relay/act.result.json',
        },
        check: { pass: ['accept'] },
      }),
    ]);
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(/relay execution requires writes\.receipt_path/);
    }
  });

  it('rejects relay item with check.required (compose-only field)', () => {
    const schematic = baseSchematic([
      actItemWithExtras({
        writes: {
          request_path: 'reports/relay/act.request.json',
          receipt_path: 'reports/relay/act.receipt.txt',
          result_path: 'reports/relay/act.result.json',
        },
        check: { pass: ['accept'], required: ['summary'] },
      }),
    ]);
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(
        /check\.required is only allowed for compose\|verification execution/,
      );
    }
  });

  it('rejects checkpoint_policy on non-checkpoint execution', () => {
    const schematic = baseSchematic([
      frameItemWithExtras({
        writes: { report_path: 'reports/brief.json' },
        check: { required: ['scope'] },
        checkpoint_policy: {
          prompt: 'go?',
          choices: [{ id: 'continue' }],
        },
      }),
    ]);
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(
        /checkpoint_policy is only allowed for checkpoint execution/,
      );
    }
  });

  it('accepts schematic-level entry, entry_modes, stage_path_policy, stages', () => {
    const schematic = {
      ...baseSchematic([
        frameItemWithExtras({
          writes: { report_path: 'reports/brief.json' },
          check: { required: ['scope'] },
        }),
      ]),
      version: '0.1.0',
      entry: { signals: { include: ['demo'], exclude: [] }, intent_prefixes: ['demo'] },
      entry_modes: [{ name: 'default', depth: 'standard', description: 'default mode' }],
      stage_path_policy: {
        mode: 'partial',
        omits: ['analyze', 'plan', 'act', 'verify', 'review', 'close'],
        rationale: 'demo schematic with only a frame stage for testing',
      },
      stages: [{ canonical: 'frame', id: 'frame-stage', title: 'Frame' }],
    };
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(true);
  });

  it('rejects duplicate entry mode names', () => {
    const schematic = {
      ...baseSchematic([
        frameItemWithExtras({
          writes: { report_path: 'reports/brief.json' },
          check: { required: ['scope'] },
        }),
      ]),
      entry_modes: [
        { name: 'default', depth: 'standard', description: 'a' },
        { name: 'default', depth: 'lite', description: 'b' },
      ],
    };
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(/duplicate entry mode name: default/);
    }
  });

  it('rejects stages entry mismatch with item stage usage', () => {
    const schematic = {
      ...baseSchematic([
        frameItemWithExtras({
          writes: { report_path: 'reports/brief.json' },
          check: { required: ['scope'] },
        }),
      ]),
      stages: [{ canonical: 'analyze', id: 'analyze-stage', title: 'Analyze' }],
    };
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(
        /stages is missing an entry for canonical stage 'frame'/,
      );
    }
  });

  it('rejects stage_path_policy.omits that includes a used canonical stage', () => {
    const schematic = {
      ...baseSchematic([
        frameItemWithExtras({
          writes: { report_path: 'reports/brief.json' },
          check: { required: ['scope'] },
        }),
      ]),
      stage_path_policy: {
        mode: 'partial',
        omits: ['frame'],
        rationale: 'invalid omit because frame is used by an item',
      },
    };
    const result = FlowSchematic.safeParse(schematic);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.message).toMatch(
        /canonical stage 'frame' is omitted but used by at least one item/,
      );
    }
  });
});
