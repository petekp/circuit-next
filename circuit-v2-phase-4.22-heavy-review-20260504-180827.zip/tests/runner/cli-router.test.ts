import { execFileSync } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

import { main } from '../../src/cli/circuit.js';
import { ReviewIntake } from '../../src/flows/review/reports.js';
import type { RelayResult } from '../../src/runtime/connectors/shared.js';
import type { RelayFn, RelayInput } from '../../src/runtime/runner.js';
import { ProgressEvent } from '../../src/schemas/progress-event.js';

const EXPLORE_SYNTHESIS_BODY = JSON.stringify({
  verdict: 'accept',
  subject: 'CLI-routed explore goal',
  recommendation: 'Return the requested exploration summary',
  success_condition_alignment: 'The response satisfies the exploratory goal',
  supporting_aspects: [
    {
      aspect: 'routing',
      contribution: 'The explore flow reached the synthesize step',
      evidence_refs: ['reports/analysis.json'],
    },
  ],
});

const EXPLORE_REVIEW_VERDICT_BODY = JSON.stringify({
  verdict: 'accept',
  overall_assessment: 'The exploratory compose is acceptable',
  objections: [],
  missed_angles: [],
});

const BUILD_IMPLEMENTATION_BODY = JSON.stringify({
  verdict: 'accept',
  summary: 'Implemented the requested change',
  changed_files: ['src/example.ts'],
  evidence: ['Stub implementation relay completed'],
});

const BUILD_REVIEW_BODY = JSON.stringify({
  verdict: 'accept',
  summary: 'No blocking issue found',
  findings: [],
});

function deterministicNow(startMs: number): () => Date {
  let n = 0;
  return () => new Date(startMs + n++ * 1000);
}

function relayerWithBody(body: string): RelayFn {
  return {
    connectorName: 'claude-code',
    relay: async (input: RelayInput): Promise<RelayResult> => ({
      request_payload: input.prompt,
      receipt_id: 'stub-receipt-cli-router',
      result_body:
        input.prompt.includes('Step: act-step') && body === '{"verdict":"accept"}'
          ? BUILD_IMPLEMENTATION_BODY
          : input.prompt.includes('Step: review-step') &&
              input.prompt.includes('build.review@v1') &&
              body === '{"verdict":"accept"}'
            ? BUILD_REVIEW_BODY
            : input.prompt.includes('Step: synthesize-step') && body === '{"verdict":"accept"}'
              ? EXPLORE_SYNTHESIS_BODY
              : input.prompt.includes('Step: review-step') && body === '{"verdict":"accept"}'
                ? EXPLORE_REVIEW_VERDICT_BODY
                : body,
      duration_ms: 1,
      cli_version: '0.0.0-stub',
    }),
  };
}

function tournamentRelayer(): RelayFn {
  return {
    connectorName: 'claude-code',
    relay: async (input: RelayInput): Promise<RelayResult> => {
      const proposal = (option_id: string, option_label: string, case_summary: string) => ({
        verdict: 'accept',
        option_id,
        option_label,
        case_summary,
        assumptions: ['The operator accepts the stated tradeoff.'],
        evidence_refs: ['reports/decision-options.json'],
        risks: ['The proof fixture only covers synthetic decision evidence.'],
        next_action: `Run a Build plan for ${option_label}.`,
      });
      if (input.prompt.includes('Step: proposal-fanout-step-option-1')) {
        return {
          request_payload: input.prompt,
          receipt_id: 'stub-tournament-option-1',
          result_body: JSON.stringify(
            proposal('option-1', 'React', 'Choose React for ecosystem depth.'),
          ),
          duration_ms: 1,
          cli_version: '0.0.0-stub',
        };
      }
      if (input.prompt.includes('Step: proposal-fanout-step-option-2')) {
        return {
          request_payload: input.prompt,
          receipt_id: 'stub-tournament-option-2',
          result_body: JSON.stringify(
            proposal('option-2', 'Vue', 'Choose Vue for iteration speed.'),
          ),
          duration_ms: 1,
          cli_version: '0.0.0-stub',
        };
      }
      if (input.prompt.includes('Step: proposal-fanout-step-option-3')) {
        return {
          request_payload: input.prompt,
          receipt_id: 'stub-tournament-option-3',
          result_body: JSON.stringify(
            proposal('option-3', 'Hybrid path', 'Prototype both paths before choosing.'),
          ),
          duration_ms: 1,
          cli_version: '0.0.0-stub',
        };
      }
      if (input.prompt.includes('Step: proposal-fanout-step-option-4')) {
        return {
          request_payload: input.prompt,
          receipt_id: 'stub-tournament-option-4',
          result_body: JSON.stringify(
            proposal('option-4', 'Defer pending evidence', 'Gather missing constraints first.'),
          ),
          duration_ms: 1,
          cli_version: '0.0.0-stub',
        };
      }
      return {
        request_payload: input.prompt,
        receipt_id: 'stub-tournament-review',
        result_body: JSON.stringify({
          verdict: 'recommend',
          recommended_option_id: 'option-1',
          comparison: 'React carries ecosystem depth while Vue carries speed.',
          objections: ['The choice lacks a spike.'],
          missing_evidence: ['No production spike exists.'],
          tradeoff_question: 'Choose ecosystem depth or iteration speed.',
          confidence: 'medium',
        }),
        duration_ms: 1,
        cli_version: '0.0.0-stub',
      };
    },
  };
}

function migrateCliRelayer(): RelayFn {
  return {
    connectorName: 'claude-code',
    relay: async (input: RelayInput): Promise<RelayResult> => {
      if (input.prompt.includes('Step: inventory-step')) {
        return {
          request_payload: input.prompt,
          receipt_id: 'stub-cli-migrate-inventory',
          result_body: JSON.stringify({
            verdict: 'accept',
            summary: 'One legacy API site found for the CLI proof.',
            items: [
              {
                id: 'item-1',
                path: 'src/legacy-api.ts',
                category: 'import-site',
                description: 'Legacy API import site.',
              },
            ],
            batches: [
              {
                id: 'batch-1',
                title: 'Replace the legacy API import',
                item_ids: ['item-1'],
                rationale: 'Single safe batch for the CLI proof.',
              },
            ],
          }),
          duration_ms: 1,
          cli_version: '0.0.0-stub',
        };
      }

      if (
        input.prompt.includes('Step: review-step') &&
        input.prompt.includes('Accepted verdicts: cutover-approved, cutover-with-followups')
      ) {
        return {
          request_payload: input.prompt,
          receipt_id: 'stub-cli-migrate-review',
          result_body: JSON.stringify({
            verdict: 'cutover-approved',
            summary: 'Cutover approved for the synthetic migration.',
            findings: [],
          }),
          duration_ms: 1,
          cli_version: '0.0.0-stub',
        };
      }

      if (input.prompt.includes('Step: act-step')) {
        return {
          request_payload: input.prompt,
          receipt_id: 'stub-cli-build-act',
          result_body: BUILD_IMPLEMENTATION_BODY,
          duration_ms: 1,
          cli_version: '0.0.0-stub',
        };
      }

      if (input.prompt.includes('Step: review-step') && input.prompt.includes('build.review@v1')) {
        return {
          request_payload: input.prompt,
          receipt_id: 'stub-cli-build-review',
          result_body: BUILD_REVIEW_BODY,
          duration_ms: 1,
          cli_version: '0.0.0-stub',
        };
      }

      throw new Error(`unexpected migrate CLI relay prompt: ${input.prompt.slice(0, 240)}`);
    },
  };
}

function traceEntryLog(runFolder: string): Array<Record<string, unknown>> {
  return readFileSync(join(runFolder, 'trace.ndjson'), 'utf8')
    .trim()
    .split('\n')
    .filter((line) => line.length > 0)
    .map((line) => JSON.parse(line) as Record<string, unknown>);
}

function writeCliFixFixture(path: string): void {
  mkdirSync(dirname(path), { recursive: true });
  const composeStep = (id: string, title: string, reportPath: string, next: string) => ({
    id,
    title,
    protocol: `${id}@v1`,
    reads: [],
    routes: { pass: next },
    executor: 'orchestrator',
    kind: 'compose',
    writes: { report: { path: reportPath, schema: 'fix.brief@v1' } },
    check: {
      kind: 'schema_sections',
      source: { kind: 'report', ref: 'report' },
      required: ['problem_statement', 'success_criteria'],
    },
  });
  const steps = [
    composeStep('frame-step', 'Frame', 'reports/fix/frame-brief.json', 'analyze-step'),
    composeStep('analyze-step', 'Analyze', 'reports/fix/analyze-brief.json', 'act-step'),
    composeStep('act-step', 'Fix', 'reports/fix/act-brief.json', 'verify-step'),
    composeStep('verify-step', 'Verify', 'reports/fix/verify-brief.json', 'review-step'),
    composeStep('review-step', 'Review', 'reports/fix/review-brief.json', 'close-step'),
    composeStep('close-step', 'Close', 'reports/fix/close-brief.json', '@complete'),
  ];

  writeFileSync(
    path,
    `${JSON.stringify(
      {
        schema_version: '2',
        id: 'fix',
        version: '0.1.0',
        purpose: 'CLI router test fixture for Fix entry-mode selection.',
        entry: { signals: { include: [], exclude: [] }, intent_prefixes: [] },
        entry_modes: [
          {
            name: 'default',
            start_at: 'frame-step',
            depth: 'standard',
            description: 'Default Fix test mode.',
          },
          {
            name: 'lite',
            start_at: 'frame-step',
            depth: 'lite',
            description: 'Lite Fix test mode.',
          },
          {
            name: 'deep',
            start_at: 'frame-step',
            depth: 'deep',
            description: 'Deep Fix test mode.',
          },
        ],
        stages: [
          { id: 'frame-stage', title: 'Frame', canonical: 'frame', steps: ['frame-step'] },
          {
            id: 'analyze-stage',
            title: 'Analyze',
            canonical: 'analyze',
            steps: ['analyze-step'],
          },
          { id: 'act-stage', title: 'Fix', canonical: 'act', steps: ['act-step'] },
          { id: 'verify-stage', title: 'Verify', canonical: 'verify', steps: ['verify-step'] },
          { id: 'review-stage', title: 'Review', canonical: 'review', steps: ['review-step'] },
          { id: 'close-stage', title: 'Close', canonical: 'close', steps: ['close-step'] },
        ],
        stage_path_policy: {
          mode: 'partial',
          omits: ['plan'],
          rationale: 'CLI test fixture: Fix folds planning into diagnosis.',
        },
        steps,
      },
      null,
      2,
    )}\n`,
  );
}

async function runMainJson(
  argv: readonly string[],
  relayBody: string,
  options: { readonly configCwd?: string } = {},
): Promise<Record<string, unknown>> {
  let captured = '';
  const origWrite = process.stdout.write;
  process.stdout.write = ((chunk: string | Uint8Array): boolean => {
    captured += typeof chunk === 'string' ? chunk : Buffer.from(chunk).toString('utf8');
    return true;
  }) as typeof process.stdout.write;
  try {
    const exit = await main(argv, {
      relayer: relayerWithBody(relayBody),
      now: deterministicNow(Date.UTC(2026, 3, 24, 15, 0, 0)),
      runId: '84000000-0000-0000-0000-000000000001',
      configHomeDir: join(runFolderBase, 'empty-home'),
      configCwd: options.configCwd ?? process.cwd(),
    });
    expect(exit).toBe(0);
  } finally {
    process.stdout.write = origWrite;
  }

  const parsed: unknown = JSON.parse(captured);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('CLI output was not a JSON object');
  }
  return parsed as Record<string, unknown>;
}

async function runMainJsonWithRelayer(
  argv: readonly string[],
  relayer: RelayFn,
): Promise<Record<string, unknown>> {
  let captured = '';
  const origWrite = process.stdout.write;
  process.stdout.write = ((chunk: string | Uint8Array): boolean => {
    captured += typeof chunk === 'string' ? chunk : Buffer.from(chunk).toString('utf8');
    return true;
  }) as typeof process.stdout.write;
  try {
    const exit = await main(argv, {
      relayer,
      now: deterministicNow(Date.UTC(2026, 3, 24, 15, 0, 0)),
      runId: '84000000-0000-0000-0000-000000000001',
      configHomeDir: join(runFolderBase, 'empty-home'),
      configCwd: process.cwd(),
    });
    expect(exit).toBe(0);
  } finally {
    process.stdout.write = origWrite;
  }
  return JSON.parse(captured) as Record<string, unknown>;
}

async function runMainJsonWithRelayerAndProgress(
  argv: readonly string[],
  relayer: RelayFn,
): Promise<{ output: Record<string, unknown>; progress: Array<ProgressEvent> }> {
  let stdout = '';
  let stderr = '';
  const origStdoutWrite = process.stdout.write;
  const origStderrWrite = process.stderr.write;
  process.stdout.write = ((chunk: string | Uint8Array): boolean => {
    stdout += typeof chunk === 'string' ? chunk : Buffer.from(chunk).toString('utf8');
    return true;
  }) as typeof process.stdout.write;
  process.stderr.write = ((chunk: string | Uint8Array): boolean => {
    stderr += typeof chunk === 'string' ? chunk : Buffer.from(chunk).toString('utf8');
    return true;
  }) as typeof process.stderr.write;
  try {
    const exit = await main(argv, {
      relayer,
      now: deterministicNow(Date.UTC(2026, 3, 24, 15, 0, 0)),
      runId: '84000000-0000-0000-0000-000000000001',
      configHomeDir: join(runFolderBase, 'empty-home'),
      configCwd: process.cwd(),
    });
    expect(exit).toBe(0);
  } finally {
    process.stdout.write = origStdoutWrite;
    process.stderr.write = origStderrWrite;
  }

  const output = JSON.parse(stdout) as Record<string, unknown>;
  const progress = stderr
    .trim()
    .split('\n')
    .filter((line) => line.length > 0)
    .map((line) => ProgressEvent.parse(JSON.parse(line)));
  return { output, progress };
}

async function runMainJsonWithProgress(
  argv: readonly string[],
  relayBody: string,
): Promise<{ output: Record<string, unknown>; progress: Array<ProgressEvent> }> {
  let stdout = '';
  let stderr = '';
  const origStdoutWrite = process.stdout.write;
  const origStderrWrite = process.stderr.write;
  process.stdout.write = ((chunk: string | Uint8Array): boolean => {
    stdout += typeof chunk === 'string' ? chunk : Buffer.from(chunk).toString('utf8');
    return true;
  }) as typeof process.stdout.write;
  process.stderr.write = ((chunk: string | Uint8Array): boolean => {
    stderr += typeof chunk === 'string' ? chunk : Buffer.from(chunk).toString('utf8');
    return true;
  }) as typeof process.stderr.write;
  try {
    const exit = await main(argv, {
      relayer: relayerWithBody(relayBody),
      now: deterministicNow(Date.UTC(2026, 3, 24, 15, 0, 0)),
      runId: '84000000-0000-0000-0000-000000000001',
      configHomeDir: join(runFolderBase, 'empty-home'),
      configCwd: process.cwd(),
    });
    expect(exit).toBe(0);
  } finally {
    process.stdout.write = origStdoutWrite;
    process.stderr.write = origStderrWrite;
  }

  const output = JSON.parse(stdout) as Record<string, unknown>;
  const progress = stderr
    .trim()
    .split('\n')
    .filter((line) => line.length > 0)
    .map((line) => ProgressEvent.parse(JSON.parse(line)));
  return { output, progress };
}

async function runMainExit(argv: readonly string[]): Promise<{ exit: number; stderr: string }> {
  let stderr = '';
  const origWrite = process.stderr.write;
  process.stderr.write = ((chunk: string | Uint8Array): boolean => {
    stderr += typeof chunk === 'string' ? chunk : Buffer.from(chunk).toString('utf8');
    return true;
  }) as typeof process.stderr.write;
  try {
    const exit = await main(argv, {
      relayer: relayerWithBody('{"verdict":"accept"}'),
      now: deterministicNow(Date.UTC(2026, 3, 24, 15, 0, 0)),
      runId: '84000000-0000-0000-0000-000000000099',
      configHomeDir: join(runFolderBase, 'empty-home'),
      configCwd: process.cwd(),
    });
    return { exit, stderr };
  } finally {
    process.stderr.write = origWrite;
  }
}

let runFolderBase: string;

beforeEach(() => {
  runFolderBase = mkdtempSync(join(tmpdir(), 'circuit-next-cli-router-'));
});

afterEach(() => {
  rmSync(runFolderBase, { recursive: true, force: true });
});

describe('CLI router', () => {
  it('omitted flow positional routes review-like goals through the classifier', async () => {
    const output = await runMainJson(
      [
        '--goal',
        'review this patch for safety problems',
        '--run-folder',
        join(runFolderBase, 'review'),
      ],
      '{"verdict":"NO_ISSUES_FOUND","findings":[]}',
    );

    expect(output.flow_id).toBe('review');
    expect(output.selected_flow).toBe('review');
    expect(output.routed_by).toBe('classifier');
    expect(output.router_reason).toMatch(/review/i);
    expect(output.router_signal).toBeDefined();
    expect(output.outcome).toBe('complete');
  });

  it('emits parseable progress JSONL to stderr without changing final stdout JSON', async () => {
    const runFolder = join(runFolderBase, 'review-progress-jsonl');
    const { output, progress } = await runMainJsonWithProgress(
      [
        '--goal',
        'review this patch for safety problems',
        '--progress',
        'jsonl',
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"NO_ISSUES_FOUND","findings":[]}',
    );

    expect(output.flow_id).toBe('review');
    expect(output.selected_flow).toBe('review');
    expect(output.outcome).toBe('complete');
    expect(typeof output.operator_summary_path).toBe('string');
    expect(typeof output.operator_summary_markdown_path).toBe('string');
    expect(existsSync(output.operator_summary_path as string)).toBe(true);
    expect(existsSync(output.operator_summary_markdown_path as string)).toBe(true);
    expect(progress.map((event) => event.type)).toEqual(
      expect.arrayContaining([
        'route.selected',
        'run.started',
        'task_list.updated',
        'step.started',
        'relay.started',
        'relay.completed',
        'run.completed',
      ]),
    );
    expect(progress.slice(0, 3).map((event) => event.type)).toEqual([
      'route.selected',
      'run.started',
      'task_list.updated',
    ]);
    const progressTypes = progress.map((event) => event.type);
    expect(progressTypes.indexOf('step.started')).toBeLessThan(
      progressTypes.indexOf('relay.started'),
    );
    expect(progressTypes.indexOf('relay.started')).toBeLessThan(
      progressTypes.indexOf('relay.completed'),
    );
    expect(progressTypes.indexOf('relay.completed')).toBeLessThan(
      progressTypes.indexOf('run.completed'),
    );
    expect(progress.every((event) => event.display.text.length > 0)).toBe(true);
    expect(progress.find((event) => event.type === 'route.selected')?.display.text).toContain(
      'Circuit selected review',
    );
    const taskListEvents = progress.filter((event) => event.type === 'task_list.updated');
    expect(taskListEvents.length).toBeGreaterThan(1);
    expect(taskListEvents[0]?.tasks.every((task) => task.status === 'pending')).toBe(true);
    expect(
      taskListEvents.some((event) => event.tasks.some((task) => task.status === 'in_progress')),
    ).toBe(true);
    expect(
      taskListEvents.some((event) => event.tasks.some((task) => task.status === 'completed')),
    ).toBe(true);
    expect(progress.find((event) => event.type === 'relay.started')).toMatchObject({
      role: 'reviewer',
      connector_name: 'claude-code',
      filesystem_capability: 'trusted-write',
      display: {
        importance: 'major',
        tone: 'info',
      },
    });
    expect(progress.find((event) => event.type === 'step.started')).toMatchObject({
      step_id: 'intake-step',
      step_title: 'Intake — resolve review scope',
      attempt: 1,
    });
  });

  it('routes decide: through the public CLI to the Explore tournament fixture', async () => {
    const runFolder = join(runFolderBase, 'explore-tournament-cli');
    const output = await runMainJsonWithRelayer(
      ['--goal', 'decide: React vs Vue', '--run-folder', runFolder],
      tournamentRelayer(),
    );

    const trace_entries = traceEntryLog(runFolder);
    const bootstrap = trace_entries.find((trace_entry) => trace_entry.kind === 'run.bootstrapped');
    const stressReview = trace_entries.find(
      (trace_entry) =>
        trace_entry.kind === 'relay.completed' && trace_entry.step_id === 'stress-proposals-step',
    );
    expect(output.flow_id).toBe('explore');
    expect(output.selected_flow).toBe('explore');
    expect(output.entry_mode).toBe('tournament');
    expect(output.entry_mode_source).toBe('classifier');
    expect(output.outcome).toBe('checkpoint_waiting');
    expect(output.checkpoint).toMatchObject({
      step_id: 'tradeoff-checkpoint-step',
      allowed_choices: ['option-1', 'option-2', 'option-3', 'option-4'],
    });
    expect(bootstrap).toMatchObject({ depth: 'tournament' });
    expect(stressReview).toBeDefined();
  });

  it('surfaces actual tournament option labels in checkpoint user input', async () => {
    const runFolder = join(runFolderBase, 'explore-tournament-progress');
    const { output, progress } = await runMainJsonWithRelayerAndProgress(
      ['--goal', 'decide: React vs Vue', '--run-folder', runFolder, '--progress', 'jsonl'],
      tournamentRelayer(),
    );

    expect(output.outcome).toBe('checkpoint_waiting');
    const waiting = progress.find((event) => event.type === 'checkpoint.waiting');
    expect(waiting?.display.text).toContain('React, Vue');
    const userInput = progress.find((event) => event.type === 'user_input.requested');
    if (userInput?.type !== 'user_input.requested') {
      throw new Error('expected user_input.requested progress event');
    }
    const [question] = userInput.questions;
    expect(question?.question).toContain('ecosystem depth or iteration speed');
    expect(question?.options.map((option) => option.label)).toEqual([
      'React',
      'Vue',
      'Hybrid path',
      'Defer pending evidence',
    ]);
    expect(question?.options.map((option) => option.checkpoint_choice)).toEqual([
      'option-1',
      'option-2',
      'option-3',
      'option-4',
    ]);
    expect(typeof output.operator_summary_markdown_path).toBe('string');
    const markdown = readFileSync(output.operator_summary_markdown_path as string, 'utf8');
    expect(markdown).toContain('Checkpoint options: React (option-1); Vue (option-2)');
  });

  it('resolves sub-run child flows through the public CLI', async () => {
    const runFolder = join(runFolderBase, 'migrate-cli-sub-run');
    const output = await runMainJsonWithRelayer(
      ['migrate', '--goal', 'migrate a tiny legacy API', '--run-folder', runFolder],
      migrateCliRelayer(),
    );

    const trace_entries = traceEntryLog(runFolder);
    expect(output.flow_id).toBe('migrate');
    expect(output.selected_flow).toBe('migrate');
    expect(output.outcome).toBe('complete');
    expect(output.result_path).toBe(join(runFolder, 'reports/result.json'));
    expect(trace_entries).toContainEqual(
      expect.objectContaining({
        kind: 'sub_run.started',
        step_id: 'batch-step',
        child_flow_id: 'build',
        child_entry_mode: 'default',
      }),
    );
    expect(existsSync(join(runFolder, 'reports/migrate/batch-result.json'))).toBe(true);
    expect(existsSync(join(runFolder, 'reports/migrate-result.json'))).toBe(true);
  }, 180_000);

  it('passes explicit untracked-content opt-in to Review evidence intake', async () => {
    const projectRoot = join(runFolderBase, 'review-untracked-cli-project');
    const runFolder = join(runFolderBase, 'review-untracked-cli-run');
    const scratch = 'CLI flag explicitly allowed this untracked content';
    mkdirSync(projectRoot, { recursive: true });
    execFileSync('git', ['init'], { cwd: projectRoot, stdio: 'pipe' });
    writeFileSync(join(projectRoot, 'scratch.txt'), `${scratch}\n`);

    const output = await runMainJson(
      [
        'review',
        '--goal',
        'review this untracked scratch file',
        '--include-untracked-content',
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"NO_ISSUES_FOUND","findings":[]}',
      { configCwd: projectRoot },
    );

    const intake = ReviewIntake.parse(
      JSON.parse(readFileSync(join(runFolder, 'reports', 'review-intake.json'), 'utf8')),
    );
    expect(intake.evidence.kind).toBe('git-working-tree');
    if (intake.evidence.kind !== 'git-working-tree') return;
    expect(intake.evidence.untracked_content_policy).toBe('include-content');
    expect(intake.evidence.untracked_files[0]).toMatchObject({
      path: 'scratch.txt',
      content: { text: `${scratch}\n`, truncated: false },
    });
    expect(typeof output.operator_summary_markdown_path).toBe('string');
    const markdown = readFileSync(output.operator_summary_markdown_path as string, 'utf8');
    expect(markdown).toContain('Untracked evidence: contents included for 1 file');
  });

  it('emits run.aborted progress when a run aborts', async () => {
    const { output, progress } = await runMainJsonWithProgress(
      [
        'review',
        '--goal',
        'review this malformed relay body',
        '--progress',
        'jsonl',
        '--run-folder',
        join(runFolderBase, 'review-progress-aborted'),
      ],
      '{"verdict":"NO_ISSUES_FOUND","findings":"not-an-array"}',
    );

    expect(output.outcome).toBe('aborted');
    expect(typeof output.operator_summary_markdown_path).toBe('string');
    expect(progress.map((event) => event.type)).toContain('run.aborted');
    expect(progress.find((event) => event.type === 'run.aborted')?.display.tone).toBe('error');
    const lastTaskList = progress.filter((event) => event.type === 'task_list.updated').at(-1);
    expect(lastTaskList?.tasks.some((task) => task.status === 'failed')).toBe(true);
  });

  it('omitted flow positional keeps exploratory goals on explore', async () => {
    const output = await runMainJson(
      ['--goal', 'map the current project state', '--run-folder', join(runFolderBase, 'explore')],
      '{"verdict":"accept"}',
    );

    expect(output.flow_id).toBe('explore');
    expect(output.selected_flow).toBe('explore');
    expect(output.routed_by).toBe('classifier');
    expect(output.router_signal).toBeUndefined();
    expect(output.outcome).toBe('complete');
  });

  it('omitted flow positional routes build-like goals through the classifier', async () => {
    const output = await runMainJson(
      ['--goal', 'develop: add a focused feature', '--run-folder', join(runFolderBase, 'build')],
      '{"verdict":"accept"}',
    );

    expect(output.flow_id).toBe('build');
    expect(output.selected_flow).toBe('build');
    expect(output.routed_by).toBe('classifier');
    expect(output.router_reason).toMatch(/implementation Build flow/i);
    expect(output.router_signal).toBeDefined();
    expect(output.outcome).toBe('complete');
  });

  it('omitted flow positional preserves router metadata on Build checkpoint_waiting output', async () => {
    const runFolder = join(runFolderBase, 'build-router-checkpoint-waiting');
    const output = await runMainJson(
      [
        '--goal',
        'develop: add a focused feature that waits for framing',
        '--depth',
        'deep',
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );

    expect(output.schema_version).toBe(1);
    expect(output.flow_id).toBe('build');
    expect(output.selected_flow).toBe('build');
    expect(output.routed_by).toBe('classifier');
    expect(output.router_reason).toMatch(/implementation Build flow/i);
    expect(output.router_signal).toBeDefined();
    expect(output.outcome).toBe('checkpoint_waiting');
    expect(output).not.toHaveProperty('result_path');
    expect(output.checkpoint).toMatchObject({
      step_id: 'frame-step',
      request_path: join(runFolder, 'reports/checkpoints/frame-step-request.json'),
      allowed_choices: ['continue'],
    });
  });

  it('emits checkpoint.waiting progress for paused checkpoint runs', async () => {
    const runFolder = join(runFolderBase, 'build-router-checkpoint-progress');
    const { output, progress } = await runMainJsonWithProgress(
      [
        '--goal',
        'develop: add a focused feature that waits for framing',
        '--depth',
        'deep',
        '--progress',
        'jsonl',
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );

    expect(output.outcome).toBe('checkpoint_waiting');
    expect(typeof output.operator_summary_markdown_path).toBe('string');
    expect(existsSync(output.operator_summary_markdown_path as string)).toBe(true);
    expect(progress).toContainEqual(
      expect.objectContaining({
        type: 'run.started',
        display: expect.objectContaining({
          tone: 'warning',
          text: expect.stringContaining('write-capable Claude Code worker'),
        }),
      }),
    );
    expect(progress).toContainEqual(
      expect.objectContaining({
        type: 'checkpoint.waiting',
        step_id: 'frame-step',
        allowed_choices: ['continue'],
        display: expect.objectContaining({ tone: 'checkpoint' }),
      }),
    );
    expect(progress).toContainEqual(
      expect.objectContaining({
        type: 'user_input.requested',
        checkpoint: expect.objectContaining({
          step_id: 'frame-step',
          request_path: join(runFolder, 'reports/checkpoints/frame-step-request.json'),
          allowed_choices: ['continue'],
        }),
        questions: [
          expect.objectContaining({
            id: 'checkpoint-choice',
            header: 'Choice',
            allow_free_text: false,
            options: [
              expect.objectContaining({
                label: 'Continue',
                checkpoint_choice: 'continue',
              }),
            ],
          }),
        ],
        resume: expect.objectContaining({
          run_folder: runFolder,
          checkpoint_choice_arg: '<choice>',
        }),
        display: expect.objectContaining({ tone: 'checkpoint' }),
      }),
    );
  });

  it('omitted flow positional keeps develop-prefixed planning goals on explore', async () => {
    const output = await runMainJson(
      [
        '--goal',
        'develop: create a new endpoint RFC',
        '--run-folder',
        join(runFolderBase, 'develop-planning'),
      ],
      '{"verdict":"accept"}',
    );

    expect(output.flow_id).toBe('explore');
    expect(output.selected_flow).toBe('explore');
    expect(output.routed_by).toBe('classifier');
    expect(output.router_signal).toBeUndefined();
    expect(output.outcome).toBe('complete');
  });

  it('omitted flow positional starts a flow for plan-execution requests', async () => {
    const output = await runMainJson(
      [
        '--goal',
        'Execute this plan: ./docs/specs/headless-engine-host-api-v1.md',
        '--run-folder',
        join(runFolderBase, 'plan-execution'),
      ],
      '{"verdict":"accept"}',
    );

    expect(output.flow_id).toBe('build');
    expect(output.selected_flow).toBe('build');
    expect(output.routed_by).toBe('classifier');
    expect(output.router_signal).toBe('plan-execution');
    expect(output.entry_mode).toBe('default');
    expect(output.entry_mode_source).toBe('classifier');
    expect(output.router_reason).toMatch(/first executable slice/i);
    expect(output.outcome).toBe('complete');
  });

  it('explicit flow positional bypasses the classifier', async () => {
    const output = await runMainJson(
      [
        'explore',
        '--goal',
        'review this patch for safety problems',
        '--run-folder',
        join(runFolderBase, 'explicit-explore'),
      ],
      '{"verdict":"accept"}',
    );

    expect(output.flow_id).toBe('explore');
    expect(output.selected_flow).toBe('explore');
    expect(output.routed_by).toBe('explicit');
    expect(output.router_reason).toMatch(/explicit flow/i);
    expect(output.router_signal).toBeUndefined();
  });

  it('run --goal routes through the classifier', async () => {
    const output = await runMainJson(
      [
        'run',
        '--goal',
        'review this patch for safety problems',
        '--run-folder',
        join(runFolderBase, 'run-routed-review'),
      ],
      '{"verdict":"NO_ISSUES_FOUND","findings":[]}',
    );

    expect(output.flow_id).toBe('review');
    expect(output.routed_by).toBe('classifier');
    expect(output.outcome).toBe('complete');
  });

  it('run <flow> --goal bypasses the classifier', async () => {
    const output = await runMainJson(
      [
        'run',
        'explore',
        '--goal',
        'review this patch for safety problems',
        '--run-folder',
        join(runFolderBase, 'run-explicit-explore'),
      ],
      '{"verdict":"accept"}',
    );

    expect(output.flow_id).toBe('explore');
    expect(output.routed_by).toBe('explicit');
  });

  it('uses classifier-inferred Fix lite mode only for explicit quick Fix intent', async () => {
    const fixturePath = join(runFolderBase, 'fixtures', 'fix.json');
    const runFolder = join(runFolderBase, 'fix-lite-inferred');
    writeCliFixFixture(fixturePath);

    const { output, progress } = await runMainJsonWithProgress(
      [
        '--goal',
        'quick fix: restore the missing token edge case',
        '--fixture',
        fixturePath,
        '--progress',
        'jsonl',
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );

    const bootstrap = traceEntryLog(runFolder).find(
      (trace_entry) => trace_entry.kind === 'run.bootstrapped',
    );
    expect(output.flow_id).toBe('fix');
    expect(output.routed_by).toBe('classifier');
    expect(output.entry_mode).toBe('lite');
    expect(output.entry_mode_source).toBe('classifier');
    expect(bootstrap).toMatchObject({ depth: 'lite' });
    expect(progress.find((event) => event.type === 'route.selected')).toMatchObject({
      entry_mode: 'lite',
      entry_mode_source: 'classifier',
    });
  });

  it('uses classifier-inferred Fix deep mode for bare serious Fix intent', async () => {
    const fixturePath = join(runFolderBase, 'fixtures', 'fix-deep-inferred.json');
    const runFolder = join(runFolderBase, 'fix-deep-inferred');
    writeCliFixFixture(fixturePath);

    const { output, progress } = await runMainJsonWithProgress(
      [
        '--goal',
        'fix: restore the missing token regression test',
        '--fixture',
        fixturePath,
        '--progress',
        'jsonl',
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );

    const bootstrap = traceEntryLog(runFolder).find(
      (trace_entry) => trace_entry.kind === 'run.bootstrapped',
    );
    expect(output.flow_id).toBe('fix');
    expect(output.routed_by).toBe('classifier');
    expect(output.entry_mode).toBe('deep');
    expect(output.entry_mode_source).toBe('classifier');
    expect(bootstrap).toMatchObject({ depth: 'deep' });
    expect(progress.find((event) => event.type === 'route.selected')).toMatchObject({
      entry_mode: 'deep',
      entry_mode_source: 'classifier',
    });
  });

  it('lets explicit --mode override classifier-inferred Fix mode', async () => {
    const fixturePath = join(runFolderBase, 'fixtures', 'fix-explicit-default.json');
    const runFolder = join(runFolderBase, 'fix-explicit-default-mode');
    writeCliFixFixture(fixturePath);

    const output = await runMainJson(
      [
        '--goal',
        'fix: restore the missing token regression test',
        '--mode',
        'default',
        '--fixture',
        fixturePath,
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );

    const bootstrap = traceEntryLog(runFolder).find(
      (trace_entry) => trace_entry.kind === 'run.bootstrapped',
    );
    expect(output.flow_id).toBe('fix');
    expect(output.entry_mode).toBe('default');
    expect(output.entry_mode_source).toBe('explicit');
    expect(bootstrap).toMatchObject({ depth: 'standard' });
  });

  it('lets explicit --depth suppress classifier-inferred Fix mode', async () => {
    const fixturePath = join(runFolderBase, 'fixtures', 'fix-explicit-depth.json');
    const runFolder = join(runFolderBase, 'fix-explicit-depth');
    writeCliFixFixture(fixturePath);

    const output = await runMainJson(
      [
        '--goal',
        'fix: restore the missing token regression test',
        '--depth',
        'deep',
        '--fixture',
        fixturePath,
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );

    const bootstrap = traceEntryLog(runFolder).find(
      (trace_entry) => trace_entry.kind === 'run.bootstrapped',
    );
    expect(output.flow_id).toBe('fix');
    expect(output.entry_mode).toBeUndefined();
    expect(output.entry_mode_source).toBeUndefined();
    expect(bootstrap).toMatchObject({ depth: 'deep' });
  });

  it('accepts --entry-mode and uses that mode depth when --depth is omitted', async () => {
    const runFolder = join(runFolderBase, 'build-lite-entry-mode');
    const output = await runMainJson(
      [
        'build',
        '--goal',
        'Add a tiny Build feature from the CLI',
        '--entry-mode',
        'lite',
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );

    const trace_entries = traceEntryLog(runFolder);
    const bootstrap = trace_entries.find((trace_entry) => trace_entry.kind === 'run.bootstrapped');
    const relayStarted = trace_entries.find(
      (trace_entry) => trace_entry.kind === 'relay.started' && trace_entry.step_id === 'act-step',
    );
    const relayResolvedSelection =
      relayStarted?.resolved_selection ??
      (relayStarted?.data as { readonly resolved_selection?: unknown } | undefined)
        ?.resolved_selection;
    expect(output.flow_id).toBe('build');
    expect(output.outcome).toBe('complete');
    expect(bootstrap).toMatchObject({ depth: 'lite' });
    expect(relayResolvedSelection).toMatchObject({ depth: 'lite' });
  });

  it('lets --depth override the selected --entry-mode default', async () => {
    const runFolder = join(runFolderBase, 'build-entry-mode-depth-override');
    const output = await runMainJson(
      [
        'build',
        '--goal',
        'Add a tiny Build feature from the CLI with an override',
        '--entry-mode',
        'deep',
        '--depth',
        'standard',
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );

    const trace_entries = traceEntryLog(runFolder);
    const bootstrap = trace_entries.find((trace_entry) => trace_entry.kind === 'run.bootstrapped');
    const relayStarted = trace_entries.find(
      (trace_entry) => trace_entry.kind === 'relay.started' && trace_entry.step_id === 'act-step',
    );
    expect(output.flow_id).toBe('build');
    expect(output.outcome).toBe('complete');
    expect(bootstrap).toMatchObject({ depth: 'standard' });
    expect(relayStarted?.resolved_selection).toMatchObject({ depth: 'standard' });
  });

  it('lets explicit autonomous --depth override the default --entry-mode through checkpoint policy', async () => {
    const runFolder = join(runFolderBase, 'build-default-entry-autonomous-override');
    const output = await runMainJson(
      [
        'build',
        '--goal',
        'Add a tiny Build feature from the CLI with autonomous override',
        '--entry-mode',
        'default',
        '--depth',
        'autonomous',
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );

    const trace_entries = traceEntryLog(runFolder);
    const bootstrap = trace_entries.find((trace_entry) => trace_entry.kind === 'run.bootstrapped');
    const checkpoint = trace_entries.find(
      (trace_entry) =>
        trace_entry.kind === 'checkpoint.resolved' && trace_entry.step_id === 'frame-step',
    );
    const relayStarted = trace_entries.find(
      (trace_entry) => trace_entry.kind === 'relay.started' && trace_entry.step_id === 'act-step',
    );
    expect(output.flow_id).toBe('build');
    expect(output.outcome).toBe('complete');
    expect(bootstrap).toMatchObject({ depth: 'autonomous' });
    expect(checkpoint).toMatchObject({ resolution_source: 'safe-autonomous' });
    expect(relayStarted?.resolved_selection).toMatchObject({ depth: 'autonomous' });
  });

  it('rejects fixture overrides whose flow id does not match the selected flow', async () => {
    await expect(
      main(
        [
          '--goal',
          'review this patch for safety problems',
          '--fixture',
          'generated/flows/explore/circuit.json',
          '--run-folder',
          join(runFolderBase, 'mismatch'),
        ],
        {
          relayer: relayerWithBody('{"verdict":"accept"}'),
          now: deterministicNow(Date.UTC(2026, 3, 24, 15, 0, 0)),
          runId: '84000000-0000-0000-0000-000000000004',
          configHomeDir: join(runFolderBase, 'empty-home'),
          configCwd: join(runFolderBase, 'empty-cwd'),
        },
      ),
    ).rejects.toThrow(/flow fixture id mismatch/i);
  });

  it('rejects an unknown --entry-mode before writing a run trace', async () => {
    const runFolder = join(runFolderBase, 'unknown-build-entry-mode');
    await expect(
      main(
        [
          'build',
          '--goal',
          'Try a missing Build entry mode',
          '--entry-mode',
          'missing',
          '--run-folder',
          runFolder,
        ],
        {
          relayer: relayerWithBody('{"verdict":"accept"}'),
          now: deterministicNow(Date.UTC(2026, 3, 24, 15, 0, 0)),
          runId: '84000000-0000-0000-0000-000000000005',
          configHomeDir: join(runFolderBase, 'empty-home'),
          configCwd: join(runFolderBase, 'empty-cwd'),
        },
      ),
    ).rejects.toThrow(/entry_mode named 'missing'/);
    expect(() => traceEntryLog(runFolder)).toThrow();
  });

  it('prints a versioned checkpoint_waiting envelope without result_path', async () => {
    const fixtureDir = join(runFolderBase, 'fixture');
    mkdirSync(fixtureDir, { recursive: true });
    const fixturePath = join(fixtureDir, 'circuit.json');
    writeFileSync(
      fixturePath,
      JSON.stringify({
        schema_version: '2',
        id: 'build-checkpoint-cli-test',
        version: '0.1.0',
        purpose: 'test CLI checkpoint waiting envelope',
        entry: { signals: { include: [], exclude: [] }, intent_prefixes: [] },
        entry_modes: [
          {
            name: 'default',
            start_at: 'frame-step',
            depth: 'standard',
            description: 'test entry mode',
          },
        ],
        stages: [
          {
            id: 'frame-stage',
            title: 'Frame',
            canonical: 'frame',
            steps: ['frame-step'],
          },
        ],
        stage_path_policy: {
          mode: 'partial',
          omits: ['analyze', 'plan', 'act', 'verify', 'review', 'close'],
          rationale: 'test-only checkpoint waiting envelope.',
        },
        steps: [
          {
            id: 'frame-step',
            title: 'Frame',
            protocol: 'build-frame@v1',
            reads: [],
            routes: { pass: '@complete' },
            executor: 'orchestrator',
            kind: 'checkpoint',
            policy: {
              prompt: 'Frame',
              choices: [{ id: 'continue' }],
              safe_default_choice: 'continue',
              report_template: {
                scope: 'CLI envelope test',
                success_criteria: ['Envelope is shaped'],
                verification_command_candidates: [
                  {
                    id: 'verify',
                    cwd: '.',
                    argv: [process.execPath, '-e', "process.stdout.write('ok')"],
                    timeout_ms: 1_000,
                    max_output_bytes: 20_000,
                    env: {},
                  },
                ],
              },
            },
            writes: {
              request: 'reports/checkpoints/frame-step-request.json',
              response: 'reports/checkpoints/frame-step-response.json',
              report: { path: 'reports/build/brief.json', schema: 'build.brief@v1' },
            },
            check: {
              kind: 'checkpoint_selection',
              source: { kind: 'checkpoint_response', ref: 'response' },
              allow: ['continue'],
            },
          },
        ],
      }),
    );

    const output = await runMainJson(
      [
        'build-checkpoint-cli-test',
        '--goal',
        'Frame via CLI',
        '--depth',
        'deep',
        '--fixture',
        fixturePath,
        '--run-folder',
        join(runFolderBase, 'checkpoint-waiting'),
      ],
      '{"verdict":"accept"}',
    );

    expect(output.schema_version).toBe(1);
    expect(output.outcome).toBe('checkpoint_waiting');
    expect(output).not.toHaveProperty('result_path');
    expect(output.checkpoint).toMatchObject({
      step_id: 'frame-step',
      allowed_choices: ['continue'],
    });
  });

  it('resumes a checkpoint_waiting run from the saved manifest and operator choice', async () => {
    const fixtureDir = join(runFolderBase, 'resume-fixture');
    mkdirSync(fixtureDir, { recursive: true });
    const fixturePath = join(fixtureDir, 'circuit.json');
    writeFileSync(
      fixturePath,
      JSON.stringify({
        schema_version: '2',
        id: 'build-checkpoint-cli-resume-test',
        version: '0.1.0',
        purpose: 'test CLI checkpoint resume',
        entry: { signals: { include: [], exclude: [] }, intent_prefixes: [] },
        entry_modes: [
          {
            name: 'default',
            start_at: 'frame-step',
            depth: 'standard',
            description: 'test entry mode',
          },
        ],
        stages: [
          {
            id: 'frame-stage',
            title: 'Frame',
            canonical: 'frame',
            steps: ['frame-step'],
          },
        ],
        stage_path_policy: {
          mode: 'partial',
          omits: ['analyze', 'plan', 'act', 'verify', 'review', 'close'],
          rationale: 'test-only checkpoint resume.',
        },
        steps: [
          {
            id: 'frame-step',
            title: 'Frame',
            protocol: 'build-frame@v1',
            reads: [],
            routes: { pass: '@complete' },
            executor: 'orchestrator',
            kind: 'checkpoint',
            policy: {
              prompt: 'Frame',
              choices: [{ id: 'continue' }, { id: 'revise' }],
              safe_default_choice: 'continue',
              report_template: {
                scope: 'CLI resume test',
                success_criteria: ['Resume closes the run'],
                verification_command_candidates: [
                  {
                    id: 'verify',
                    cwd: '.',
                    argv: [process.execPath, '-e', "process.stdout.write('ok')"],
                    timeout_ms: 1_000,
                    max_output_bytes: 20_000,
                    env: {},
                  },
                ],
              },
            },
            writes: {
              request: 'reports/checkpoints/frame-step-request.json',
              response: 'reports/checkpoints/frame-step-response.json',
              report: { path: 'reports/build/brief.json', schema: 'build.brief@v1' },
            },
            check: {
              kind: 'checkpoint_selection',
              source: { kind: 'checkpoint_response', ref: 'response' },
              allow: ['continue', 'revise'],
            },
          },
        ],
      }),
    );
    const runFolder = join(runFolderBase, 'checkpoint-resume');

    const waiting = await runMainJson(
      [
        'build-checkpoint-cli-resume-test',
        '--goal',
        'Frame and resume via CLI',
        '--depth',
        'deep',
        '--fixture',
        fixturePath,
        '--run-folder',
        runFolder,
      ],
      '{"verdict":"accept"}',
    );
    expect(waiting.outcome).toBe('checkpoint_waiting');

    const resumed = await runMainJson(
      ['resume', '--run-folder', runFolder, '--checkpoint-choice', 'continue'],
      '{"verdict":"accept"}',
    );

    expect(resumed.schema_version).toBe(1);
    expect(resumed.outcome).toBe('complete');
    expect(resumed.run_folder).toBe(runFolder);
    expect(resumed).toHaveProperty('result_path');
  });

  it('rejects resume-only incompatible flags', async () => {
    const withDepth = await runMainExit([
      'resume',
      '--run-folder',
      join(runFolderBase, 'not-needed'),
      '--checkpoint-choice',
      'continue',
      '--depth',
      'deep',
    ]);
    expect(withDepth.exit).toBe(2);
    expect(withDepth.stderr).toMatch(/omit --depth/);

    const withFixture = await runMainExit([
      'resume',
      '--run-folder',
      join(runFolderBase, 'not-needed'),
      '--checkpoint-choice',
      'continue',
      '--fixture',
      join(runFolderBase, 'fixture.json'),
    ]);
    expect(withFixture.exit).toBe(2);
    expect(withFixture.stderr).toMatch(/omit --fixture/);

    const withEntryMode = await runMainExit([
      'resume',
      '--run-folder',
      join(runFolderBase, 'not-needed'),
      '--checkpoint-choice',
      'continue',
      '--entry-mode',
      'lite',
    ]);
    expect(withEntryMode.exit).toBe(2);
    expect(withEntryMode.stderr).toMatch(/omit --mode\/--entry-mode/);
  });

  it('rejects --depth on checkpoint resume', async () => {
    const withDepth = await runMainExit([
      'resume',
      '--run-folder',
      join(runFolderBase, 'not-needed'),
      '--checkpoint-choice',
      'continue',
      '--depth',
      'deep',
    ]);
    expect(withDepth.exit).toBe(2);
    expect(withDepth.stderr).toMatch(/omit --depth/);
  });

  it('accepts --mode as a synonym for --entry-mode', async () => {
    const withMode = await runMainExit([
      'resume',
      '--run-folder',
      join(runFolderBase, 'not-needed'),
      '--checkpoint-choice',
      'continue',
      '--mode',
      'lite',
    ]);
    expect(withMode.exit).toBe(2);
    expect(withMode.stderr).toMatch(/omit --mode\/--entry-mode/);
  });

  it('parses --run-folder before rejecting resume-only --depth', async () => {
    // Resume validates other flags after argv parsing; pairing --run-folder
    // with --depth exercises the downstream "omit --depth" branch. The
    // branch firing proves --run-folder parsed and populated the run-folder slot.
    const result = await runMainExit([
      'resume',
      '--run-folder',
      join(runFolderBase, 'not-needed'),
      '--checkpoint-choice',
      'continue',
      '--depth',
      'deep',
    ]);
    expect(result.exit).toBe(2);
    expect(result.stderr).toMatch(/omit --depth/);
  });

  it('rejects supplying --depth more than once', async () => {
    const conflict = await runMainExit([
      'resume',
      '--run-folder',
      join(runFolderBase, 'not-needed'),
      '--checkpoint-choice',
      'continue',
      '--depth',
      'standard',
      '--depth',
      'deep',
    ]);
    expect(conflict.exit).toBe(2);
    expect(conflict.stderr).toMatch(/supply --depth only once/);
  });

  it('rejects supplying both --mode and --entry-mode', async () => {
    const conflict = await runMainExit([
      'resume',
      '--run-folder',
      join(runFolderBase, 'not-needed'),
      '--checkpoint-choice',
      'continue',
      '--mode',
      'lite',
      '--entry-mode',
      'deep',
    ]);
    expect(conflict.exit).toBe(2);
    expect(conflict.stderr).toMatch(/use either --mode or --entry-mode, not both/);
  });

  it('rejects supplying --run-folder more than once', async () => {
    const conflict = await runMainExit([
      'resume',
      '--run-folder',
      join(runFolderBase, 'a'),
      '--run-folder',
      join(runFolderBase, 'b'),
      '--checkpoint-choice',
      'continue',
    ]);
    expect(conflict.exit).toBe(2);
    expect(conflict.stderr).toMatch(/supply --run-folder only once/);
  });

  it('keeps CLI help text aligned with the router-supported flow set', () => {
    const source = readFileSync(join(process.cwd(), 'src/cli/circuit.ts'), 'utf-8');
    expect(source).toContain('registered explore/review/fix/build/migrate/sweep flows');
    expect(source).not.toContain('registered explore/review/build flows');
    expect(source).not.toContain('registered explore/review flows');
  });
});
