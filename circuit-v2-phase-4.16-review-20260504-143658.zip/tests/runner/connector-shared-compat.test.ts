import { describe, expect, it } from 'vitest';

import { sha256Hex as runtimeSha256Hex } from '../../src/runtime/connectors/shared.js';
import { sha256Hex as sharedSha256Hex } from '../../src/shared/connector-relay.js';

describe('connector shared compatibility wrapper', () => {
  it('keeps sha256Hex identical through the shared and runtime paths', () => {
    const payload = 'circuit-next connector relay payload';

    expect(sharedSha256Hex(payload)).toBe(runtimeSha256Hex(payload));
    expect(sharedSha256Hex(payload)).toMatch(/^[0-9a-f]{64}$/);
  });
});
