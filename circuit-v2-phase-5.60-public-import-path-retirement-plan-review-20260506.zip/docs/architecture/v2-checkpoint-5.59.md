# Core-v2 Checkpoint 5.59: Public Import-Path Deprecation Artifact

Date: 2026-05-06

## Summary

Phase 5.59 promotes the existing low-risk old `src/runtime/**` soft-deprecated
path list to a public release-note deprecation document.

This is communication only. The old paths still work, wrapper files remain in
place, package exports are unchanged, and no import-time/runtime warnings are
emitted.

## What Changed

`docs/release/deprecations/public-runtime-import-paths.md` now records the public
soft-deprecation notice for the exact paths already marked
`deprecationStage: 'soft-deprecated'` in
`src/compat/public-runtime-paths.ts`.

`tests/runner/public-runtime-paths.test.ts` now proves:

- the release-note document exists;
- its deprecated import-path table matches exactly
  `PUBLIC_RUNTIME_SOFT_DEPRECATED_PATHS`;
- every deprecated old path appears with its replacement owner;
- no non-soft-deprecated old runtime path appears in the deprecated table;
- the document says old paths continue to work;
- the document says no import-time/runtime warning is emitted;
- the document says there is no wrapper deletion and no package export change;
- sensitive categories remain called out as not deprecated.

`docs/architecture/v2-public-runtime-import-path-policy.md` now points to the
release-note document instead of carrying draft release wording inline.

## Scope

Only the existing 15 shared-helper and flow-authoring wrapper paths are
release-note soft-deprecated. No connector, registry, run-status, result-writer,
public runner, retained handler, retained trace, retained checkpoint, or
saved-state path is deprecated.

## Proof

```bash
npx vitest run tests/runner/public-runtime-paths.test.ts
npx vitest run tests/runner/public-runtime-paths.test.ts tests/runner/retained-compat-facade.test.ts tests/runner/shared-helper-compat.test.ts tests/runner/catalog-derivations.test.ts tests/runner/connector-shared-compat.test.ts tests/runner/run-status-facade.test.ts tests/runner/result-path-compat.test.ts tests/runner/fanout-aggregate-compat.test.ts tests/runner/json-report-compat.test.ts tests/runner/recovery-route-compat.test.ts tests/runner/terminal-verdict-helper.test.ts tests/properties/visible/fanout-join-policy.test.ts
npm run check
npm run lint
npm run build
npx vitest run tests/contracts/terminology-active-surface.test.ts tests/runner/public-runtime-paths.test.ts
npm run verify
git diff --check
```

Passed.

## Non-Approvals

Phase 5.59 does not approve:

- deleting old `src/runtime/**` wrappers;
- retiring old public import paths;
- changing package exports;
- adding import-time or runtime deprecation warnings;
- deprecating connector wrappers;
- deprecating catalog or registry wrappers;
- deprecating `src/runtime/run-status-projection.ts`;
- deprecating `src/runtime/result-writer.ts`;
- deprecating `src/runtime/runner.ts` or `src/runtime/runner-types.ts`;
- deprecating retained handlers, trace, checkpoint, reducer, snapshot,
  progress, or saved-state paths;
- changing `composeWriter`;
- changing rollback;
- routing arbitrary fixtures or custom roots through v2 by default;
- changing retained/v1 checkpoint folder behavior;
- moving retained trace/reducer/snapshot/progress/checkpoint implementations;
- deleting retained runner/handler oracle tests;
- old runtime deletion.

## Next

Review is required before any stronger public import-path action: additional
deprecation categories, warnings, package export changes, wrapper deletion, old
import-path retirement, or old runtime deletion.
