import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { TERMINAL_TARGETS } from '../../src/core-v2/domain/route.js';
import type { TraceEntryV2 } from '../../src/core-v2/domain/trace.js';
import { createStubRelayConnectorV2 } from '../../src/core-v2/executors/relay.js';
import type { ExecutableFlowV2 } from '../../src/core-v2/manifest/executable-flow.js';
import { validateExecutableFlowV2 } from '../../src/core-v2/manifest/validate-executable-flow.js';
import { projectStatusFromTraceV2 } from '../../src/core-v2/projections/status.js';
import { RunFileStore } from '../../src/core-v2/run-files/run-file-store.js';
import { executeExecutableFlowV2 } from '../../src/core-v2/run/graph-runner.js';
import { TraceStore } from '../../src/core-v2/trace/trace-store.js';

async function withTempRun<T>(fn: (runDir: string) => Promise<T>): Promise<T> {
  const runDir = await mkdtemp(join(tmpdir(), 'circuit-core-v2-'));
  try {
    return await fn(runDir);
  } finally {
    await rm(runDir, { recursive: true, force: true });
  }
}

function validFlow(): ExecutableFlowV2 {
  return {
    id: 'baseline',
    version: '0.1.0',
    entry: 'compose',
    stages: [{ id: 'main', stepIds: ['compose', 'relay'] }],
    steps: [
      {
        id: 'compose',
        kind: 'compose',
        writer: 'baseline-writer',
        body: { ok: true },
        writes: { result: { path: 'reports/compose.json' } },
        routes: { pass: { kind: 'step', stepId: 'relay' } },
      },
      {
        id: 'relay',
        kind: 'relay',
        role: 'reviewer',
        prompt: 'inspect the composed file',
        writes: { report: { path: 'reports/relay.json' } },
        routes: { pass: { kind: 'terminal', target: '@complete' } },
      },
    ],
  };
}

describe('core-v2 baseline', () => {
  it('uses the v1 terminal target vocabulary', () => {
    expect(TERMINAL_TARGETS).toEqual(['@complete', '@stop', '@handoff', '@escalate']);
  });

  it('runs a valid executable flow to a terminal result', async () => {
    await withTempRun(async (runDir) => {
      const result = await executeExecutableFlowV2(validFlow(), {
        runDir,
        runId: 'run-valid',
        executors: {
          relay: async (step, context) => {
            if (step.kind !== 'relay') throw new Error('expected relay step');
            const relay = createStubRelayConnectorV2({ verdict: 'ok' });
            const { executeRelayV2 } = await import('../../src/core-v2/executors/relay.js');
            return executeRelayV2(step, context, relay);
          },
        },
      });

      expect(result.outcome).toBe('complete');

      const files = new RunFileStore(runDir);
      await expect(files.readJson('reports/result.json')).resolves.toMatchObject({
        schema_version: 1,
        run_id: 'run-valid',
        flow_id: 'baseline',
        outcome: 'complete',
        trace_entries_observed: 6,
      });
      await expect(files.readJson('reports/compose.json')).resolves.toMatchObject({
        writer: 'baseline-writer',
        body: { ok: true },
      });
      await expect(files.readJson('reports/relay.json')).resolves.toMatchObject({
        role: 'reviewer',
        response: { verdict: 'ok' },
      });
    });
  });

  it('rejects an invalid route target during validation', () => {
    const flow: ExecutableFlowV2 = {
      ...validFlow(),
      steps: [
        {
          id: 'compose',
          kind: 'compose',
          writer: 'baseline-writer',
          routes: { pass: { kind: 'step', stepId: 'missing' } },
        },
      ],
      stages: [{ id: 'main', stepIds: ['compose'] }],
    };

    expect(validateExecutableFlowV2(flow)).toMatchObject({
      ok: false,
      issues: expect.arrayContaining([
        "step 'compose' route 'pass' targets unknown step 'missing'",
      ]),
    });
  });

  it('allows a step to be listed in more than one stage', () => {
    const flow: ExecutableFlowV2 = {
      ...validFlow(),
      stages: [
        { id: 'main', stepIds: ['compose', 'relay'] },
        { id: 'overlap', stepIds: ['compose'] },
      ],
    };

    expect(validateExecutableFlowV2(flow)).toEqual({ ok: true, issues: [] });
  });

  it('validates basic entry mode structure', () => {
    expect(
      validateExecutableFlowV2({
        ...validFlow(),
        entryModes: [],
      }).issues,
    ).toContain('entryModes must not be empty when provided');

    expect(
      validateExecutableFlowV2({
        ...validFlow(),
        entryModes: [
          {
            name: 'default',
            startAt: 'compose',
            depth: 'standard',
            description: 'Default route',
          },
          {
            name: 'default',
            startAt: 'missing',
            depth: 'standard',
            description: 'Duplicate route',
          },
        ],
      }).issues,
    ).toEqual(
      expect.arrayContaining([
        'duplicate entry mode name: default',
        "entry mode 'default' startAt references unknown step 'missing'",
      ]),
    );
  });

  it('assigns monotonic trace sequence numbers and rejects append after close', async () => {
    await withTempRun(async (runDir) => {
      const trace = new TraceStore(runDir);
      await trace.append({ run_id: 'run-trace', kind: 'run.bootstrapped' });
      await trace.append({ run_id: 'run-trace', kind: 'step.entered', step_id: 'compose' });
      await trace.append({
        run_id: 'run-trace',
        kind: 'run.closed',
        data: { outcome: 'complete' },
      });

      expect(trace.getAll().map((entry) => entry.sequence)).toEqual([0, 1, 2]);
      await expect(
        trace.append({ run_id: 'run-trace', kind: 'step.completed', step_id: 'compose' }),
      ).rejects.toThrow('cannot append trace entry after run close');

      const reloaded = new TraceStore(runDir);
      await expect(reloaded.load()).resolves.toHaveLength(3);
    });
  });

  it('does not mutate trace memory when persistence fails', async () => {
    await withTempRun(async (runDir) => {
      const filePath = join(runDir, 'not-a-directory');
      await writeFile(filePath, 'blocks trace directory creation', 'utf8');
      const trace = new TraceStore(filePath);

      await expect(
        trace.append({ run_id: 'run-persist', kind: 'run.bootstrapped' }),
      ).rejects.toThrow();
      expect(trace.getAll()).toEqual([]);
    });
  });

  it('rejects path traversal in the run-file store', async () => {
    await withTempRun(async (runDir) => {
      const files = new RunFileStore(runDir);
      await expect(files.writeJson('../escape.json', { unsafe: true })).rejects.toThrow(
        'escapes run directory',
      );
    });
  });

  it('rejects invalid run-file paths before appending trace', async () => {
    await withTempRun(async (runDir) => {
      const flow: ExecutableFlowV2 = {
        ...validFlow(),
        steps: validFlow().steps.map((step) =>
          step.id === 'compose'
            ? { ...step, writes: { result: { path: '../escape.json' } } }
            : step,
        ),
      };

      await expect(
        executeExecutableFlowV2(flow, {
          runDir,
          runId: 'run-invalid-path',
        }),
      ).rejects.toThrow("step 'compose' write 'result' path must not contain");

      const trace = new TraceStore(runDir);
      await expect(trace.load()).resolves.toEqual([]);
    });
  });

  it('records failure and closes when an executor throws', async () => {
    await withTempRun(async (runDir) => {
      const result = await executeExecutableFlowV2(
        {
          id: 'failure',
          version: '0.1.0',
          entry: 'compose',
          stages: [{ id: 'main', stepIds: ['compose'] }],
          steps: [
            {
              id: 'compose',
              kind: 'compose',
              writer: 'will-fail',
              routes: { pass: { kind: 'terminal', target: '@complete' } },
            },
          ],
        },
        {
          runDir,
          runId: 'run-failure',
          executors: {
            compose: async () => {
              throw new Error('compose failed');
            },
          },
        },
      );

      const trace = new TraceStore(runDir);
      const entries = await trace.load();
      expect(result.outcome).toBe('aborted');
      expect(entries.map((entry) => entry.kind)).toContain('step.aborted');
      expect(entries.at(-1)).toMatchObject({
        kind: 'run.closed',
        data: { outcome: 'aborted' },
      });
    });
  });

  it('does not complete a step whose executor returns an undeclared route', async () => {
    await withTempRun(async (runDir) => {
      const result = await executeExecutableFlowV2(
        {
          id: 'undeclared-route',
          version: '0.1.0',
          entry: 'compose',
          stages: [{ id: 'main', stepIds: ['compose'] }],
          steps: [
            {
              id: 'compose',
              kind: 'compose',
              writer: 'wrong-route',
              routes: { pass: { kind: 'terminal', target: '@complete' } },
            },
          ],
        },
        {
          runDir,
          runId: 'run-undeclared-route',
          executors: {
            compose: async () => ({ route: 'ghost' }),
          },
        },
      );

      const trace = new TraceStore(runDir);
      const entries = await trace.load();
      expect(result.outcome).toBe('aborted');
      expect(entries.map((entry) => entry.kind)).toEqual([
        'run.bootstrapped',
        'step.entered',
        'step.aborted',
        'run.closed',
      ]);
      expect(entries).not.toContainEqual(expect.objectContaining({ kind: 'step.completed' }));
    });
  });

  it('rejects non-empty existing traces instead of appending blindly', async () => {
    await withTempRun(async (runDir) => {
      const trace = new TraceStore(runDir);
      await trace.append({ run_id: 'existing-run', kind: 'run.bootstrapped' });

      await expect(
        executeExecutableFlowV2(validFlow(), {
          runDir,
          runId: 'new-run',
        }),
      ).rejects.toThrow('core-v2 baseline requires a fresh run directory');

      const reloaded = new TraceStore(runDir);
      await expect(reloaded.load()).resolves.toHaveLength(1);
    });
  });

  it('derives status from trace entries', () => {
    const entries: TraceEntryV2[] = [
      { sequence: 0, run_id: 'run-status', kind: 'run.bootstrapped' },
      {
        sequence: 1,
        run_id: 'run-status',
        kind: 'run.closed',
        data: { outcome: 'complete' },
      },
    ];

    expect(projectStatusFromTraceV2([])).toBe('not_started');
    expect(projectStatusFromTraceV2(entries.slice(0, 1))).toBe('running');
    expect(projectStatusFromTraceV2(entries)).toBe('complete');
  });
});
