import { access, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import type { ExecutorRegistryV2 } from '../../src/core-v2/executors/index.js';
import type { ExecutableStepV2 } from '../../src/core-v2/manifest/executable-flow.js';
import { projectStatusFromTraceV2 } from '../../src/core-v2/projections/status.js';
import { runCompiledFlowV2 } from '../../src/core-v2/run/compiled-flow-runner.js';
import type { RunContextV2 } from '../../src/core-v2/run/run-context.js';
import { TraceStore } from '../../src/core-v2/trace/trace-store.js';
import {
  BuildBrief,
  BuildImplementation,
  BuildPlan,
  BuildResult,
  BuildReview,
  BuildVerification,
} from '../../src/flows/build/reports.js';
import {
  FixBrief,
  FixChange,
  FixContext,
  FixDiagnosis,
  FixResult,
  FixReview,
  FixVerification,
} from '../../src/flows/fix/reports.js';
import { ReviewIntake, ReviewRelayResult, ReviewResult } from '../../src/flows/review/reports.js';
import {
  type CompiledFlow,
  CompiledFlow as CompiledFlowSchema,
} from '../../src/schemas/compiled-flow.js';
import { computeManifestHash } from '../../src/schemas/manifest.js';

export interface CompiledFlowFixture {
  readonly flow: CompiledFlow;
  readonly bytes: Buffer;
  readonly manifestHash: string;
}

const TERMINAL_TARGETS = new Set(['@complete', '@stop', '@handoff', '@escalate']);

const commandSpec = {
  id: 'core-v2-parity-check',
  cwd: '.',
  argv: [process.execPath, '-e', 'process.exit(0)'],
  timeout_ms: 30_000,
  max_output_bytes: 200_000,
  env: {},
};

const commandResult = {
  command_id: commandSpec.id,
  cwd: commandSpec.cwd,
  argv: commandSpec.argv,
  exit_code: 0,
  status: 'passed' as const,
  duration_ms: 0,
  stdout_summary: '',
  stderr_summary: '',
};

const fixCommandResult = {
  ...commandResult,
  timeout_ms: commandSpec.timeout_ms,
  max_output_bytes: commandSpec.max_output_bytes,
  env: commandSpec.env,
};

export async function withTempRun<T>(fn: (runDir: string) => Promise<T>): Promise<T> {
  const runDir = await mkdtemp(join(tmpdir(), 'circuit-core-v2-parity-'));
  try {
    return await fn(runDir);
  } finally {
    await rm(runDir, { recursive: true, force: true });
  }
}

export async function loadCompiledFlowFixture(flowId: string): Promise<CompiledFlowFixture> {
  const bytes = await readFile(join(process.cwd(), 'generated', 'flows', flowId, 'circuit.json'));
  const raw = JSON.parse(bytes.toString('utf8'));
  return {
    flow: CompiledFlowSchema.parse(raw),
    bytes,
    manifestHash: computeManifestHash(bytes),
  };
}

export function expectedPassStepIds(
  flow: CompiledFlow,
  entryModeName = flow.entry_modes[0]?.name,
): string[] {
  const entry = flow.entry_modes.find((mode) => mode.name === entryModeName);
  if (entry === undefined) throw new Error(`missing entry mode ${String(entryModeName)}`);
  const stepsById = new Map(flow.steps.map((step) => [step.id as string, step]));
  const seen = new Set<string>();
  const stepIds: string[] = [];
  let current: string | undefined = entry.start_at;

  while (current !== undefined) {
    if (seen.has(current)) throw new Error(`pass route cycle at ${current}`);
    seen.add(current);
    stepIds.push(current);
    const step = stepsById.get(current);
    if (step === undefined) throw new Error(`missing step ${current}`);
    const target = step.routes.pass;
    if (target === undefined) throw new Error(`missing pass route for ${current}`);
    if (TERMINAL_TARGETS.has(target)) return stepIds;
    current = target;
  }

  throw new Error('pass route walk ended without a terminal target');
}

export async function runSimpleCompiledFlowV2(options: {
  readonly flow: CompiledFlow;
  readonly flowBytes: Uint8Array;
  readonly runDir: string;
  readonly runId: string;
  readonly goal: string;
  readonly entryModeName?: string;
  readonly failStepId?: string;
  readonly routeByStepId?: Readonly<Record<string, string>>;
  readonly executors?: Partial<ExecutorRegistryV2>;
}) {
  return await runCompiledFlowV2({
    flow: options.flow,
    flowBytes: options.flowBytes,
    runDir: options.runDir,
    runId: options.runId,
    goal: options.goal,
    ...(options.entryModeName === undefined ? {} : { entryModeName: options.entryModeName }),
    now: () => new Date('2026-05-02T12:00:00.000Z'),
    executors: {
      ...createSimpleParityExecutors({
        ...(options.failStepId === undefined ? {} : { failStepId: options.failStepId }),
        ...(options.routeByStepId === undefined ? {} : { routeByStepId: options.routeByStepId }),
      }),
      ...options.executors,
    },
  });
}

export async function readTrace(runDir: string) {
  const trace = new TraceStore(runDir);
  return await trace.load();
}

export async function completedStepIds(runDir: string): Promise<string[]> {
  const entries = await readTrace(runDir);
  return entries
    .filter((entry) => entry.kind === 'step.completed')
    .map((entry) => entry.step_id)
    .filter((stepId): stepId is string => stepId !== undefined);
}

export async function runFileExists(runDir: string, runFilePath: string): Promise<boolean> {
  try {
    await access(join(runDir, runFilePath));
    return true;
  } catch {
    return false;
  }
}

export async function expectCompleteTrace(runDir: string): Promise<void> {
  const entries = await readTrace(runDir);
  if (entries[0]?.kind !== 'run.bootstrapped') {
    throw new Error('trace did not bootstrap');
  }
  if (entries.at(-1)?.kind !== 'run.closed') {
    throw new Error('trace did not close');
  }
  if (projectStatusFromTraceV2(entries) !== 'complete') {
    throw new Error('status projection did not derive complete');
  }
  if (entries.some((entry) => entry.kind === 'step.aborted')) {
    throw new Error('trace contains an aborted step');
  }
}

function reviewEvidenceSummary() {
  return {
    kind: 'unavailable' as const,
    message: 'core-v2 parity fixture',
  };
}

function reportBody(step: ExecutableStepV2, context: RunContextV2, schema: string | undefined) {
  const goal = context.goal || 'core-v2 parity goal';
  switch (schema) {
    case 'review.intake@v1':
      return ReviewIntake.parse({
        scope: goal,
        evidence: { kind: 'unavailable', reason: 'core-v2 parity fixture' },
        evidence_warnings: [],
      });
    case 'review.result@v1':
      return ReviewResult.parse({
        scope: goal,
        findings: [],
        verdict: 'CLEAN',
        evidence_summary: reviewEvidenceSummary(),
        evidence_warnings: [],
      });
    case 'fix.brief@v1':
      return FixBrief.parse({
        problem_statement: goal,
        expected_behavior: 'The requested behavior works.',
        observed_behavior: 'The current behavior needs correction.',
        scope: 'core-v2 parity scope',
        regression_contract: {
          expected_behavior: 'The requested behavior works.',
          actual_behavior: 'The current behavior needs correction.',
          repro: { kind: 'command', command: commandSpec },
          regression_test: { status: 'failing-before-fix', command: commandSpec },
        },
        success_criteria: ['The run reaches the close step.'],
        verification_command_candidates: [commandSpec],
      });
    case 'fix.context@v1':
      return FixContext.parse({
        verdict: 'accept',
        sources: [
          { kind: 'file', ref: 'generated/flows/fix/circuit.json', summary: 'Parsed fixture' },
        ],
        observations: ['The v2 adapter preserves the current fix path.'],
        open_questions: [],
      });
    case 'fix.diagnosis@v1':
      return FixDiagnosis.parse({
        verdict: 'accept',
        reproduction_status: 'reproduced',
        cause_summary: 'The parity fixture provides a deterministic diagnosis.',
        confidence: 'high',
        evidence: ['The pass route reaches the act step.'],
        residual_uncertainty: [],
      });
    case 'fix.change@v1':
      return FixChange.parse({
        verdict: 'accept',
        summary: 'Applied the parity fixture change.',
        diagnosis_ref: 'fix.diagnosis@v1',
        changed_files: ['src/example.ts'],
        evidence: ['The v2 run reached the change report.'],
      });
    case 'fix.verification@v1':
      return FixVerification.parse({
        overall_status: 'passed',
        commands: [fixCommandResult],
      });
    case 'fix.review@v1':
      return FixReview.parse({
        verdict: 'accept',
        summary: 'No blocking findings in the parity fixture.',
        findings: [],
      });
    case 'fix.result@v1':
      return FixResult.parse({
        summary: 'The fix flow completed in v2.',
        outcome: 'fixed',
        verification_status: 'passed',
        regression_status: 'proved',
        review_status: 'completed',
        review_verdict: 'accept',
        residual_risks: [],
        evidence_links: [
          { report_id: 'fix.brief', path: 'reports/fix/brief.json', schema: 'fix.brief@v1' },
          { report_id: 'fix.context', path: 'reports/fix/context.json', schema: 'fix.context@v1' },
          {
            report_id: 'fix.diagnosis',
            path: 'reports/fix/diagnosis.json',
            schema: 'fix.diagnosis@v1',
          },
          { report_id: 'fix.change', path: 'reports/fix/change.json', schema: 'fix.change@v1' },
          {
            report_id: 'fix.verification',
            path: 'reports/fix/verification.json',
            schema: 'fix.verification@v1',
          },
          { report_id: 'fix.review', path: 'reports/fix/review.json', schema: 'fix.review@v1' },
        ],
      });
    case 'build.brief@v1':
      return BuildBrief.parse({
        objective: goal,
        scope: 'core-v2 parity scope',
        success_criteria: ['The run reaches the close step.'],
        verification_command_candidates: [commandSpec],
        checkpoint: {
          request_path: step.writes?.request?.path ?? 'reports/checkpoints/request.json',
          response_path: step.writes?.response?.path,
          allowed_choices: step.kind === 'checkpoint' ? [...step.choices] : ['continue'],
        },
      });
    case 'build.plan@v1':
      return BuildPlan.parse({
        objective: goal,
        approach: 'Use the converted v1 manifest.',
        slices: ['Run the simple path.'],
        verification: { commands: [commandSpec] },
      });
    case 'build.implementation@v1':
      return BuildImplementation.parse({
        verdict: 'accept',
        summary: 'Applied the parity fixture implementation.',
        changed_files: ['src/example.ts'],
        evidence: ['The v2 run reached the implementation report.'],
      });
    case 'build.verification@v1':
      return BuildVerification.parse({
        overall_status: 'passed',
        commands: [commandResult],
      });
    case 'build.review@v1':
      return BuildReview.parse({
        verdict: 'accept',
        summary: 'No blocking findings in the parity fixture.',
        findings: [],
      });
    case 'build.result@v1':
      return BuildResult.parse({
        summary: 'The build flow completed in v2.',
        outcome: 'complete',
        verification_status: 'passed',
        review_verdict: 'accept',
        evidence_links: [
          { report_id: 'build.brief', path: 'reports/build/brief.json', schema: 'build.brief@v1' },
          { report_id: 'build.plan', path: 'reports/build/plan.json', schema: 'build.plan@v1' },
          {
            report_id: 'build.implementation',
            path: 'reports/build/implementation.json',
            schema: 'build.implementation@v1',
          },
          {
            report_id: 'build.verification',
            path: 'reports/build/verification.json',
            schema: 'build.verification@v1',
          },
          {
            report_id: 'build.review',
            path: 'reports/build/review.json',
            schema: 'build.review@v1',
          },
        ],
      });
    default:
      return { step_id: step.id, schema: schema ?? 'none', ok: true };
  }
}

async function writeText(context: RunContextV2, path: string, value: string): Promise<void> {
  const fullPath = context.files.resolve(path);
  await mkdir(dirname(fullPath), { recursive: true });
  await writeFile(fullPath, value, 'utf8');
}

async function writeReport(step: ExecutableStepV2, context: RunContextV2): Promise<void> {
  const report = step.writes?.report;
  if (report !== undefined) {
    await context.files.writeJson(report, reportBody(step, context, report.schema));
  }
}

async function writeRelayFiles(step: ExecutableStepV2, context: RunContextV2): Promise<void> {
  if (step.writes?.request !== undefined) {
    await context.files.writeJson(step.writes.request, {
      step_id: step.id,
      goal: context.goal,
    });
  }
  if (step.writes?.receipt !== undefined) {
    await writeText(context, step.writes.receipt.path, `stub receipt for ${step.id}\n`);
  }
  if (step.writes?.result !== undefined) {
    const body =
      step.id === 'audit-step'
        ? ReviewRelayResult.parse({ verdict: 'NO_ISSUES_FOUND', findings: [] })
        : reportBody(step, context, step.writes.report?.schema);
    await context.files.writeJson(step.writes.result, body);
  }
}

function checkpointChoice(step: ExecutableStepV2): string {
  if (step.kind !== 'checkpoint') throw new Error('expected checkpoint step');
  const policy = step.policy as
    | { readonly safe_default_choice?: unknown; readonly safe_autonomous_choice?: unknown }
    | undefined;
  const candidates = [
    policy?.safe_default_choice,
    policy?.safe_autonomous_choice,
    ...step.choices,
    'pass',
  ];
  for (const candidate of candidates) {
    if (typeof candidate === 'string' && step.routes[candidate] !== undefined) return candidate;
  }
  throw new Error(`checkpoint step '${step.id}' has no usable route`);
}

export function createSimpleParityExecutors(
  options: {
    readonly failStepId?: string;
    readonly routeByStepId?: Readonly<Record<string, string>>;
  } = {},
): Partial<ExecutorRegistryV2> {
  return {
    compose: async (step, context) => {
      if (step.kind !== 'compose') throw new Error('expected compose step');
      if (step.id === options.failStepId) throw new Error(`forced failure at ${step.id}`);
      await writeReport(step, context);
      return {
        route: options.routeByStepId?.[step.id] ?? 'pass',
        details: { report: step.writes?.report?.path },
      };
    },
    relay: async (step, context) => {
      if (step.kind !== 'relay') throw new Error('expected relay step');
      if (step.id === options.failStepId) throw new Error(`forced failure at ${step.id}`);
      await writeRelayFiles(step, context);
      await writeReport(step, context);
      return { route: options.routeByStepId?.[step.id] ?? 'pass', details: { role: step.role } };
    },
    verification: async (step, context) => {
      if (step.kind !== 'verification') throw new Error('expected verification step');
      if (step.id === options.failStepId) throw new Error(`forced failure at ${step.id}`);
      await writeReport(step, context);
      return {
        route: options.routeByStepId?.[step.id] ?? 'pass',
        details: { report: step.writes?.report?.path },
      };
    },
    checkpoint: async (step, context) => {
      if (step.kind !== 'checkpoint') throw new Error('expected checkpoint step');
      if (step.id === options.failStepId) throw new Error(`forced failure at ${step.id}`);
      const choice = options.routeByStepId?.[step.id] ?? checkpointChoice(step);
      if (step.writes?.request !== undefined) {
        await context.files.writeJson(step.writes.request, {
          step_id: step.id,
          prompt: (step.policy as { readonly prompt?: unknown } | undefined)?.prompt,
          choices: step.choices,
        });
      }
      if (step.writes?.response !== undefined) {
        await context.files.writeJson(step.writes.response, {
          step_id: step.id,
          selected_choice: choice,
          answered_by: 'mode-default',
          rationale: 'core-v2 parity fixture',
        });
      }
      await writeReport(step, context);
      return { route: choice, details: { selected_choice: choice } };
    },
  };
}
