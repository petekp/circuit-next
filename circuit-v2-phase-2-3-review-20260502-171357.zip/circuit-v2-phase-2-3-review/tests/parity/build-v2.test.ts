import { describe, expect, it } from 'vitest';
import { RunFileStore } from '../../src/core-v2/run-files/run-file-store.js';
import {
  BuildBrief,
  BuildImplementation,
  BuildPlan,
  BuildResult,
  BuildReview,
  BuildVerification,
} from '../../src/flows/build/reports.js';
import { RunResult } from '../../src/schemas/result.js';
import {
  completedStepIds,
  expectCompleteTrace,
  expectedPassStepIds,
  loadCompiledFlowFixture,
  readTrace,
  runSimpleCompiledFlowV2,
  withTempRun,
} from './core-v2-parity-helpers.js';

describe('build v2 parity', () => {
  it('runs the generated build flow through the v2 compiled-flow path', async () => {
    const fixture = await loadCompiledFlowFixture('build');
    const { flow } = fixture;
    const expectedSteps = expectedPassStepIds(flow);

    await withTempRun(async (runDir) => {
      const result = await runSimpleCompiledFlowV2({
        flow,
        flowBytes: fixture.bytes,
        runDir,
        runId: '55555555-5555-4555-8555-555555555555',
        goal: 'build a small change',
      });

      expect(result).toMatchObject({
        schema_version: 1,
        run_id: '55555555-5555-4555-8555-555555555555',
        flow_id: 'build',
        outcome: 'complete',
      });
      expect(await completedStepIds(runDir)).toEqual(expectedSteps);
      await expectCompleteTrace(runDir);

      const trace = await readTrace(runDir);
      expect(trace).toEqual(
        expect.arrayContaining([
          expect.objectContaining({
            kind: 'step.completed',
            step_id: 'frame-step',
            data: { route: 'continue', details: { selected_choice: 'continue' } },
          }),
        ]),
      );

      const files = new RunFileStore(runDir);
      await expect(
        files.readJson('reports/checkpoints/frame-step-response.json'),
      ).resolves.toMatchObject({
        selected_choice: 'continue',
      });
      expect(BuildBrief.safeParse(await files.readJson('reports/build/brief.json')).success).toBe(
        true,
      );
      expect(BuildPlan.safeParse(await files.readJson('reports/build/plan.json')).success).toBe(
        true,
      );
      expect(
        BuildImplementation.safeParse(await files.readJson('reports/build/implementation.json'))
          .success,
      ).toBe(true);
      expect(
        BuildVerification.safeParse(await files.readJson('reports/build/verification.json'))
          .success,
      ).toBe(true);
      expect(BuildReview.safeParse(await files.readJson('reports/build/review.json')).success).toBe(
        true,
      );
      expect(BuildResult.safeParse(await files.readJson('reports/build-result.json')).success).toBe(
        true,
      );
      const runResult = RunResult.parse(await files.readJson('reports/result.json'));
      expect(runResult).toMatchObject({
        flow_id: 'build',
        outcome: 'complete',
        trace_entries_observed: 14,
        manifest_hash: fixture.manifestHash,
      });
    });
  });

  it('can start build from a named entry mode without changing the production CLI path', async () => {
    const fixture = await loadCompiledFlowFixture('build');
    const { flow } = fixture;

    await withTempRun(async (runDir) => {
      const result = await runSimpleCompiledFlowV2({
        flow,
        flowBytes: fixture.bytes,
        runDir,
        runId: '66666666-6666-4666-8666-666666666666',
        goal: 'build with the deep entry mode',
        entryModeName: 'deep',
      });

      expect(result).toMatchObject({
        flow_id: 'build',
        outcome: 'complete',
      });
      expect(await completedStepIds(runDir)).toEqual(expectedPassStepIds(flow, 'deep'));
    });
  });
});
