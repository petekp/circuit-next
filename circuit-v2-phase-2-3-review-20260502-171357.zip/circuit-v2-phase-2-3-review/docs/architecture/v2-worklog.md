# Circuit v2 Worklog

## 2026-05-02 - Phase 0

Goal: audit current runtime strictness, classify what v2 should keep or
simplify, and produce the Checkpoint 1 architecture packet without changing
runtime behavior.

Files inspected:

- `package.json`
- `package-lock.json`
- `AGENTS.md`
- `UBIQUITOUS_LANGUAGE.md`
- `docs/generated-surfaces.md`
- `docs/contracts/`
- `src/runtime/`
- `src/runtime/connectors/`
- `src/runtime/step-handlers/`
- `src/cli/`
- `src/schemas/`
- `src/flows/`
- `specs/behavioral/`
- `specs/invariants.json`
- `specs/reports.json`
- `tests/`
- `commands/`
- `.claude-plugin/`
- `plugins/circuit/`
- `generated/flows/`
- `scripts/emit-flows.mjs`

Files changed:

- `docs/architecture/v2-principles.md`
- `docs/architecture/v2-rigor-audit.md`
- `docs/architecture/v2-migration-plan.md`
- `docs/architecture/v2-checkpoint-1.md`
- `docs/architecture/v2-worklog.md`

Tests run:

- `npm run check`: passed.
- `npm run lint`: passed.
- `npm run build`: passed.
- `npm run test:fast`: failed only on
  `tests/contracts/terminology-active-surface.test.ts`, because the required
  Phase 0 architecture docs use currently banned terms and the required file
  name `v2-rigor-audit.md`.
- `npm run check-flow-drift`: passed.
- `git diff --check`: passed.

Behavior changed? No.

Concerns:

- The Phase 0 deliverable names and required language include terms currently
  banned by the active terminology test. This needs a review decision rather
  than a silent test weakening.
- Several specs still refer to `docs/contracts/flow.md`; the current contract
  file is `docs/contracts/compiled-flow.md`.
- Fanout behavior is load-bearing but currently spread across a large handler
  plus helpers. v2 should preserve behavior while splitting ownership.
- Build checkpoint behavior is product-relevant, but some policy shape still
  lives in generic schema/runtime surfaces.

Next recommended action: review Checkpoint 1, decide how to handle
architecture-transition terminology, then approve or revise the Phase 1 runtime
substrate spike.

## 2026-05-02 - Phase 0.5

Goal: apply the conditional Checkpoint 1 correction before Phase 1.

Files inspected:

- `tests/contracts/terminology-active-surface.test.ts`
- `docs/architecture/v2-principles.md`
- `docs/architecture/v2-rigor-audit.md`
- `docs/architecture/v2-migration-plan.md`
- `docs/architecture/v2-checkpoint-1.md`

Files changed:

- `tests/contracts/terminology-active-surface.test.ts`
- `docs/architecture/v2-principles.md`
- `docs/architecture/v2-rigor-audit.md`
- `docs/architecture/v2-migration-plan.md`
- `docs/architecture/v2-checkpoint-1.md`
- `docs/architecture/v2-worklog.md`

Tests run:

- `npm run check`: passed.
- `npm run lint`: passed.
- `npm run build`: passed.
- `npm run test:fast`: passed.
- `npm run check-flow-drift`: passed.
- `git diff --check`: passed.
- `npm run verify`: passed.
- `npm run verify`: passed.

Behavior changed? No runtime behavior changed.

Concerns: the active terminology exception is intentionally narrow:
`docs/architecture/v2-*` only. Source code, tests other than the existing
terminology test self-exemption, commands, generated outputs, and
product-facing prose remain checked.

Next recommended action: if validation is green, start Phase 1 with a plain
TypeScript baseline and no global Effect adoption.

## 2026-05-02 - Phase 1

Goal: build a minimal v2 runtime substrate beside the existing runtime using a
plain TypeScript baseline.

Files inspected:

- `tsconfig.json`
- `tsconfig.build.json`
- representative test files under `tests/`
- Phase 0 and Phase 0.5 architecture docs

Files changed:

- `src/core-v2/domain/flow.ts`
- `src/core-v2/domain/step.ts`
- `src/core-v2/domain/route.ts`
- `src/core-v2/domain/report.ts`
- `src/core-v2/domain/run-file.ts`
- `src/core-v2/domain/run.ts`
- `src/core-v2/domain/trace.ts`
- `src/core-v2/domain/connector.ts`
- `src/core-v2/domain/selection.ts`
- `src/core-v2/manifest/executable-flow.ts`
- `src/core-v2/manifest/validate-executable-flow.ts`
- `src/core-v2/trace/trace-store.ts`
- `src/core-v2/run-files/paths.ts`
- `src/core-v2/run-files/run-file-store.ts`
- `src/core-v2/run/run-context.ts`
- `src/core-v2/run/result-writer.ts`
- `src/core-v2/run/graph-runner.ts`
- `src/core-v2/executors/index.ts`
- `src/core-v2/executors/compose.ts`
- `src/core-v2/executors/relay.ts`
- `src/core-v2/projections/status.ts`
- `tests/core-v2/core-v2-baseline.test.ts`
- `docs/architecture/v2-checkpoint-2.md`
- `docs/architecture/v2-worklog.md`

Tests run:

- `npx vitest run tests/core-v2/core-v2-baseline.test.ts`: passed.
- `npm run check`: passed.
- `npm run lint`: initially failed on formatting/import order.
- `npx biome check --write src/core-v2 tests/core-v2`: passed and fixed the
  new files.
- `npm run lint`: passed after formatting.
- `npm run build`: passed.
- `npm run test:fast`: passed.
- `npm run test`: passed.
- `npm run check-flow-drift`: passed.
- `git diff --check`: passed.
- `npm run verify`: passed.

Behavior changed? No production behavior changed. v2 exists only as new
opt-in source and tests.

Concerns:

- Checkpoint-like pause is deferred until v1 checkpoint semantics can be
  adapted instead of guessed.
- Non-baseline step kinds fail closed in the executor registry.
- Phase 2 must keep v1 quirks explicit when adapting compiled flows.

Next recommended action: after Checkpoint 2 review, start Phase 2 with the
compiled-flow to executable-manifest adapter.

## 2026-05-02 - Phase 1.5

Goal: fix early v2 contract drift before Phase 2.

Files inspected:

- `src/schemas/compiled-flow.ts`
- `src/schemas/trace-entry.ts`
- `src/runtime/result-writer.ts`
- `src/core-v2/`
- `tests/core-v2/core-v2-baseline.test.ts`

Files changed:

- `src/core-v2/domain/route.ts`
- `src/core-v2/domain/run.ts`
- `src/core-v2/domain/trace.ts`
- `src/core-v2/trace/trace-store.ts`
- `src/core-v2/run/result-writer.ts`
- `src/core-v2/run/graph-runner.ts`
- `src/core-v2/projections/status.ts`
- `tests/core-v2/core-v2-baseline.test.ts`
- `docs/architecture/v2-checkpoint-2.md`
- `docs/architecture/v2-worklog.md`

Tests run:

- `npm run check`: passed.
- `npm run lint`: initially failed on one formatting issue in the updated
  core-v2 test file.
- `npx biome check --write tests/core-v2/core-v2-baseline.test.ts`: passed and
  fixed the formatting issue.
- `npm run check`: passed after formatting.
- `npm run lint`: passed after formatting.
- `npm run build`: passed.
- `npx vitest run tests/core-v2/core-v2-baseline.test.ts`: passed.
- `npm run test:fast`: passed.
- `npm run check-flow-drift`: passed.
- `git diff --check`: passed.

Behavior changed? No production behavior changed. The v2 baseline now aligns
its terminal targets, run close outcomes, trace names, trace field names, and
result path with current runtime contracts.

Concerns:

- v2 still has only baseline executors. Verification, checkpoint, sub-run, and
  fanout remain intentionally unsupported in execution.
- Manifest validation is still a Phase 1 baseline. Phase 2 should add or plan
  terminal reachability, dead-step detection, stage membership consistency, and
  checkpoint choice validation.

Next recommended action: after validation and review, start Phase 2 with the
compiled-flow to executable-manifest adapter.

## 2026-05-02 - Phase 2

Goal: build the `CompiledFlow` v1 to `ExecutableFlowV2` adapter without
changing flow authoring, generated manifests, production CLI behavior, or old
runtime code.

Files inspected:

- `src/schemas/compiled-flow.ts`
- `src/schemas/step.ts`
- `src/schemas/stage.ts`
- `src/schemas/selection-policy.ts`
- representative generated flows under `generated/flows/`
- current `src/core-v2/` manifest, domain, and validation files

Files changed:

- `src/core-v2/domain/flow.ts`
- `src/core-v2/domain/selection.ts`
- `src/core-v2/manifest/executable-flow.ts`
- `src/core-v2/manifest/validate-executable-flow.ts`
- `src/core-v2/manifest/from-compiled-flow-v1.ts`
- `tests/core-v2/from-compiled-flow-v1.test.ts`
- `docs/architecture/v2-phase-2-notes.md`
- `docs/architecture/v2-worklog.md`

Tests run:

- `npx vitest run tests/core-v2/from-compiled-flow-v1.test.ts`: passed.
- `npm run check`: passed.
- `npm run lint`: initially failed on formatting/import order in new files.
- `npx biome check --write src/core-v2 tests/core-v2`: passed and fixed the
  new files.
- `npm run check`: passed after formatting.
- `npm run lint`: passed after formatting.
- `npx vitest run tests/core-v2`: passed.
- `npm run build`: passed.
- `npm run test:fast`: passed.
- `npm run check-flow-drift`: passed.
- `git diff --check`: passed.
- `npm run test`: passed.
- `npm run verify`: passed.

Behavior changed? No production behavior changed. Phase 2 adds adapter parity
tests only.

Concerns:

- v2 manifest validation now covers adapter-level structural safety, but not
  full graph liveness.
- v2 still represents unsupported step kinds without executing them.
- Checkpoint choices and route names are intentionally separate because v1 uses
  both concepts differently.

Next recommended action: after review, begin simple-flow v2 execution parity
only when the unsupported executor boundaries are explicitly planned.

## 2026-05-02 - Phase 2.5

Goal: correct v2 stage membership before simple-flow parity.

Files inspected:

- `src/core-v2/manifest/executable-flow.ts`
- `src/core-v2/manifest/from-compiled-flow-v1.ts`
- `src/core-v2/manifest/validate-executable-flow.ts`
- `src/runtime/selection-resolver.ts`
- `src/schemas/compiled-flow.ts`
- `src/schemas/selection-policy.ts`
- `tests/core-v2/core-v2-baseline.test.ts`
- `tests/core-v2/from-compiled-flow-v1.test.ts`

Files changed:

- `src/core-v2/manifest/executable-flow.ts`
- `src/core-v2/manifest/from-compiled-flow-v1.ts`
- `src/core-v2/manifest/validate-executable-flow.ts`
- `tests/core-v2/core-v2-baseline.test.ts`
- `tests/core-v2/from-compiled-flow-v1.test.ts`
- `docs/architecture/v2-phase-2-notes.md`
- `docs/architecture/v2-worklog.md`

Tests run:

- `npx vitest run tests/core-v2`: passed.
- `npm run check`: passed.
- `npm run lint`: passed.
- `npm run build`: passed.
- `npm run test:fast`: passed.
- `npm run check-flow-drift`: passed.
- `git diff --check`: passed.

Behavior changed? No production behavior changed. The v2 manifest shape now
preserves overlapping stage membership for future selection parity.

Concerns:

- Exact v1 trace and result schemas are still deferred to execution parity.
- v2 still represents unsupported step kinds without executing them.

Next recommended action: after review, begin Phase 3 simple-flow parity.

## 2026-05-02 - Phase 2 adversarial review fixes

Goal: address all adversarial review findings before Phase 3.

Files inspected:

- `src/core-v2/run/graph-runner.ts`
- `src/core-v2/manifest/from-compiled-flow-v1.ts`
- `src/core-v2/manifest/validate-executable-flow.ts`
- `src/core-v2/run-files/paths.ts`
- `src/core-v2/domain/selection.ts`
- `tests/core-v2/core-v2-baseline.test.ts`
- `tests/core-v2/from-compiled-flow-v1.test.ts`
- `src/runtime/runner.ts`
- `src/schemas/scalars.ts`

Files changed:

- `src/core-v2/run/graph-runner.ts`
- `src/core-v2/manifest/from-compiled-flow-v1.ts`
- `src/core-v2/manifest/validate-executable-flow.ts`
- `src/core-v2/run-files/paths.ts`
- `src/core-v2/domain/selection.ts`
- `tests/core-v2/core-v2-baseline.test.ts`
- `tests/core-v2/from-compiled-flow-v1.test.ts`
- `docs/architecture/v2-phase-2-notes.md`
- `docs/architecture/v2-worklog.md`

Tests run:

- `npx vitest run tests/core-v2`: initially failed because the new synthetic
  adapter test referenced a non-existent review step; corrected the fixture.
- `npx vitest run tests/core-v2`: passed after correction.
- `npm run check`: passed.
- `npm run lint`: passed.
- `npm run build`: passed.
- `npm run test:fast`: passed.
- `npm run check-flow-drift`: passed.
- `git diff --check`: passed.
- `npm run verify`: passed.

Behavior changed? No production behavior changed. The v2-only baseline now
matches v1 default-entry behavior more closely, keeps trace lifecycle cleaner
on undeclared routes, validates run-file paths before execution, and preserves
v1 selection field names at the adapter boundary.

Concerns:

- v2 result and trace schemas are still intentionally minimal.
- Verification, checkpoint, sub-run, and fanout execution remain unsupported.

Next recommended action: after validation and review, begin Phase 3 simple-flow
parity.

## 2026-05-02 - Phase 3

Goal: prove simple-flow v2 execution parity for review, fix, and build using
the v1 compiled-flow adapter.

Files inspected:

- `src/runtime/runner.ts`
- `src/runtime/runner-types.ts`
- `src/runtime/result-writer.ts`
- `src/runtime/step-handlers/`
- `src/schemas/compiled-flow.ts`
- `src/schemas/result.ts`
- `src/schemas/trace-entry.ts`
- `src/schemas/verification.ts`
- `src/flows/review/reports.ts`
- `src/flows/fix/reports.ts`
- `src/flows/build/reports.ts`
- `generated/flows/review/circuit.json`
- `generated/flows/fix/circuit.json`
- `generated/flows/build/circuit.json`
- `tests/runner/review-runtime-wiring.test.ts`
- `tests/runner/fix-runtime-wiring.test.ts`
- `tests/runner/build-runtime-wiring.test.ts`
- existing `src/core-v2/` files

Files changed:

- `src/core-v2/run/run-context.ts`
- `src/core-v2/run/result-writer.ts`
- `src/core-v2/run/graph-runner.ts`
- `src/core-v2/run/compiled-flow-runner.ts`
- `tests/core-v2/core-v2-baseline.test.ts`
- `tests/parity/core-v2-parity-helpers.ts`
- `tests/parity/review-v2.test.ts`
- `tests/parity/fix-v2.test.ts`
- `tests/parity/build-v2.test.ts`
- `docs/architecture/v2-checkpoint-3.md`
- `docs/architecture/v2-worklog.md`

Tests run:

- `npm run check`: initially failed on one TypeScript branded id mismatch in
  the new parity helper.
- `npm run check`: passed after correction.
- `npx vitest run tests/core-v2 tests/parity`: passed.
- `npm run lint`: initially failed on formatting/import order in new Phase 3
  files.
- `npx biome check --write src/core-v2/run/compiled-flow-runner.ts tests/parity`:
  passed and fixed the new files.
- `npm run check`: passed after formatting.
- `npx vitest run tests/core-v2 tests/parity`: passed after formatting.
- `npm run lint`: passed.
- `npm run build`: passed.
- `npm run test:fast`: passed.
- `npm run check-flow-drift`: passed.
- `git diff --check`: passed.
- `npm run verify`: passed.

Behavior changed? No production behavior changed. Phase 3 adds an opt-in v2
compiled-flow execution path and tests it against generated review, fix, and
build flows. The production CLI remains on the old runtime.

Concerns:

- v2 trace entries still use a minimal schema.
- v2 result shape is closer to v1 but not the complete current result schema.
- Phase 3 test executors support verification and checkpoint only inside tests.
- Production v2 execution still does not support sub-run, fanout, connector
  subprocess behavior, checkpoint resume, or worktree behavior.

Next recommended action: stop at Checkpoint 3 for review. If approved, begin
Phase 4 complex-flow parity.

## 2026-05-02 - Phase 3 adversarial review fixes

Goal: address adversarial review findings before Phase 4.

Files inspected:

- `src/core-v2/run/result-writer.ts`
- `src/core-v2/run/compiled-flow-runner.ts`
- `src/core-v2/run/graph-runner.ts`
- `src/schemas/result.ts`
- `src/schemas/manifest.ts`
- `src/runtime/runner.ts`
- `tests/parity/`

Files changed:

- `src/core-v2/run/result-writer.ts`
- `src/core-v2/run/compiled-flow-runner.ts`
- `src/core-v2/run/graph-runner.ts`
- `tests/core-v2/core-v2-baseline.test.ts`
- `tests/parity/core-v2-parity-helpers.ts`
- `tests/parity/review-v2.test.ts`
- `tests/parity/fix-v2.test.ts`
- `tests/parity/build-v2.test.ts`
- `docs/architecture/v2-checkpoint-3.md`
- `docs/architecture/v2-worklog.md`

Tests run:

- `npm run check`: passed.
- `npx vitest run tests/core-v2 tests/parity`: initially failed because parity
  run ids were not UUIDs for `RunResult` parsing and one nested matcher was too
  strict.
- `npx vitest run tests/core-v2 tests/parity`: passed after correction.
- `npm run lint`: initially failed on formatting in the route guard and parity
  helper.
- `npx biome check --write src/core-v2/run/graph-runner.ts tests/parity/core-v2-parity-helpers.ts tests/parity/fix-v2.test.ts tests/parity/build-v2.test.ts tests/parity/review-v2.test.ts`:
  passed and fixed formatting.

Behavior changed? No production behavior changed. The v2-only path now writes
result files that parse with the current `RunResult` schema, computes manifest
hashes from raw compiled-flow bytes, and aborts route re-entry before recording
misleading completion.

Concerns:

- The v2 trace shape is still minimal.
- Full recovery-route attempt semantics are still old-runtime behavior; v2 now
  fails closed on re-entry until that behavior is intentionally migrated.

Next recommended action: run full validation again, then stop for Phase 4
review approval.
