import type { RunId } from './run.js';
import type { StepId } from './step.js';

export type TraceSequence = number;

export type TraceEntryTypeV2 =
  | 'run.bootstrapped'
  | 'step.entered'
  | 'step.completed'
  | 'step.aborted'
  | 'run.closed';

export interface TraceEntryInputV2 {
  readonly run_id: RunId;
  readonly kind: TraceEntryTypeV2;
  readonly step_id?: StepId;
  readonly data?: Record<string, unknown>;
}

export interface TraceEntryV2 extends TraceEntryInputV2 {
  readonly sequence: TraceSequence;
}
