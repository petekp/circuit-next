import type { StepOutcomeV2 } from '../domain/step.js';
import type { ComposeStepV2 } from '../manifest/executable-flow.js';
import type { RunContextV2 } from '../run/run-context.js';

export async function executeComposeV2(
  step: ComposeStepV2,
  context: RunContextV2,
): Promise<StepOutcomeV2> {
  const body = step.body ?? { stepId: step.id, writer: step.writer };
  const writes = step.writes ?? {};
  await Promise.all(
    Object.values(writes).map((ref) =>
      context.files.writeJson(ref, {
        stepId: step.id,
        writer: step.writer,
        body,
      }),
    ),
  );
  return { route: 'pass', details: { writer: step.writer } };
}
