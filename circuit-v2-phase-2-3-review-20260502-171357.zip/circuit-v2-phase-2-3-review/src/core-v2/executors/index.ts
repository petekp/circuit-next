import type { StepKindV2, StepOutcomeV2 } from '../domain/step.js';
import type { ExecutableStepV2 } from '../manifest/executable-flow.js';
import type { RunContextV2 } from '../run/run-context.js';
import { executeComposeV2 } from './compose.js';
import { type RelayConnectorV2, createStubRelayConnectorV2, executeRelayV2 } from './relay.js';

export type StepExecutorV2 = (
  step: ExecutableStepV2,
  context: RunContextV2,
) => Promise<StepOutcomeV2>;

export type ExecutorRegistryV2 = Readonly<Record<StepKindV2, StepExecutorV2>>;

export interface DefaultExecutorOptionsV2 {
  readonly relayConnector?: RelayConnectorV2;
}

function unsupportedStep(step: ExecutableStepV2): never {
  throw new Error(`step kind '${step.kind}' is not implemented in core-v2 baseline`);
}

export function createDefaultExecutorsV2(
  options: DefaultExecutorOptionsV2 = {},
): ExecutorRegistryV2 {
  const relayConnector = options.relayConnector ?? createStubRelayConnectorV2();
  return {
    compose: async (step, context) => {
      if (step.kind !== 'compose') return unsupportedStep(step);
      return executeComposeV2(step, context);
    },
    relay: async (step, context) => {
      if (step.kind !== 'relay') return unsupportedStep(step);
      return executeRelayV2(step, context, relayConnector);
    },
    verification: async (step) => unsupportedStep(step),
    checkpoint: async (step) => unsupportedStep(step),
    'sub-run': async (step) => unsupportedStep(step),
    fanout: async (step) => unsupportedStep(step),
  };
}
