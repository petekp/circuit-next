import type { StepOutcomeV2 } from '../domain/step.js';
import type { RelayStepV2 } from '../manifest/executable-flow.js';
import type { RunContextV2 } from '../run/run-context.js';

export interface RelayRequestV2 {
  readonly runId: string;
  readonly stepId: string;
  readonly role: string;
  readonly prompt: string;
  readonly connector?: string;
}

export interface RelayConnectorV2 {
  relay(request: RelayRequestV2): Promise<unknown>;
}

export function createStubRelayConnectorV2(response: unknown = { ok: true }): RelayConnectorV2 {
  return {
    async relay() {
      return response;
    },
  };
}

export async function executeRelayV2(
  step: RelayStepV2,
  context: RunContextV2,
  connector: RelayConnectorV2,
): Promise<StepOutcomeV2> {
  const request: RelayRequestV2 = {
    runId: context.runId,
    stepId: step.id,
    role: step.role,
    prompt: step.prompt ?? '',
    ...(step.connector === undefined ? {} : { connector: step.connector }),
  };
  const response = await connector.relay(request);

  const writes = step.writes ?? {};
  await Promise.all(
    Object.values(writes).map((ref) =>
      context.files.writeJson(ref, {
        stepId: step.id,
        role: step.role,
        response,
      }),
    ),
  );

  return { route: 'pass', details: { role: step.role } };
}
