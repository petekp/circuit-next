import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import type { RunFileRef } from '../domain/run-file.js';
import { resolveRunFilePath } from './paths.js';

export class RunFileStore {
  constructor(readonly runDir: string) {}

  resolve(ref: RunFileRef | string): string {
    return resolveRunFilePath(this.runDir, typeof ref === 'string' ? ref : ref.path);
  }

  async writeJson(ref: RunFileRef | string, value: unknown): Promise<string> {
    const fullPath = this.resolve(ref);
    await mkdir(dirname(fullPath), { recursive: true });
    await writeFile(fullPath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
    return fullPath;
  }

  async readJson<T = unknown>(ref: RunFileRef | string): Promise<T> {
    const raw = await readFile(this.resolve(ref), 'utf8');
    return JSON.parse(raw) as T;
  }
}
