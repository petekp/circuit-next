import type { RunId } from '../domain/run.js';
import type { ExecutableFlowV2 } from '../manifest/executable-flow.js';
import type { RunFileStore } from '../run-files/run-file-store.js';
import type { TraceStore } from '../trace/trace-store.js';

export interface RunContextV2 {
  readonly flow: ExecutableFlowV2;
  readonly runId: RunId;
  readonly runDir: string;
  readonly goal: string;
  readonly manifestHash: string;
  readonly now: () => Date;
  readonly files: RunFileStore;
  readonly trace: TraceStore;
}
