import { randomUUID } from 'node:crypto';
import { mkdir } from 'node:fs/promises';
import type { TerminalTarget } from '../domain/route.js';
import type { RunClosedOutcomeV2 } from '../domain/run.js';
import { type ExecutorRegistryV2, createDefaultExecutorsV2 } from '../executors/index.js';
import type { ExecutableFlowV2 } from '../manifest/executable-flow.js';
import { assertExecutableFlowV2 } from '../manifest/validate-executable-flow.js';
import { RunFileStore } from '../run-files/run-file-store.js';
import { TraceStore } from '../trace/trace-store.js';
import { type RunResultV2, writeRunResultV2 } from './result-writer.js';
import type { RunContextV2 } from './run-context.js';

export interface GraphRunnerOptionsV2 {
  readonly runDir: string;
  readonly runId?: string;
  readonly goal?: string;
  readonly manifestHash?: string;
  readonly now?: () => Date;
  readonly executors?: Partial<ExecutorRegistryV2>;
  readonly maxSteps?: number;
}

export interface GraphRunResultV2 extends RunResultV2 {
  readonly resultPath: string;
}

function defaultManifestHash(flow: ExecutableFlowV2): string {
  return `core-v2:${flow.id}@${flow.version}`;
}

function resultSummary(outcome: RunClosedOutcomeV2, terminalTarget?: TerminalTarget): string {
  if (terminalTarget === undefined) return `Run closed with outcome ${outcome}.`;
  return `Run closed with outcome ${outcome} via ${terminalTarget}.`;
}

function outcomeForTerminal(target: TerminalTarget): RunClosedOutcomeV2 {
  if (target === '@complete') return 'complete';
  if (target === '@stop') return 'stopped';
  if (target === '@handoff') return 'handoff';
  return 'escalated';
}

async function closeRun(
  context: RunContextV2,
  outcome: RunClosedOutcomeV2,
  terminalTarget?: TerminalTarget,
  reason?: string,
): Promise<GraphRunResultV2> {
  await context.trace.append({
    run_id: context.runId,
    kind: 'run.closed',
    data: {
      outcome,
      ...(terminalTarget === undefined ? {} : { terminal_target: terminalTarget }),
      ...(reason === undefined ? {} : { reason }),
    },
  });
  const result: RunResultV2 = {
    schema_version: 1,
    run_id: context.runId,
    flow_id: context.flow.id,
    goal: context.goal,
    outcome,
    summary: resultSummary(outcome, terminalTarget),
    closed_at: context.now().toISOString(),
    trace_entries_observed: context.trace.getAll().length,
    manifest_hash: context.manifestHash,
    ...(reason === undefined ? {} : { reason }),
  };
  const resultPath = await writeRunResultV2(context.files, result);
  return { ...result, resultPath };
}

export async function executeExecutableFlowV2(
  flow: ExecutableFlowV2,
  options: GraphRunnerOptionsV2,
): Promise<GraphRunResultV2> {
  assertExecutableFlowV2(flow);
  await mkdir(options.runDir, { recursive: true });

  const trace = new TraceStore(options.runDir);
  const existingTrace = await trace.load();
  if (existingTrace.length > 0) {
    throw new Error('core-v2 baseline requires a fresh run directory');
  }

  const files = new RunFileStore(options.runDir);
  const runId = options.runId ?? randomUUID();
  const context: RunContextV2 = {
    flow,
    runId,
    runDir: options.runDir,
    goal: options.goal ?? '',
    manifestHash: options.manifestHash ?? defaultManifestHash(flow),
    now: options.now ?? (() => new Date()),
    files,
    trace,
  };
  const executors: ExecutorRegistryV2 = {
    ...createDefaultExecutorsV2(),
    ...options.executors,
  };
  const steps = new Map(flow.steps.map((step) => [step.id, step]));
  const completedStepIds = new Set<string>();
  const maxSteps = options.maxSteps ?? Math.max(flow.steps.length * 4, 8);

  await trace.append({
    run_id: runId,
    kind: 'run.bootstrapped',
    data: {
      flow_id: flow.id,
      version: flow.version,
      entry: flow.entry,
      manifest_hash: context.manifestHash,
    },
  });

  let currentStepId = flow.entry;
  for (let index = 0; index < maxSteps; index += 1) {
    const step = steps.get(currentStepId);
    if (step === undefined) {
      return await closeRun(
        context,
        'aborted',
        undefined,
        `route target '${currentStepId}' is not a known step id`,
      );
    }

    if (completedStepIds.has(step.id)) {
      const reason = `route cycle detected at step '${step.id}'; aborting before re-entering an already completed step`;
      await trace.append({
        run_id: runId,
        kind: 'step.aborted',
        step_id: step.id,
        data: { message: reason },
      });
      return await closeRun(context, 'aborted', undefined, reason);
    }

    await trace.append({ run_id: runId, kind: 'step.entered', step_id: step.id });

    let route: string;
    let details: Record<string, unknown>;
    try {
      const outcome = await executors[step.kind](step, context);
      route = outcome.route;
      details = outcome.details ?? {};
    } catch (error) {
      const message = (error as Error).message;
      await trace.append({
        run_id: runId,
        kind: 'step.aborted',
        step_id: step.id,
        data: { message },
      });
      return await closeRun(
        context,
        'aborted',
        undefined,
        `step '${step.id}' handler threw: ${message}`,
      );
    }

    const target = step.routes[route];
    if (target === undefined) {
      const reason = `step '${step.id}' selected undeclared route '${route}'`;
      await trace.append({
        run_id: runId,
        kind: 'step.aborted',
        step_id: step.id,
        data: { message: reason },
      });
      return await closeRun(context, 'aborted', undefined, reason);
    }

    if (
      target.kind === 'step' &&
      (target.stepId === step.id || completedStepIds.has(target.stepId))
    ) {
      const reason =
        target.stepId === step.id
          ? `route cycle detected: step '${step.id}' routes via '${route}' to itself`
          : `route cycle detected: step '${step.id}' routes via '${route}' to already completed step '${target.stepId}'`;
      await trace.append({
        run_id: runId,
        kind: 'step.aborted',
        step_id: step.id,
        data: { message: reason },
      });
      return await closeRun(context, 'aborted', undefined, reason);
    }

    await trace.append({
      run_id: runId,
      kind: 'step.completed',
      step_id: step.id,
      data: { route, details },
    });
    completedStepIds.add(step.id);

    if (target.kind === 'terminal') {
      return await closeRun(context, outcomeForTerminal(target.target), target.target);
    }

    currentStepId = target.stepId;
  }

  return await closeRun(context, 'aborted', undefined, `maxSteps exceeded: ${maxSteps}`);
}
