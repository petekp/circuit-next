import type { CompiledFlow } from '../../schemas/compiled-flow.js';
import type { Depth } from '../../schemas/depth.js';
import { computeManifestHash } from '../../schemas/manifest.js';
import { type ExecutorRegistryV2, createDefaultExecutorsV2 } from '../executors/index.js';
import { fromCompiledFlowV1 } from '../manifest/from-compiled-flow-v1.js';
import { type GraphRunResultV2, executeExecutableFlowV2 } from './graph-runner.js';

export interface CompiledFlowRunOptionsV2 {
  readonly flow: CompiledFlow;
  readonly flowBytes: Uint8Array;
  readonly runDir: string;
  readonly runId?: string;
  readonly goal: string;
  readonly entryModeName?: string;
  readonly depth?: Depth;
  readonly now?: () => Date;
  readonly executors?: Partial<ExecutorRegistryV2>;
  readonly maxSteps?: number;
}

function selectEntryMode(
  flow: CompiledFlow,
  entryModeName: string | undefined,
): CompiledFlow['entry_modes'][number] {
  if (entryModeName === undefined) {
    const entry = flow.entry_modes[0];
    if (entry === undefined) throw new Error(`compiled flow '${flow.id}' declares no entry modes`);
    return entry;
  }
  const entry = flow.entry_modes.find((mode) => mode.name === entryModeName);
  if (entry === undefined) {
    throw new Error(`compiled flow '${flow.id}' declares no entry mode named '${entryModeName}'`);
  }
  return entry;
}

export async function runCompiledFlowV2(
  options: CompiledFlowRunOptionsV2,
): Promise<GraphRunResultV2> {
  const entry = selectEntryMode(options.flow, options.entryModeName);
  const executable = fromCompiledFlowV1(options.flow);
  const depth = options.depth ?? entry.depth;
  return await executeExecutableFlowV2(
    {
      ...executable,
      entry: entry.start_at,
      metadata: {
        ...executable.metadata,
        selected_entry_mode: entry.name,
        selected_depth: depth,
      },
    },
    {
      runDir: options.runDir,
      ...(options.runId === undefined ? {} : { runId: options.runId }),
      goal: options.goal,
      manifestHash: computeManifestHash(options.flowBytes),
      ...(options.now === undefined ? {} : { now: options.now }),
      executors: {
        ...createDefaultExecutorsV2(),
        ...options.executors,
      },
      ...(options.maxSteps === undefined ? {} : { maxSteps: options.maxSteps }),
    },
  );
}
