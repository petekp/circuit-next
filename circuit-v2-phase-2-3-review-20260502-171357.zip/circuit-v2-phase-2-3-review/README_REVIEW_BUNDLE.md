# Circuit v2 Phase 2-3 Review Bundle

This archive contains the current files needed to review Phase 2, Phase 2.5, Phase 3, and the Phase 3 adversarial-review fixes.

Included changed/current v2 surfaces:

- `src/core-v2/`
- `tests/core-v2/`
- `tests/parity/`
- `docs/architecture/v2-phase-2-notes.md`
- `docs/architecture/v2-checkpoint-3.md`
- `docs/architecture/v2-worklog.md`

Included supporting context, not edited as part of these phases:

- current v1 runtime/schema anchors under `src/runtime/` and `src/schemas/`
- flow-owned report schemas for review/fix/build
- generated flow fixtures used by adapter/parity tests
- package/test config files

Excluded intentionally:

- `.DS_Store`
- previous local zip archives
- generated command/plugin mirrors not touched by these phases
- `node_modules`, `dist`, and coverage output

Recent validation recorded in the worklog/checkpoint docs:

- `npm run check`
- `npm run lint`
- `npm run build`
- `npx vitest run tests/core-v2 tests/parity`
- `npm run test:fast`
- `npm run check-flow-drift`
- `git diff --check`
- `npm run verify`
