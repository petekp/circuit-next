# Circuit v2 Runtime Import Inventory

Generated for Phase 4.15 retained-runtime narrowing prep. This file records full command output for deletion-readiness review. The inventory excludes this generated file from the `rg` scans so it does not cite itself.

## Runtime file tree

```bash
find src/runtime -type f | sort
```

```text
src/runtime/append-and-derive.ts
src/runtime/catalog-derivations.ts
src/runtime/compile-schematic-to-flow.ts
src/runtime/config-loader.ts
src/runtime/connectors/claude-code.ts
src/runtime/connectors/codex.ts
src/runtime/connectors/custom.ts
src/runtime/connectors/relay-materializer.ts
src/runtime/connectors/shared.ts
src/runtime/manifest-snapshot-writer.ts
src/runtime/operator-summary-writer.ts
src/runtime/policy/flow-kind-policy.ts
src/runtime/progress-projector.ts
src/runtime/reducer.ts
src/runtime/registries/checkpoint-writers/registry.ts
src/runtime/registries/checkpoint-writers/types.ts
src/runtime/registries/close-writers/registry.ts
src/runtime/registries/close-writers/shared.ts
src/runtime/registries/close-writers/types.ts
src/runtime/registries/compose-writers/registry.ts
src/runtime/registries/compose-writers/types.ts
src/runtime/registries/cross-report-validators.ts
src/runtime/registries/report-schemas.ts
src/runtime/registries/shape-hints/registry.ts
src/runtime/registries/shape-hints/types.ts
src/runtime/registries/verification-writers/registry.ts
src/runtime/registries/verification-writers/types.ts
src/runtime/relay-selection.ts
src/runtime/relay-support.ts
src/runtime/result-writer.ts
src/runtime/router.ts
src/runtime/run-relative-path.ts
src/runtime/run-status-projection.ts
src/runtime/runner-types.ts
src/runtime/runner.ts
src/runtime/selection-resolver.ts
src/runtime/snapshot-writer.ts
src/runtime/step-handlers/checkpoint.ts
src/runtime/step-handlers/compose.ts
src/runtime/step-handlers/fanout.ts
src/runtime/step-handlers/fanout/aggregate.ts
src/runtime/step-handlers/fanout/branch-resolution.ts
src/runtime/step-handlers/fanout/join-policy.ts
src/runtime/step-handlers/fanout/types.ts
src/runtime/step-handlers/index.ts
src/runtime/step-handlers/recovery-route.ts
src/runtime/step-handlers/relay.ts
src/runtime/step-handlers/shared.ts
src/runtime/step-handlers/sub-run.ts
src/runtime/step-handlers/types.ts
src/runtime/step-handlers/verification.ts
src/runtime/trace-reader.ts
src/runtime/trace-writer.ts
src/runtime/write-capable-worker-disclosure.ts
```

## Runtime import references

```bash
rg -n "from ['\"].*runtime/|../runtime|../../runtime|runtime/" README.md commands plugins .claude-plugin generated docs specs scripts src tests package.json -g "!docs/architecture/v2-runtime-import-inventory.md"
```

```text
scripts/policy/flow-kind-policy.d.mts:6: *   - src/runtime/policy/flow-kind-policy.ts — runtime-level
src/flows/catalog.ts:13:import { runtimeProofCompiledFlowPackage } from './runtime-proof/index.js';
tests/helpers/failure-message.ts:20:import type { StepHandlerResult } from '../../src/runtime/step-handlers/types.js';
scripts/policy/flow-kind-policy.mjs:3:// Consumed by src/runtime/policy/flow-kind-policy.ts, which wraps these
scripts/policy/flow-kind-policy.mjs:236: * in src/runtime/policy/flow-kind-policy.ts so this stays Zod-free and
tests/helpers/failure-message.test.ts:17:import type { StepHandlerResult } from '../../src/runtime/step-handlers/types.js';
commands/run.md:206:- `src/runtime/router.ts` (current deterministic classifier)
src/flows/build/relay-hints.ts:3:import type { SchemaShapeHint } from '../../runtime/registries/shape-hints/types.js';
specs/reference/legacy-circuit/review-characterization.md:34:~/Code/circuit/scripts/runtime/bin/dispatch.js  # the CLI (bundled)
specs/reference/legacy-circuit/review-characterization.md:173:existing step kinds at `src/runtime/runner.ts` are `dispatch` and
specs/reference/legacy-circuit/review-characterization.md:230:adapter surface (`src/runtime/adapters/`). The shape is cited here for
commands/build.md:117:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
src/flows/build/command.md:117:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
docs/flows/authoring-model.md:19:- `src/runtime/compile-schematic-to-flow.ts` for schematic to compiled-flow projection.
generated/release/current-capabilities.json:520:      "evidence": ["src/schemas/connector.ts", "src/runtime/relay-selection.ts"],
generated/release/current-capabilities.json:536:      "evidence": ["src/schemas/connector.ts", "src/runtime/relay-selection.ts"],
generated/release/current-capabilities.json:552:      "evidence": ["src/schemas/connector.ts", "src/runtime/relay-selection.ts"],
generated/release/current-capabilities.json:569:      "evidence": ["src/runtime/runner.ts", "src/cli/circuit.ts"],
generated/release/current-capabilities.json:586:      "evidence": ["src/runtime/snapshot-writer.ts", "src/runtime/runner.ts", "src/cli/handoff.ts"],
generated/release/current-capabilities.json:603:      "evidence": ["src/runtime/router.ts", "tests/contracts/flow-router.test.ts"],
generated/release/current-capabilities.json:1647:      "evidence": ["src/runtime/compile-schematic-to-flow.ts"],
generated/release/current-capabilities.json:1662:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1677:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1692:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1707:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1722:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1737:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1752:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1805:        "src/runtime/write-capable-worker-disclosure.ts",
generated/release/current-capabilities.json:1806:        "src/runtime/runner.ts",
generated/release/current-capabilities.json:1807:        "src/runtime/operator-summary-writer.ts"
commands/explore.md:111:- `src/runtime/` (current runner)
scripts/release/emit-current-capabilities.mjs:499:    evidence: ['src/runtime/router.ts'],
scripts/release/emit-current-capabilities.mjs:544:    evidence: ['src/schemas/connector.ts', 'src/runtime/relay-selection.ts'],
scripts/release/emit-current-capabilities.mjs:702:      evidence: ['src/runtime/runner.ts', 'src/cli/circuit.ts'],
scripts/release/emit-current-capabilities.mjs:717:      evidence: ['src/runtime/snapshot-writer.ts', 'src/runtime/runner.ts', 'src/cli/handoff.ts'],
scripts/release/emit-current-capabilities.mjs:733:      evidence: ['src/runtime/router.ts', 'tests/contracts/flow-router.test.ts'],
scripts/release/emit-current-capabilities.mjs:776:        'src/runtime/write-capable-worker-disclosure.ts',
scripts/release/emit-current-capabilities.mjs:777:        'src/runtime/runner.ts',
scripts/release/emit-current-capabilities.mjs:778:        'src/runtime/operator-summary-writer.ts',
scripts/release/emit-current-capabilities.mjs:799:      evidence: ['src/runtime/compile-schematic-to-flow.ts'],
commands/fix.md:123:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
docs/generated-surfaces.md:37:| `runtime-proof` | `internal` | `src/flows/runtime-proof/schematic.json` | `generated/flows/runtime-proof/circuit.json` | none; internal flow | none | none | Edit the flow package; host mirrors must not exist. |
scripts/release/capture-golden-run-proofs.mjs:16:import { writeComposeReport } from '../../dist/runtime/runner.js';
src/flows/build/writers/plan.ts:10:} from '../../../runtime/registries/compose-writers/types.js';
docs/positioning-and-strategy.md:161:| Within-run continuity (pause/resume single run) | **Real** (`runtime/checkpoint.ts`, `schemas/continuity.ts`) |
specs/reports.json:75:      "description": "Authoring-layer schematic shape for assembling reusable flow blocks into runnable compiled flows. Captures schematic steps, stage bindings, execution labels, typed evidence contracts, contract aliases, named route targets, and per-depth route_overrides. Compiled to generated/flows/<id>/circuit.json (and per-mode <mode>.json siblings) by src/runtime/compile-schematic-to-flow.ts at build time.",
specs/reports.json:252:      "trust_boundary": "operator-local derived state; state.json is written only by the reducer-derived snapshot writer at src/runtime/snapshot-writer.ts (never by step executors). A byte-match against a fresh reducer pass over run.trace is the re-entry check. Slice 27c lands the writer; re-entry byte-match enforcement in resume lands in Slice 27d+ per plan.",
specs/reports.json:279:      "trust_boundary": "operator-local persisted state; written once at bootstrap by the manifest snapshot writer at src/runtime/manifest-snapshot-writer.ts. Hash algorithm: SHA-256 over the exact persisted manifest snapshot bytes (`algorithm: 'sha256-raw'`), per ADR-0001 Addendum B §Stage 1.5 Close Criteria #8. Parse-time superRefine rejects any snapshot whose declared hash disagrees with sha256 over decoded bytes_base64; a second reader cannot be tricked into accepting a tampered byte-body under the declared hash.",
specs/reports.json:832:      "trust_boundary": "engine-computed at Close by the registered explore.result@v1 compose writer from schema-parsed compose.json and review-verdict.json plus flow-declared evidence link paths; terminal report — no in-run readers; cross-run reader is the run result consumer only; path-distinct from run.result so the engine's result-writer (src/runtime/result-writer.ts RESULT-I1 — single writer to result.json) and the orchestrator's close-step (flow-semantic aggregate at explore-result.json) do not collide",
plugins/circuit/commands/run.md:205:- `src/runtime/router.ts` (current deterministic classifier)
src/flows/build/writers/verification.ts:10:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/build/writers/verification.ts:16:} from '../../../runtime/registries/verification-writers/types.js';
plugins/circuit/skills/run/SKILL.md:194:- `src/runtime/router.ts` (current deterministic classifier)
plugins/circuit/commands/build.md:116:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
src/flows/build/writers/close.ts:8:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/build/writers/close.ts:12:} from '../../../runtime/registries/close-writers/types.js';
docs/architecture/v2-checkpoint-4.8.md:16:First, `src/runtime/selection-resolver.ts` is not just a test oracle. It is
docs/architecture/v2-checkpoint-4.8.md:18:core-v2 relay through `src/runtime/relay-selection.ts`.
docs/architecture/v2-checkpoint-4.8.md:20:Second, `src/runtime/progress-projector.ts` is not only old runtime/test
docs/architecture/v2-checkpoint-4.8.md:33:find src/runtime -type f | sort
docs/architecture/v2-checkpoint-4.8.md:34:rg -n "from ['\"].*runtime/|../runtime|../../runtime|runtime/" src tests scripts docs specs package.json
docs/architecture/v2-checkpoint-4.8.md:47:1. Move shared relay/progress types out of `src/runtime/runner-types.ts`.
docs/architecture/v2-checkpoint-4.8.md:48:2. Move shared progress helper functions out of `src/runtime/progress-projector.ts`.
docs/architecture/v2-checkpoint-4.8.md:49:3. Move relay selection support out of `src/runtime/relay-selection.ts` and
docs/architecture/v2-checkpoint-4.8.md:50:   `src/runtime/selection-resolver.ts`.
scripts/release/lib.mjs:103:  return import(resolve(projectRoot, 'dist/runtime/router.js'));
docs/architecture/v2-checkpoint-4.1.md:42:- `src/runtime/runner.ts`
docs/architecture/v2-checkpoint-4.1.md:43:- `src/runtime/runner-types.ts`
docs/architecture/v2-checkpoint-4.1.md:44:- `src/runtime/step-handlers/checkpoint.ts`
docs/architecture/v2-checkpoint-4.1.md:45:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-checkpoint-4.1.md:46:- `src/runtime/step-handlers/verification.ts`
docs/architecture/v2-checkpoint-4.1.md:47:- `src/runtime/relay-selection.ts`
docs/architecture/v2-checkpoint-4.1.md:48:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-checkpoint-4.1.md:49:- `src/runtime/result-writer.ts`
plugins/circuit/skills/build/SKILL.md:121:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
src/flows/build/writers/checkpoint-brief.ts:17:import { sha256Hex } from '../../../runtime/connectors/shared.js';
src/flows/build/writers/checkpoint-brief.ts:23:} from '../../../runtime/registries/checkpoint-writers/types.js';
plugins/circuit/commands/explore.md:110:- `src/runtime/` (current runner)
docs/architecture/v2-checkpoint-4.15.md:20:`src/runtime/run-relative-path.ts` remains as a compatibility re-export.
docs/architecture/v2-worklog.md:17:- `src/runtime/`
docs/architecture/v2-worklog.md:18:- `src/runtime/connectors/`
docs/architecture/v2-worklog.md:19:- `src/runtime/step-handlers/`
docs/architecture/v2-worklog.md:65:  lives in generic schema/runtime surfaces.
docs/architecture/v2-worklog.md:188:- `src/runtime/result-writer.ts`
docs/architecture/v2-worklog.md:301:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:350:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:398:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:399:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:400:- `src/runtime/result-writer.ts`
docs/architecture/v2-worklog.md:401:- `src/runtime/step-handlers/`
docs/architecture/v2-worklog.md:476:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:525:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:587:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:588:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-worklog.md:642:- `src/runtime/**`
docs/architecture/v2-worklog.md:643:- current imports referencing `src/runtime/`
docs/architecture/v2-worklog.md:669:- `src/runtime/runner.ts` remains live for retained fallback, rollback,
docs/architecture/v2-worklog.md:672:- Several `src/runtime/` modules are shared infrastructure and should be moved
docs/architecture/v2-worklog.md:685:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:686:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:688:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:725:shared relay/progress callback types out of `src/runtime/runner-types.ts`.
docs/architecture/v2-worklog.md:729:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:740:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:763:Behavior changed? No runtime behavior changed. `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:779:the shared progress output helpers out of `src/runtime/progress-projector.ts`.
docs/architecture/v2-worklog.md:783:- `src/runtime/progress-projector.ts`
docs/architecture/v2-worklog.md:791:- `src/runtime/progress-projector.ts`
docs/architecture/v2-worklog.md:818:- `src/runtime/progress-projector.ts` remains live for retained runtime and old
docs/architecture/v2-worklog.md:827:precedence resolver out of `src/runtime/selection-resolver.ts`.
docs/architecture/v2-worklog.md:831:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:832:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:840:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:841:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:871:- `src/runtime/relay-selection.ts` remains live for retained relay decision
docs/architecture/v2-worklog.md:875:leaving retained relayer resolution in `runtime/relay-selection.ts`.
docs/architecture/v2-worklog.md:879:Goal: reduce core-v2's dependency on `src/runtime/relay-selection.ts` by moving
docs/architecture/v2-worklog.md:885:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:886:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:887:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:896:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:918:`src/shared/relay-selection.ts`; `src/runtime/relay-selection.ts` re-exports
docs/architecture/v2-worklog.md:924:- `src/runtime/relay-selection.ts` remains live for retained relayer resolution,
docs/architecture/v2-worklog.md:933:Goal: reduce core-v2's dependency on `src/runtime/relay-support.ts` by moving
docs/architecture/v2-worklog.md:938:- `src/runtime/relay-support.ts`
docs/architecture/v2-worklog.md:939:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:940:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-worklog.md:947:- `src/runtime/relay-support.ts`
docs/architecture/v2-worklog.md:969:`src/runtime/relay-support.ts` re-exports them for retained runtime
docs/architecture/v2-worklog.md:983:Goal: reduce core-v2's dependency on `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:988:- `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:990:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:991:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:997:- `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:1019:`src/runtime/write-capable-worker-disclosure.ts` re-exports them for retained
docs/architecture/v2-worklog.md:1027:Next recommended action: inspect `src/runtime/run-relative-path.ts` as the next
docs/architecture/v2-worklog.md:1034:`src/runtime/run-relative-path.ts` without changing path safety semantics.
docs/architecture/v2-worklog.md:1038:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-worklog.md:1047:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-worklog.md:1065:in `src/shared/run-relative-path.ts`; `src/runtime/run-relative-path.ts`
docs/architecture/v2-worklog.md:1087:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1098:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1142:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1155:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1300:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:1301:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:1310:- `src/runtime/relay-support.ts`
docs/architecture/v2-worklog.md:1311:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:1337:- `RelayFn` still lives in `src/runtime/runner-types.ts` and should move to a
docs/architecture/v2-worklog.md:1679:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-worklog.md:1736:- `src/runtime/`
docs/architecture/v2-worklog.md:1737:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:1738:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:1739:- `src/runtime/step-handlers/`
docs/architecture/v2-worklog.md:1740:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-worklog.md:1741:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-worklog.md:1742:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:1743:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:1744:- `src/runtime/registries/`
docs/architecture/v2-worklog.md:1777:- Some files under `src/runtime/` are still live compiler, catalog, registry,
docs/architecture/v2-worklog.md:1833:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-worklog.md:1916:- `src/runtime/step-handlers/sub-run.ts`
docs/architecture/v2-worklog.md:1917:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-worklog.md:1918:- `src/runtime/step-handlers/fanout/branch-resolution.ts`
docs/architecture/v2-worklog.md:1919:- `src/runtime/step-handlers/fanout/join-policy.ts`
docs/architecture/v2-worklog.md:1920:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:1921:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-worklog.md:1922:- `src/runtime/connectors/codex.ts`
plugins/circuit/commands/fix.md:122:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
scripts/emit-flows.mjs:5:// src/runtime/compile-schematic-to-flow.ts (consumed here through
scripts/emit-flows.mjs:644:  // dist/runtime/compile-schematic-to-flow.js is produced by `npm run
scripts/emit-flows.mjs:647:  const distPath = resolve(projectRoot, 'dist/runtime/compile-schematic-to-flow.js');
docs/architecture/v2-migration-plan.md:12:`src/runtime/`, `src/cli/`, `src/schemas/`, `src/flows/`, `docs/contracts/`,
docs/architecture/v2-migration-plan.md:128:`src/runtime/compile-schematic-to-flow.ts`, `src/schemas/step.ts`, flow
docs/architecture/v2-migration-plan.md:176:Files likely involved: old `src/runtime/*`, old runner imports, CLI runtime
src/flows/sweep/relay-hints.ts:3:import type { SchemaShapeHint } from '../../runtime/registries/shape-hints/types.js';
docs/architecture/v2-checkpoint-4.10.md:21:`src/runtime/progress-projector.ts` remains as the old trace-to-progress
docs/architecture/v2-checkpoint-4.10.md:30:It no longer imports `src/runtime/progress-projector.ts`.
plugins/circuit/skills/fix/SKILL.md:127:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
docs/architecture/v2-checkpoint-4.12.md:23:`src/runtime/relay-selection.ts` re-exports those helpers for compatibility.
docs/architecture/v2-checkpoint-4.12.md:29:`src/runtime/relay-selection.ts` still owns retained relayer resolution,
docs/architecture/v2-checkpoint-4.11.md:21:`src/runtime/selection-resolver.ts` remains as a compatibility re-export.
docs/architecture/v2-checkpoint-4.11.md:25:`src/runtime/relay-selection.ts` now imports selection precedence from the
plugins/circuit/skills/explore/SKILL.md:116:- `src/runtime/` (current runner)
docs/architecture/v2-checkpoint-4.1.1.md:25:  `src/runtime/relay-support.ts`, so `core-v2` no longer imports
docs/architecture/v2-checkpoint-4.1.1.md:26:  `src/runtime/step-handlers/relay.ts` directly.
docs/architecture/v2-checkpoint-4.1.1.md:32:- `src/runtime/runner.ts` remains the production CLI runner.
docs/architecture/v2-checkpoint-4.1.1.md:33:- `src/runtime/step-handlers/relay.ts` remains for the old runtime path and old
docs/architecture/v2-checkpoint-4.1.1.md:35:- `src/runtime/runner-types.ts` remains because `RelayFn` is still shared by the
docs/architecture/v2-deletion-plan.md:50:| `src/runtime/runner.ts` | retained execution path | The CLI still imports `runCompiledFlow` for unsupported modes, rollback, arbitrary fixtures, `composeWriter`, and checkpoint resume. Release proof scripts and many runner tests still use it. |
docs/architecture/v2-deletion-plan.md:51:| `src/runtime/runner-types.ts` | compatibility re-export plus retained runtime types | core-v2 imports shared relay/progress/run callback types from `src/shared/relay-runtime-types.ts`. Keep this file until retained runtime and tests stop importing the old surface. |
docs/architecture/v2-deletion-plan.md:52:| `src/runtime/step-handlers/checkpoint.ts` | checkpoint pause/resume and retained checkpoint modes | v2 handles fresh safe checkpoint choices, but checkpoint waiting and resume stay retained-runtime-owned. |
docs/architecture/v2-deletion-plan.md:53:| `src/runtime/step-handlers/compose.ts` | retained fallback and programmatic compose writer hook | core-v2 uses catalog writers, but `main(..., { composeWriter })` intentionally falls back to retained runtime. |
docs/architecture/v2-deletion-plan.md:54:| `src/runtime/step-handlers/relay.ts` | retained relay handler and oracle tests | core-v2 no longer imports this file directly, but retained runtime and handler tests still do. |
docs/architecture/v2-deletion-plan.md:55:| `src/runtime/step-handlers/sub-run.ts` | retained fallback and oracle tests | core-v2 has sub-run coverage, but unsupported fallback paths and old tests still rely on the old handler. |
docs/architecture/v2-deletion-plan.md:56:| `src/runtime/step-handlers/fanout.ts` and `src/runtime/step-handlers/fanout/*` | retained fallback and fanout oracle tests | core-v2 has fanout slices, but old fanout behavior remains the comparison oracle. |
docs/architecture/v2-deletion-plan.md:57:| `src/runtime/step-handlers/verification.ts` | retained fallback and verification oracle tests | core-v2 can run flow-owned verification writers, but old verification tests remain useful until migration. |
docs/architecture/v2-deletion-plan.md:58:| `src/runtime/step-handlers/recovery-route.ts` | retained runner recovery behavior | core-v2 has bounded recovery tests, but old runner tests still cover the retained path. |
docs/architecture/v2-deletion-plan.md:59:| `src/runtime/step-handlers/shared.ts`, `src/runtime/step-handlers/types.ts`, `src/runtime/step-handlers/index.ts` | retained handler support | Delete only with the old handler cluster. |
docs/architecture/v2-deletion-plan.md:67:These files live under `src/runtime/`, but they are not simply old graph-runner
docs/architecture/v2-deletion-plan.md:72:| `src/runtime/compile-schematic-to-flow.ts` | keep / compiler infrastructure | `scripts/emit-flows.mjs`, compiler tests, and generated flow output still use it. |
docs/architecture/v2-deletion-plan.md:73:| `src/runtime/catalog-derivations.ts` | keep / catalog infrastructure | Router, generated surfaces, and catalog tests depend on catalog-derived data. |
docs/architecture/v2-deletion-plan.md:74:| `src/runtime/registries/**` | keep / later move | Flow packages, v2 report validation, writer discovery, cross-report validators, and shape hints depend on these registries. |
docs/architecture/v2-deletion-plan.md:75:| `src/runtime/connectors/**` | keep / later move | core-v2 reuses real connector subprocesses, relay materialization, argv validation, and shared connector helpers. |
docs/architecture/v2-deletion-plan.md:76:| `src/runtime/relay-support.ts` | compatibility re-export | Relay prompt and check helpers moved to `src/shared/relay-support.ts` in Phase 4.13. Keep this wrapper until retained relay handler imports and old tests stop using the old path. |
docs/architecture/v2-deletion-plan.md:77:| `src/runtime/config-loader.ts` | keep / later move | CLI config discovery feeds both retained runtime and core-v2 connector resolution. |
docs/architecture/v2-deletion-plan.md:78:| `src/runtime/router.ts` | keep / later move | Natural-language flow selection still uses the current router. |
docs/architecture/v2-deletion-plan.md:79:| `src/runtime/relay-selection.ts` | retained relay decision bridge | Selection-depth helpers moved to `src/shared/relay-selection.ts` in Phase 4.12. Keep this file for retained relayer resolution, connector bridge behavior, old relay handler imports, and relay provenance tests. |
docs/architecture/v2-deletion-plan.md:80:| `src/runtime/selection-resolver.ts` | compatibility re-export | Selection precedence logic moved to `src/shared/selection-resolver.ts` in Phase 4.11. Keep this wrapper until retained runtime tests and external imports stop using the old path. |
docs/architecture/v2-deletion-plan.md:81:| `src/runtime/result-writer.ts` | retain until old result tests migrate | core-v2 has its own result writer, but retained runtime and old result tests still use this one. |
docs/architecture/v2-deletion-plan.md:82:| `src/runtime/manifest-snapshot-writer.ts` | retain until old resume/status tests migrate | core-v2 has raw-byte snapshots, but old runner resume/status tests still use this writer. |
docs/architecture/v2-deletion-plan.md:83:| `src/runtime/snapshot-writer.ts` | retain for state snapshots and continuity | Used by retained runner, checkpoint handler, `append-and-derive`, `cli/handoff`, event-log round-trip tests, fresh-run-root tests, release evidence, and state snapshot behavior. |
docs/architecture/v2-deletion-plan.md:84:| `src/runtime/operator-summary-writer.ts` | keep / later move | CLI writes operator summaries for both v2 and retained runs. |
docs/architecture/v2-deletion-plan.md:85:| `src/runtime/run-status-projection.ts` | keep | This is now the compatibility projector for both v1 and v2 run folders. |
docs/architecture/v2-deletion-plan.md:86:| `src/runtime/progress-projector.ts` | retained trace-to-progress projection | core-v2 imports shared helpers from `src/shared/progress-output.ts`. Keep this file for old trace projection, retained runtime imports, and old progress tests. |
docs/architecture/v2-deletion-plan.md:87:| `src/runtime/reducer.ts`, `src/runtime/append-and-derive.ts`, `src/runtime/trace-reader.ts`, `src/runtime/trace-writer.ts` | retain until trace/projection tests migrate | Old trace infrastructure remains the v1 oracle and status/progress source for retained runs. |
docs/architecture/v2-deletion-plan.md:88:| `src/runtime/policy/flow-kind-policy.ts` | keep | Generated-surface and fixture policy, not old execution. |
docs/architecture/v2-deletion-plan.md:89:| `src/runtime/write-capable-worker-disclosure.ts` | compatibility re-export | Disclosure helper moved to `src/shared/write-capable-worker-disclosure.ts` in Phase 4.14. Keep this wrapper while retained runtime and operator summary imports use the old path. |
docs/architecture/v2-deletion-plan.md:90:| `src/runtime/run-relative-path.ts` | compatibility re-export | Run-relative path helper moved to `src/shared/run-relative-path.ts` in Phase 4.15. Keep this wrapper while retained runtime, connector materialization, old handlers, projection, and operator summary imports use the old path. |
docs/architecture/v2-deletion-plan.md:97:../runtime
docs/architecture/v2-deletion-plan.md:98:../../runtime
docs/architecture/v2-deletion-plan.md:99:runtime/
docs/architecture/v2-deletion-plan.md:107:| `runtime/runner` | `src/cli/circuit.ts`, release proof script, many `tests/runner/*`, selected contract tests | retained execution | Keep until unsupported modes, rollback, `composeWriter`, fixtures, and checkpoint resume have explicit replacement or retained-module ownership. |
docs/architecture/v2-deletion-plan.md:108:| `runtime/runner-types` | retained runtime, `src/cli/circuit.ts`, tests | compatibility re-export | core-v2 no longer imports this file. Keep until retained runtime and tests stop importing the old type surface. |
docs/architecture/v2-deletion-plan.md:109:| `runtime/step-handlers` | direct handler tests and retained runner | retained execution oracle | Migrate tests only after v2 owns the behavior or the behavior stays retained by policy. |
docs/architecture/v2-deletion-plan.md:110:| `runtime/registries` | flow packages, core-v2 report validation, tests | live infrastructure | Move to neutral flow-package infrastructure before deleting any runtime namespace. |
docs/architecture/v2-deletion-plan.md:111:| `runtime/connectors` | core-v2 relay bridge, flow writers, connector tests | live connector infrastructure | Keep or move. Do not delete with old runner. |
docs/architecture/v2-deletion-plan.md:112:| `runtime/relay-support` | old relay handler and compatibility imports | compatibility re-export | core-v2 no longer imports this file. Shared helper ownership now lives in `src/shared/relay-support.ts`. |
docs/architecture/v2-deletion-plan.md:113:| `runtime/relay-selection` | retained relay handler, old runner, and old relay tests | retained relay decision bridge | core-v2 no longer imports this file. Keep until retained relayer resolution and connector bridge behavior move or stay behind an explicit retained module. |
docs/architecture/v2-deletion-plan.md:114:| `runtime/selection-resolver` | retained tests and compatibility imports | compatibility re-export | Neutral ownership now lives in `src/shared/selection-resolver.ts`; keep wrapper until old-path imports migrate. |
docs/architecture/v2-deletion-plan.md:173:find src/runtime -type f | sort
docs/architecture/v2-deletion-plan.md:174:rg -n "from ['\"].*runtime/|../runtime|../../runtime|runtime/" src tests scripts docs specs package.json
docs/architecture/v2-deletion-plan.md:188:| Move shared relay/progress types out of `src/runtime/runner-types.ts` | Done in Phase 4.9 for `RelayFn`, `RelayInput`, `ProgressReporter`, and `RuntimeEvidencePolicy`. `runner-types.ts` remains as a compatibility re-export plus retained runtime invocation/result types. | Keep full validation green while retained runtime and tests continue importing the old surface. |
docs/architecture/v2-deletion-plan.md:189:| Move progress helper functions out of `src/runtime/progress-projector.ts` | Done in Phase 4.10 for `progressDisplay` and `reportProgress`. `progress-projector.ts` re-exports them for compatibility and still owns old trace-to-progress projection. | Keep progress schema tests, old progress-projector tests, CLI v2 progress tests, and full validation green. |
docs/architecture/v2-deletion-plan.md:190:| Move relay selection support to a neutral module | Mostly done in Phases 4.11 and 4.12 for selection ownership: `src/shared/selection-resolver.ts` owns `resolveSelectionForRelay`, and `src/shared/relay-selection.ts` owns depth-bound selection derivation. `src/runtime/relay-selection.ts` remains for retained relayer resolution and connector bridge behavior. | Config loader tests, selection contract tests, relay provenance tests, core-v2 connector tests, CLI custom connector precedence tests, full `npm run verify`. |
docs/architecture/v2-deletion-plan.md:191:| Move run-relative path helper out of `src/runtime/run-relative-path.ts` | Done in Phase 4.15 for `resolveRunRelative`. Flow writers and shared relay support now import `src/shared/run-relative-path.ts`; the runtime file remains a compatibility re-export for retained runtime surfaces. | Keep run-relative path containment tests, materializer tests, report writer tests, CLI v2 tests, and full validation green. |
docs/architecture/v2-checkpoint-4.2.md:36:The complex flows still have direct v2 runtime/parity coverage, but the CLI
docs/architecture/v2-checkpoint-4.md:30:- `src/runtime/runner.ts`
docs/architecture/v2-checkpoint-4.md:31:- `src/runtime/runner-types.ts`
docs/architecture/v2-checkpoint-4.md:32:- `src/runtime/step-handlers/checkpoint.ts`
docs/architecture/v2-checkpoint-4.md:33:- `src/runtime/step-handlers/compose.ts`
docs/architecture/v2-checkpoint-4.md:34:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-checkpoint-4.md:35:- `src/runtime/step-handlers/sub-run.ts`
docs/architecture/v2-checkpoint-4.md:36:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-checkpoint-4.md:37:- `src/runtime/step-handlers/fanout/aggregate.ts`
docs/architecture/v2-checkpoint-4.md:38:- `src/runtime/step-handlers/fanout/branch-resolution.ts`
docs/architecture/v2-checkpoint-4.md:39:- `src/runtime/step-handlers/fanout/join-policy.ts`
docs/architecture/v2-checkpoint-4.md:40:- `src/runtime/step-handlers/fanout/types.ts`
docs/architecture/v2-checkpoint-4.md:41:- `src/runtime/step-handlers/verification.ts`
docs/architecture/v2-checkpoint-4.md:42:- `src/runtime/step-handlers/recovery-route.ts`
docs/architecture/v2-checkpoint-4.md:43:- `src/runtime/step-handlers/shared.ts`
docs/architecture/v2-checkpoint-4.md:44:- `src/runtime/step-handlers/types.ts`
docs/architecture/v2-checkpoint-4.md:46:The deletion should be a narrow approved slice, not a whole-tree `src/runtime/`
docs/architecture/v2-checkpoint-4.md:53:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-checkpoint-4.md:54:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-checkpoint-4.md:55:- `src/runtime/registries/**`
docs/architecture/v2-checkpoint-4.md:56:- `src/runtime/connectors/**`
docs/architecture/v2-checkpoint-4.md:57:- `src/runtime/config-loader.ts`
docs/architecture/v2-checkpoint-4.md:58:- `src/runtime/router.ts`
docs/architecture/v2-checkpoint-4.md:59:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.md:60:- `src/runtime/snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.md:61:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-checkpoint-4.md:62:- `src/runtime/progress-projector.ts`
docs/architecture/v2-checkpoint-4.md:63:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-checkpoint-4.md:64:- `src/runtime/reducer.ts`
docs/architecture/v2-checkpoint-4.md:65:- `src/runtime/trace-reader.ts`
docs/architecture/v2-checkpoint-4.md:66:- `src/runtime/trace-writer.ts`
docs/architecture/v2-checkpoint-4.md:67:- `src/runtime/append-and-derive.ts`
docs/architecture/v2-checkpoint-4.md:68:- `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-checkpoint-4.md:69:- `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-checkpoint-4.md:70:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-checkpoint-4.md:82:| `runtime/runner` | production CLI, release proof script, old runner tests, a few contract tests | replace with v2 before deleting runner |
docs/architecture/v2-checkpoint-4.md:83:| `runtime/step-handlers` | direct handler tests and property tests | delete or rewrite after v2 executor coverage is accepted |
docs/architecture/v2-checkpoint-4.md:84:| `runtime/registries` | flow packages, writer types, report schema helpers, catalog tests | retain or move before whole-runtime cleanup |
docs/architecture/v2-checkpoint-4.md:85:| `runtime/catalog-derivations` | catalog and router tests | retain or move |
docs/architecture/v2-checkpoint-4.md:86:| `runtime/compile-schematic-to-flow` | emit script and compiler tests | retain until compiler replacement |
docs/architecture/v2-checkpoint-4.md:87:| `runtime/relay-selection` | old relay provenance tests | replace with v2 connector/config tests |
docs/architecture/v2-checkpoint-4.md:88:| `runtime/selection-resolver` | flow model/effort contract test | replace with v2 config precedence tests |
docs/architecture/v2-checkpoint-4.md:94:rg -n "runCompiledFlow|executeCompiledFlow|compileSchematicToFlow|CompiledFlow|flow-schematic|runtime/runner|runtime/step-handlers|runtime/catalog-derivations|runtime/registries|relay-selection|selection-resolver" src tests docs specs scripts commands plugins .claude-plugin generated README.md package.json
docs/architecture/v2-checkpoint-4.md:95:rg -n "from ['\"].*runtime/(runner|step-handlers|catalog-derivations|registries|relay-selection|selection-resolver)|from ['\"].*runtime/(compile-schematic-to-flow)" src tests scripts
docs/architecture/v2-checkpoint-4.md:96:rg -l "from ['\"].*runtime/runner" src tests scripts
docs/architecture/v2-checkpoint-4.md:97:rg -l "from ['\"].*runtime/step-handlers" src tests scripts
docs/architecture/v2-checkpoint-4.md:98:rg -l "from ['\"].*runtime/registries" src tests scripts
docs/architecture/v2-checkpoint-4.md:99:rg -l "from ['\"].*runtime/(catalog-derivations|relay-selection|selection-resolver|compile-schematic-to-flow)" src tests scripts
docs/architecture/v2-checkpoint-4.md:209:- Deleting all of `src/runtime/` would remove live compiler/catalog/report/config
docs/architecture/v2-checkpoint-4.14.md:22:`src/runtime/write-capable-worker-disclosure.ts` remains as a compatibility
src/flows/sweep/cross-report-validators.ts:19:} from '../../runtime/registries/close-writers/shared.js';
src/flows/sweep/cross-report-validators.ts:20:import type { CrossReportResult } from '../../runtime/registries/cross-report-validators.js';
docs/architecture/v2-checkpoint-4.7.md:49:Several files under `src/runtime/` are not old execution code and should be
docs/architecture/v2-checkpoint-4.9.md:23:`src/runtime/runner-types.ts` remains as a compatibility re-export and still
docs/architecture/v2-checkpoint-4.9.md:28:core-v2 no longer imports `src/runtime/runner-types.ts` for relay/progress
docs/architecture/v2-checkpoint-4.9.md:38:`src/runtime/runner-types.ts` or `src/runtime/runner.ts`.
tests/runner/fanout-handler-direct.test.ts:18:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/fanout-handler-direct.test.ts:25:} from '../../src/runtime/runner.js';
tests/runner/fanout-handler-direct.test.ts:26:import { runFanoutStep } from '../../src/runtime/step-handlers/fanout.js';
tests/runner/fanout-handler-direct.test.ts:27:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
docs/architecture/v2-rigor-audit.md:11:| Trace sequence authority | `src/runtime/runner.ts`, `src/schemas/run.ts`, `docs/contracts/run.md` | Trace corruption, duplicate sequence numbers, status projection drift | Reducer, progress projector, run status, reports | Runner `push()` assigns sequence numbers before append | keep | `trace/trace-store.ts` | `tests/runner/push-sequence-authority.test.ts`, `tests/contracts/runtrace-schema.test.ts` | One component must own sequence assignment. |
docs/architecture/v2-rigor-audit.md:12:| Run bootstrap rules | `src/runtime/runner.ts`, `src/schemas/run.ts`, `docs/contracts/run.md` | Ambiguous run identity, missing manifest snapshot, invalid resume base | CLI, run reducer, status reader | `run.bootstrapped` first entry, manifest snapshot writer, strict trace schema | keep | `run/run-context.ts` and trace store | Run trace schema tests, status projection tests | Bootstrap should stay explicit and single. |
docs/architecture/v2-rigor-audit.md:13:| Run close rules | `src/runtime/runner.ts`, `src/runtime/result-writer.ts`, `src/schemas/run.ts` | Runs that keep accepting entries after completion, wrong terminal result | CLI, status projection, operator summary | `run.closed`, result writer, trace close validation | keep | `run/graph-runner.ts` and `run/result-writer.ts` | Run trace and runner tests | Close should be a graph-runner responsibility, with result writing isolated. |
docs/architecture/v2-rigor-audit.md:14:| Resume rules | `src/runtime/runner.ts`, checkpoint handler, run status projection | Resuming the wrong checkpoint, stale request reuse, mismatched manifest | CLI resume path, checkpoint waiting state | Saved manifest, checkpoint request validation, resume choice checks | keep | `run/resume.ts` | Checkpoint and status projection tests | Keep behavior. Split resume from main runner. |
docs/architecture/v2-rigor-audit.md:15:| Connector capability rules | `docs/contracts/connector.md`, `src/schemas/connector.ts`, `src/runtime/connectors/` | Wrong connector writes, sandbox bypass, unsafe argv, unknown provider effort | Relay runtime, config resolution, tests | Schema checks, argv guards, subprocess flags, provider effort allowlists | keep | `connectors/resolver.ts` and connector modules | Connector schema, Codex, custom connector, identity tests | This is load-bearing and should not be loosened for migration speed. |
docs/architecture/v2-rigor-audit.md:16:| Selection/config precedence | `src/runtime/selection-resolver.ts`, `src/runtime/relay-selection.ts`, `docs/contracts/selection.md`, `docs/contracts/config.md` | Ambiguous model/effort/connector choice, hidden overrides | Relay prompt builder, CLI config loader | Layered config fold with applied provenance | keep | `domain/selection.ts` plus connector resolver | Config loader and selection tests | Preserve precedence. Simplify by making provenance a v2 first-class value. |
docs/architecture/v2-rigor-audit.md:18:| Schematic step validation | `src/schemas/flow-schematic.ts`, `src/runtime/compile-schematic-to-flow.ts` | Missing kind-specific fields, invalid reads/writes/checks | Compiler, flow packages | Flat optional authoring shape plus manual cross-field validation | simplify | Phase 5 authoring schemas, then adapter/compiler output validation | Flow schematic and compiler tests | Keep validation strength, reduce optional-field reasoning. |
docs/architecture/v2-rigor-audit.md:21:| Report schema validation | Flow package `reports.ts`, `src/runtime/registries/*`, connector materializer | Invalid report trusted downstream, bad relay result accepted | Relay executor, report readers, generated manifests | Flow-owned schemas and runtime parsing | keep | Flow-owned validators called by executors | Flow report schema tests and relay tests | Preserve flow package ownership. |
docs/architecture/v2-rigor-audit.md:22:| Checkpoint behavior | `src/runtime/step-handlers/checkpoint.ts`, checkpoint writers, Build writer | Bad pause/resume, wrong auto-resolution, invalid checkpoint report | Runner, CLI resume, status projection | Handler policy, checkpoint files, trace entries, flow-owned writers | simplify | `executors/checkpoint.ts`, `run/resume.ts`, flow-owned policy | Checkpoint handler, Build checkpoint tests | Preserve behavior but remove generic knowledge of Build-specific report shape. |
docs/architecture/v2-rigor-audit.md:23:| Fanout behavior | `src/runtime/step-handlers/fanout.ts`, `src/runtime/step-handlers/fanout/*` | Branch loss, partial failure mishandling, missing aggregate report, leaked worktree | Explore and Sweep flows, run status, report consumers | Large handler plus helper modules | simplify | `fanout/branch-expansion.ts`, `branch-execution.ts`, `worktree.ts`, `join-policy.ts`, `aggregate-report.ts`, `cleanup.ts` | Fanout runtime and property tests | Behavior is load-bearing; file shape needs decomposition. |
docs/architecture/v2-rigor-audit.md:24:| Sub-run behavior | `src/runtime/step-handlers/sub-run.ts` | Child run ambiguity, missing copied result, parent/child trace confusion | Migrate/Sweep flows, parent runner | Child run folder creation, child resolver, copied report/result | keep | `executors/sub-run.ts` plus `run/graph-runner.ts` child context | Sub-run runtime and recursion tests | Preserve identity and materialization rules. |
docs/architecture/v2-rigor-audit.md:26:| Runtime-proof flow | `src/flows/runtime-proof/`, generated internal flow | Runtime checks become public product shape or stale proof relic | Tests and generated internal manifest | Internal flow package | demote | Focused core-v2 test fixtures | Current catalog/generated tests | Keep only if it remains a useful internal fixture. Do not make it v2 architecture. |
docs/architecture/v2-rigor-audit.md:31:| Run file path safety | `src/schemas/scalars.ts`, `src/runtime/run-relative-path.ts`, step schema | Path traversal, symlink escape, write collision | Runtime writers, connectors, reports | Run-relative path parser and containment checks | keep | `run-files/paths.ts` and `run-file-store.ts` | Scalar and runner path tests | Keep explicit paths in executable manifests. |
docs/architecture/v2-rigor-audit.md:32:| Progress/status projection | `src/runtime/reducer.ts`, `src/runtime/progress-projector.ts`, `src/runtime/run-status-projection.ts` | Independent truth stores disagree with trace | CLI progress, run status, operator summary | Reducer and projection modules read trace and files | simplify | `projections/status.ts`, `progress.ts`, `task-state.ts`, `user-input.ts` | Progress projector and status tests | Preserve trace-first rule. Split projection from runner wording. |
docs/architecture/v2-rigor-audit.md:33:| Manifest snapshot and hash | `src/runtime/manifest-snapshot-writer.ts`, runner bootstrap | Resume against different flow bytes, impossible run audit | Resume path, status readers, tests | Snapshot writer and bootstrap metadata | keep | `manifest/` plus `run/run-context.ts` | Runner and resume tests | v2 should snapshot the executable manifest actually run. |
docs/contracts/selection.md:142:  `src/runtime/connectors/*.ts` for connector-specific honoring.
docs/contracts/selection.md:271:## Property ids (Stage 2 runtime/property coverage)
docs/architecture/v2-checkpoint-4.13.md:24:`src/runtime/relay-support.ts` remains as a compatibility re-export.
docs/architecture/v2-checkpoint-4.13.md:33:- `src/runtime/registries/shape-hints/registry.ts`
docs/architecture/v2-checkpoint-4.13.md:34:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-checkpoint-1.md:136:- `src/runtime/runner.ts`
docs/architecture/v2-checkpoint-1.md:137:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-checkpoint-1.md:138:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-checkpoint-1.md:139:- `src/runtime/relay-selection.ts`
docs/architecture/v2-checkpoint-1.md:140:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-checkpoint-1.md:141:- `src/runtime/reducer.ts`
docs/architecture/v2-checkpoint-1.md:142:- `src/runtime/progress-projector.ts`
docs/architecture/v2-checkpoint-1.md:143:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-checkpoint-1.md:144:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-checkpoint-1.md:145:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-1.md:146:- `src/runtime/router.ts`
docs/architecture/v2-checkpoint-1.md:147:- `src/runtime/connectors/codex.ts`
docs/architecture/v2-checkpoint-1.md:148:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-checkpoint-1.md:149:- `src/runtime/connectors/custom.ts`
docs/architecture/v2-checkpoint-1.md:150:- `src/runtime/step-handlers/checkpoint.ts`
docs/architecture/v2-checkpoint-1.md:151:- `src/runtime/step-handlers/sub-run.ts`
docs/architecture/v2-checkpoint-1.md:152:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-checkpoint-1.md:153:- `src/runtime/step-handlers/fanout/aggregate.ts`
docs/architecture/v2-checkpoint-1.md:154:- `src/runtime/step-handlers/fanout/branch-resolution.ts`
docs/architecture/v2-checkpoint-1.md:155:- `src/runtime/step-handlers/fanout/join-policy.ts`
docs/architecture/v2-checkpoint-1.md:156:- `src/runtime/step-handlers/fanout/types.ts`
tests/runner/terminal-outcome-mapping.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/terminal-outcome-mapping.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/terminal-outcome-mapping.test.ts:12:} from '../../src/runtime/runner.js';
tests/runner/terminal-outcome-mapping.test.ts:13:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/fanout-runtime.test.ts:6:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/fanout-runtime.test.ts:15:} from '../../src/runtime/runner.js';
tests/runner/fanout-runtime.test.ts:801:      reason: /runtime-proof-strict@v1/,
docs/architecture/v2-checkpoint-4.6.md:60:fresh runs; it only includes runtime/runtime_reason fields in CLI JSON output.
docs/contracts/step.md:145:  `src/runtime/run-relative-path.ts` path is a retained compatibility wrapper.
src/flows/sweep/writers/queue.ts:12:} from '../../../runtime/registries/compose-writers/types.js';
docs/contracts/connector.md:126:    `src/runtime/connectors/codex.ts`; ADR-0009 §Consequences.Enabling is
docs/contracts/connector.md:175:  `src/runtime/connectors/custom.ts`.
tests/runner/codex-relay-roundtrip.test.ts:8:import { type CodexRelayResult, relayCodex } from '../../src/runtime/connectors/codex.js';
tests/runner/codex-relay-roundtrip.test.ts:9:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/codex-relay-roundtrip.test.ts:10:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/codex-relay-roundtrip.test.ts:11:import { reduce } from '../../src/runtime/reducer.js';
tests/runner/codex-relay-roundtrip.test.ts:12:import { appendAndDerive, bootstrapRun } from '../../src/runtime/runner.js';
tests/runner/codex-relay-roundtrip.test.ts:13:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/codex-relay-roundtrip.test.ts:60://   (a) src/runtime/connectors/codex.ts — relayCodex + parseCodexStdout
tests/runner/codex-relay-roundtrip.test.ts:62://   (b) src/runtime/connectors/shared.ts — sha256Hex + RelayResult
tests/runner/codex-relay-roundtrip.test.ts:64://   (c) src/runtime/connectors/relay-materializer.ts — five-trace_entry
tests/runner/codex-relay-roundtrip.test.ts:77:  resolve('src/runtime/connectors/codex.ts'),
tests/runner/codex-relay-roundtrip.test.ts:78:  resolve('src/runtime/connectors/shared.ts'),
tests/runner/codex-relay-roundtrip.test.ts:79:  resolve('src/runtime/connectors/relay-materializer.ts'),
tests/runner/codex-relay-roundtrip.test.ts:80:  resolve('src/runtime/runner.ts'),
tests/runner/codex-relay-roundtrip.test.ts:81:  resolve('src/runtime/registries/report-schemas.ts'),
src/flows/sweep/writers/verification.ts:12:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/sweep/writers/verification.ts:18:} from '../../../runtime/registries/verification-writers/types.js';
src/shared/relay-runtime-types.ts:1:import type { ConnectorRelayInput, RelayResult } from '../runtime/connectors/shared.js';
tests/runner/explore-tournament-runtime.test.ts:6:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-tournament-runtime.test.ts:12:} from '../../src/runtime/runner.js';
tests/contracts/terminology-product-surface.test.ts:174:        'internal/runtime names belong inside backticks or fenced code,',
tests/contracts/terminology-product-surface.test.ts:214:    expect(raw).not.toMatch(/\bsrc\/runtime\/compile-recipe-to-flow\.ts\b/);
tests/contracts/terminology-product-surface.test.ts:219:    expect(raw).toMatch(/\bsrc\/runtime\/compile-schematic-to-flow\.ts\b/);
src/flows/sweep/writers/close.ts:11:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/sweep/writers/close.ts:15:} from '../../../runtime/registries/close-writers/types.js';
src/runtime/connectors/shared.ts:15:// This module stays under `src/runtime/connectors/**` so Check 29's
src/runtime/runner.ts:441:// under src/runtime/registries/compose-writers/ and is registered by
src/runtime/runner.ts:443:// src/runtime/registries/close-writers/. The runner stays flow-
src/runtime/runner.ts:741:// src/runtime/step-handlers/.
tests/runner/build-runtime-wiring.test.ts:12:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/build-runtime-wiring.test.ts:13:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/build-runtime-wiring.test.ts:14:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/contracts/flow-router.test.ts:3:import { ROUTABLE_WORKFLOWS, classifyCompiledFlowTask } from '../../src/runtime/router.js';
src/runtime/connectors/relay-materializer.ts:28:// Why live in `src/runtime/connectors/` and not `src/runtime/` proper.
src/runtime/connectors/relay-materializer.ts:31:// scope is `src/runtime/connectors/**`, and this module's only external
src/runtime/connectors/relay-materializer.ts:93:// `src/runtime/runner.ts::evaluateRelayCheck` + the `parseReport`
src/runtime/connectors/relay-materializer.ts:97:// registry at `src/runtime/registries/report-schemas.ts`; unknown schema names
src/flows/sweep/writers/brief.ts:12:} from '../../../runtime/registries/compose-writers/types.js';
tests/runner/agent-relay-roundtrip.test.ts:9:} from '../../src/runtime/connectors/claude-code.js';
tests/runner/agent-relay-roundtrip.test.ts:10:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/agent-relay-roundtrip.test.ts:11:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/agent-relay-roundtrip.test.ts:12:import { reduce } from '../../src/runtime/reducer.js';
tests/runner/agent-relay-roundtrip.test.ts:13:import { appendAndDerive, bootstrapRun } from '../../src/runtime/runner.js';
tests/runner/agent-relay-roundtrip.test.ts:14:import { readRunTrace } from '../../src/runtime/trace-reader.js';
src/shared/relay-support.ts:2:import { findRelayShapeHint } from '../runtime/registries/shape-hints/registry.js';
src/runtime/registries/compose-writers/types.ts:17:// src/runtime/registries/close-writers/. The two registries are intentionally
tests/runner/verification-handler-direct.test.ts:25:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/verification-handler-direct.test.ts:26:import { runVerificationStep } from '../../src/runtime/step-handlers/verification.js';
src/runtime/step-handlers/checkpoint.ts:109:// means adding a builder under src/runtime/registries/checkpoint-writers/.
tests/contracts/codex-connector-schema.test.ts:15:} from '../../src/runtime/connectors/codex.js';
tests/contracts/codex-connector-schema.test.ts:22://   (A) `src/runtime/connectors/codex.ts` module shape + capability-
tests/contracts/codex-connector-schema.test.ts:40:describe('Codex connector — src/runtime/connectors/codex.ts module shape', () => {
tests/runner/build-verification-exec.test.ts:16:import { type ComposeWriterFn, runCompiledFlow } from '../../src/runtime/runner.js';
src/flows/fix/command.md:123:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
tests/runner/sub-run-real-recursion.test.ts:25:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/sub-run-real-recursion.test.ts:26:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/sub-run-real-recursion.test.ts:31:} from '../../src/runtime/runner.js';
tests/properties/visible/flow-router-tiebreak.test.ts:3:// src/runtime/router.ts.
tests/properties/visible/flow-router-tiebreak.test.ts:32:import type { RoutablePackage } from '../../../src/runtime/catalog-derivations.js';
tests/properties/visible/flow-router-tiebreak.test.ts:33:import { classifyTaskAgainstRoutables } from '../../../src/runtime/router.js';
tests/properties/visible/cross-report-validator.test.ts:16:import { reportPathForSchemaInCompiledFlow } from '../../../src/runtime/registries/close-writers/shared.js';
tests/properties/visible/cross-report-validator.test.ts:17:import { runCrossReportValidator } from '../../../src/runtime/registries/cross-report-validators.js';
src/core-v2/executors/verification.ts:4:import { findVerificationWriter } from '../../runtime/registries/verification-writers/registry.js';
src/core-v2/executors/verification.ts:5:import type { VerificationCommand } from '../../runtime/registries/verification-writers/types.js';
src/flows/types.ts:14:import type { CheckpointBriefBuilder } from '../runtime/registries/checkpoint-writers/types.js';
src/flows/types.ts:15:import type { CloseBuilder } from '../runtime/registries/close-writers/types.js';
src/flows/types.ts:16:import type { ComposeBuilder } from '../runtime/registries/compose-writers/types.js';
src/flows/types.ts:17:import type { CrossReportValidator } from '../runtime/registries/cross-report-validators.js';
src/flows/types.ts:18:import type { StructuralShapeHint } from '../runtime/registries/shape-hints/types.js';
src/flows/types.ts:19:import type { VerificationBuilder } from '../runtime/registries/verification-writers/types.js';
tests/runner/cli-v2-runtime.test.ts:32:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/cli-v2-runtime.test.ts:33:import type { ComposeWriterFn, RelayFn, RelayInput } from '../../src/runtime/runner.js';
tests/runner/cli-v2-runtime.test.ts:1547:      /checkpoint-waiting depth 'deep' remains on the retained checkpoint runtime/,
tests/properties/visible/fanout-join-policy.test.ts:3:// `evaluateFanoutJoinPolicy` helper in src/runtime/step-handlers/fanout.ts.
tests/properties/visible/fanout-join-policy.test.ts:33:} from '../../../src/runtime/step-handlers/fanout.js';
src/core-v2/executors/checkpoint.ts:2:import { sha256Hex } from '../../runtime/connectors/shared.js';
src/core-v2/executors/checkpoint.ts:3:import { findCheckpointBriefBuilder } from '../../runtime/registries/checkpoint-writers/registry.js';
tests/runner/catalog-derivations.test.ts:20:} from '../../src/runtime/catalog-derivations.js';
tests/runner/catalog-derivations.test.ts:21:import type { CheckpointBriefBuilder } from '../../src/runtime/registries/checkpoint-writers/types.js';
tests/runner/catalog-derivations.test.ts:22:import type { CloseBuilder } from '../../src/runtime/registries/close-writers/types.js';
tests/runner/catalog-derivations.test.ts:23:import type { ComposeBuilder } from '../../src/runtime/registries/compose-writers/types.js';
tests/runner/catalog-derivations.test.ts:24:import type { StructuralShapeHint } from '../../src/runtime/registries/shape-hints/types.js';
tests/runner/catalog-derivations.test.ts:25:import type { VerificationBuilder } from '../../src/runtime/registries/verification-writers/types.js';
tests/runner/catalog-derivations.test.ts:461:      '../../src/runtime/registries/compose-writers/registry.js'
tests/runner/catalog-derivations.test.ts:464:      '../../src/runtime/registries/close-writers/registry.js'
tests/runner/catalog-derivations.test.ts:467:      '../../src/runtime/registries/verification-writers/registry.js'
tests/runner/catalog-derivations.test.ts:470:      '../../src/runtime/registries/checkpoint-writers/registry.js'
src/runtime/compile-schematic-to-flow.ts:71:        `schematic item '${item.id}' has verification kind but writes '${item.output}'; no verification writer is registered for that schema (see src/runtime/registries/verification-writers/registry.ts)`,
src/runtime/compile-schematic-to-flow.ts:78:        `schematic item '${item.id}' has checkpoint kind writing report '${item.output}'; no checkpoint writer is registered for that schema (see src/runtime/registries/checkpoint-writers/registry.ts)`,
tests/contracts/engine-flow-boundary.test.ts:1:// Architecture boundary: src/runtime/ may not import from any
tests/contracts/engine-flow-boundary.test.ts:14:const RUNTIME_ROOT = 'src/runtime';
tests/contracts/engine-flow-boundary.test.ts:69:  it('no file under src/runtime/ imports a flow source other than the catalog or types', () => {
tests/contracts/engine-flow-boundary.test.ts:76:      'src/runtime walk returned unexpectedly few files — discovery loop is likely broken',
tests/runner/relay-invocation-failure.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/relay-invocation-failure.test.ts:7:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/relay-invocation-failure.test.ts:8:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/relay-invocation-failure.test.ts:16:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/contracts/explore-report-composition.test.ts:5:import { findCloseBuilder } from '../../src/runtime/registries/close-writers/registry.js';
tests/contracts/explore-report-composition.test.ts:6:import { findComposeBuilder } from '../../src/runtime/registries/compose-writers/registry.js';
tests/contracts/explore-report-composition.test.ts:7:import { parseReport } from '../../src/runtime/registries/report-schemas.js';
src/flows/fix/writers/verification.ts:11:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/fix/writers/verification.ts:17:} from '../../../runtime/registries/verification-writers/types.js';
src/flows/explore/relay-hints.ts:3:import type { SchemaShapeHint } from '../../runtime/registries/shape-hints/types.js';
src/core-v2/executors/compose.ts:5:} from '../../runtime/registries/close-writers/registry.js';
src/core-v2/executors/compose.ts:9:} from '../../runtime/registries/compose-writers/registry.js';
tests/runner/review-runtime-wiring.test.ts:28:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/review-runtime-wiring.test.ts:29:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/review-runtime-wiring.test.ts:30:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
src/cli/circuit.ts:18:import { discoverConfigLayers } from '../runtime/config-loader.js';
src/cli/circuit.ts:19:import { writeOperatorSummary } from '../runtime/operator-summary-writer.js';
src/cli/circuit.ts:20:import { validateCompiledFlowKindPolicy } from '../runtime/policy/flow-kind-policy.js';
src/cli/circuit.ts:21:import { classifyCompiledFlowTask } from '../runtime/router.js';
src/cli/circuit.ts:29:} from '../runtime/runner.js';
src/cli/circuit.ts:400:  // Validator: src/runtime/policy/flow-kind-policy.ts.
src/flows/fix/writers/close.ts:14:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/fix/writers/close.ts:18:} from '../../../runtime/registries/close-writers/types.js';
tests/contracts/orphan-blocks.test.ts:24:} from '../../src/runtime/compile-schematic-to-flow.js';
tests/contracts/orphan-blocks.test.ts:25:import { runCompiledFlow, writePrototypeComposeReport } from '../../src/runtime/runner.js';
src/core-v2/executors/relay.ts:3:import { relayClaudeCode } from '../../runtime/connectors/claude-code.js';
src/core-v2/executors/relay.ts:4:import { relayCodex } from '../../runtime/connectors/codex.js';
src/core-v2/executors/relay.ts:5:import { relayCustom } from '../../runtime/connectors/custom.js';
src/core-v2/executors/relay.ts:6:import { type RelayResult, sha256Hex } from '../../runtime/connectors/shared.js';
src/core-v2/executors/relay.ts:7:import { runCrossReportValidator } from '../../runtime/registries/cross-report-validators.js';
src/core-v2/executors/relay.ts:8:import { parseReport } from '../../runtime/registries/report-schemas.js';
src/flows/explore/writers/analysis.ts:10:} from '../../../runtime/registries/compose-writers/types.js';
tests/runner/compose-builder-registry.test.ts:15:import { findComposeBuilder } from '../../src/runtime/registries/compose-writers/registry.js';
tests/runner/compose-builder-registry.test.ts:16:import type { ComposeBuilder } from '../../src/runtime/registries/compose-writers/types.js';
tests/runner/compose-builder-registry.test.ts:17:import { runCompiledFlow, writeComposeReport } from '../../src/runtime/runner.js';
src/flows/explore/writers/close.ts:10:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/explore/writers/close.ts:14:} from '../../../runtime/registries/close-writers/types.js';
src/flows/explore/writers/decision-options.ts:10:} from '../../../runtime/registries/compose-writers/types.js';
src/flows/explore/command.md:111:- `src/runtime/` (current runner)
src/flows/explore/writers/brief.ts:11:} from '../../../runtime/registries/compose-writers/types.js';
src/cli/create.ts:5:import { validateCompiledFlowKindPolicy } from '../runtime/policy/flow-kind-policy.js';
src/flows/explore/writers/decision.ts:11:} from '../../../runtime/registries/compose-writers/types.js';
tests/contracts/flow-model-effort.test.ts:6:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/contracts/flow-model-effort.test.ts:7:import { type RelayFn, type RelayInput, runCompiledFlow } from '../../src/runtime/runner.js';
src/flows/fix/writers/brief.ts:12:} from '../../../runtime/registries/compose-writers/types.js';
tests/runner/materializer-schema-parse.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/materializer-schema-parse.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/materializer-schema-parse.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/materializer-schema-parse.test.ts:41:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/materializer-schema-parse.test.ts:200:    expect(ge.reason).toMatch(/runtime-proof-strict@v1/);
src/flows/runtime-proof/index.ts:9:    schematic: 'src/flows/runtime-proof/schematic.json',
src/flows/explore/contract.md:369:`src/runtime/registries/report-schemas.ts`. The canonical report at
src/flows/explore/contract.md:387:`src/runtime/registries/report-schemas.ts` carries the strict
src/flows/explore/contract.md:394:`src/runtime/runner.ts` name the exact JSON shapes the connectors must
tests/runner/relay-handler-direct.test.ts:16:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/relay-handler-direct.test.ts:17:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/relay-handler-direct.test.ts:18:import { runRelayStep } from '../../src/runtime/step-handlers/relay.js';
tests/runner/relay-handler-direct.test.ts:19:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
src/cli/handoff.ts:6:import { readManifestSnapshot } from '../runtime/manifest-snapshot-writer.js';
src/cli/handoff.ts:7:import { deriveSnapshot } from '../runtime/snapshot-writer.js';
src/schemas/result.ts:15:// src/runtime/result-writer.ts); this schema only enforces shape.
src/flows/runtime-proof/writers/compose.ts:4:} from '../../../runtime/registries/compose-writers/types.js';
tests/runner/fresh-run-root.test.ts:14:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/fresh-run-root.test.ts:15:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/fresh-run-root.test.ts:16:import { manifestSnapshotPath } from '../../src/runtime/manifest-snapshot-writer.js';
tests/runner/fresh-run-root.test.ts:17:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/fresh-run-root.test.ts:23:} from '../../src/runtime/runner.js';
tests/runner/fresh-run-root.test.ts:24:import { snapshotPath } from '../../src/runtime/snapshot-writer.js';
tests/runner/fresh-run-root.test.ts:25:import { traceEntryLogPath } from '../../src/runtime/trace-writer.js';
tests/runner/fresh-run-root.test.ts:30:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
src/cli/runs.ts:4:} from '../runtime/run-status-projection.js';
src/flows/review/relay-hints.ts:10:import type { StructuralShapeHint } from '../../runtime/registries/shape-hints/types.js';
tests/runner/terminal-verdict-derivation.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/terminal-verdict-derivation.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/terminal-verdict-derivation.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/terminal-verdict-derivation.test.ts:31:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
src/flows/review/writers/intake.ts:14:} from '../../../runtime/registries/compose-writers/types.js';
tests/runner/cli-router.test.ts:9:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/cli-router.test.ts:10:import type { RelayFn, RelayInput } from '../../src/runtime/runner.js';
tests/runner/config-loader.test.ts:11:} from '../../src/runtime/config-loader.js';
tests/runner/config-loader.test.ts:12:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/config-loader.test.ts:13:import type { RelayFn, RelayInput } from '../../src/runtime/runner.js';
src/flows/review/writers/result.ts:14:} from '../../../runtime/registries/compose-writers/types.js';
tests/runner/handler-throw-recovery.test.ts:11:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/handler-throw-recovery.test.ts:12:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/handler-throw-recovery.test.ts:13:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/handler-throw-recovery.test.ts:14:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/handler-throw-recovery.test.ts:25:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
src/flows/migrate/relay-hints.ts:3:import type { SchemaShapeHint } from '../../runtime/registries/shape-hints/types.js';
tests/contracts/flow-kind-policy.test.ts:12:} from '../../src/runtime/policy/flow-kind-policy.js';
tests/contracts/flow-kind-policy.test.ts:321:    expect(result.detail).toMatch(/runtime-proof.*exempt/);
tests/runner/fix-runtime-wiring.test.ts:17:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/fix-runtime-wiring.test.ts:18:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/fix-runtime-wiring.test.ts:24:} from '../../src/runtime/runner.js';
tests/runner/explore-e2e-parity.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-e2e-parity.test.ts:12:import { validateCompiledFlowKindPolicy } from '../../src/runtime/policy/flow-kind-policy.js';
tests/runner/explore-e2e-parity.test.ts:13:import { type RelayFn, type RelayInput, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/explore-e2e-parity.test.ts:50:  'src/runtime/connectors/claude-code.ts',
tests/runner/explore-e2e-parity.test.ts:51:  'src/runtime/connectors/shared.ts',
tests/runner/explore-e2e-parity.test.ts:52:  'src/runtime/connectors/relay-materializer.ts',
tests/runner/explore-e2e-parity.test.ts:53:  'src/runtime/runner.ts',
tests/runner/explore-e2e-parity.test.ts:54:  'src/runtime/registries/report-schemas.ts',
tests/runner/sub-run-runtime.test.ts:6:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/sub-run-runtime.test.ts:14:} from '../../src/runtime/runner.js';
tests/runner/checkpoint-handler-direct.test.ts:16:import { runCheckpointStep } from '../../src/runtime/step-handlers/checkpoint.js';
tests/runner/checkpoint-handler-direct.test.ts:17:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/checkpoint-handler-direct.test.ts:18:import { traceEntryLogPath } from '../../src/runtime/trace-writer.js';
tests/runner/extract-json-object.test.ts:3:import { extractJsonObject } from '../../src/runtime/connectors/shared.js';
tests/runner/check-evaluation.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/check-evaluation.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/check-evaluation.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/check-evaluation.test.ts:29:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/runner-relay-connector-identity.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/runner-relay-connector-identity.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/runner-relay-connector-identity.test.ts:8:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/runner-relay-connector-identity.test.ts:30:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/build-report-writer.test.ts:19:} from '../../src/runtime/runner.js';
tests/runner/build-report-writer.test.ts:334:        changed_files: ['src/runtime/runner.ts'],
tests/runner/relay-shape-hint-registry.test.ts:20:} from '../../src/runtime/registries/shape-hints/registry.js';
tests/runner/relay-shape-hint-registry.test.ts:21:import type { RelayStep } from '../../src/runtime/registries/shape-hints/types.js';
tests/runner/plugin-command-invocation.test.ts:139:        expect(body).not.toMatch(/dist\/cli\/runtime-proof\.js/);
tests/runner/close-builder-registry.test.ts:21:import { findCloseBuilder } from '../../src/runtime/registries/close-writers/registry.js';
tests/runner/close-builder-registry.test.ts:22:import type { CloseBuilder } from '../../src/runtime/registries/close-writers/types.js';
tests/runner/close-builder-registry.test.ts:23:import { runCompiledFlow, writePrototypeComposeReport } from '../../src/runtime/runner.js';
tests/runner/runtime-smoke.test.ts:14:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/runtime-smoke.test.ts:15:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/runtime-smoke.test.ts:16:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/runtime-smoke.test.ts:17:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/runtime-smoke.test.ts:30:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/operator-summary-writer.test.ts:6:import { writeOperatorSummary } from '../../src/runtime/operator-summary-writer.js';
src/flows/migrate/writers/verification.ts:12:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/migrate/writers/verification.ts:18:} from '../../../runtime/registries/verification-writers/types.js';
src/flows/migrate/writers/brief.ts:13:} from '../../../runtime/registries/compose-writers/types.js';
tests/runner/pass-route-cycle-guard.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/pass-route-cycle-guard.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/pass-route-cycle-guard.test.ts:8:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/pass-route-cycle-guard.test.ts:9:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/pass-route-cycle-guard.test.ts:17:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
src/flows/migrate/writers/coexistence.ts:12:} from '../../../runtime/registries/compose-writers/types.js';
tests/runner/fix-report-writer.test.ts:22:import { writeComposeReport } from '../../src/runtime/runner.js';
tests/runner/migrate-runtime-wiring.test.ts:15:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/migrate-runtime-wiring.test.ts:16:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/migrate-runtime-wiring.test.ts:17:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/migrate-runtime-wiring.test.ts:25:} from '../../src/runtime/runner.js';
tests/runner/explore-report-writer.test.ts:13:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-report-writer.test.ts:14:import { type RelayFn, type RelayInput, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/sub-run-handler-direct.test.ts:20:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/sub-run-handler-direct.test.ts:26:} from '../../src/runtime/runner.js';
tests/runner/sub-run-handler-direct.test.ts:27:import { runSubRunStep } from '../../src/runtime/step-handlers/sub-run.js';
tests/runner/sub-run-handler-direct.test.ts:28:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
src/flows/migrate/writers/close.ts:14:import { reportPathForSchemaInCompiledFlow } from '../../../runtime/registries/close-writers/shared.js';
src/flows/migrate/writers/close.ts:18:} from '../../../runtime/registries/close-writers/types.js';
tests/runner/fanout-real-recursion.test.ts:13:// itself (per src/runtime/runner.ts:633), so each branch recurses
tests/runner/fanout-real-recursion.test.ts:24:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/fanout-real-recursion.test.ts:25:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/fanout-real-recursion.test.ts:31:} from '../../src/runtime/runner.js';
tests/runner/run-status-projection.test.ts:6:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/run-status-projection.test.ts:7:import { writeManifestSnapshot } from '../../src/runtime/manifest-snapshot-writer.js';
tests/runner/run-status-projection.test.ts:8:import { projectRunStatusFromRunFolder } from '../../src/runtime/run-status-projection.js';
tests/runner/run-status-projection.test.ts:9:import { appendTraceEntry } from '../../src/runtime/trace-writer.js';
tests/runner/agent-connector-smoke.test.ts:4:import { relayClaudeCode, sha256Hex } from '../../src/runtime/connectors/claude-code.js';
tests/runner/codex-connector-smoke.test.ts:3:import { relayCodex } from '../../src/runtime/connectors/codex.js';
tests/runner/codex-connector-smoke.test.ts:4:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/cross-report-validators.test.ts:6:import { reportPathForSchemaInCompiledFlow } from '../../src/runtime/registries/close-writers/shared.js';
tests/runner/cross-report-validators.test.ts:7:import { runCrossReportValidator } from '../../src/runtime/registries/cross-report-validators.js';
tests/unit/compile-schematic-per-mode.test.ts:10:import { compileSchematicToCompiledFlow } from '../../src/runtime/compile-schematic-to-flow.js';
tests/runner/push-sequence-authority.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/push-sequence-authority.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/push-sequence-authority.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/push-sequence-authority.test.ts:13:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/push-sequence-authority.test.ts:26:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/build-checkpoint-exec.test.ts:8:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/build-checkpoint-exec.test.ts:9:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/build-checkpoint-exec.test.ts:15:} from '../../src/runtime/runner.js';
tests/runner/sweep-runtime-wiring.test.ts:15:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/sweep-runtime-wiring.test.ts:16:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/sweep-runtime-wiring.test.ts:17:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/custom-connector-runtime.test.ts:3:import { relayCustom } from '../../src/runtime/connectors/custom.js';
tests/contracts/codex-host-plugin.test.ts:17:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/contracts/codex-host-plugin.test.ts:18:import type { RelayInput } from '../../src/runtime/runner.js';
tests/contracts/codex-host-plugin.test.ts:460:    expect(existsSync(resolve(PLUGIN_ROOT, 'flows/runtime-proof'))).toBe(false);
tests/contracts/codex-host-plugin.test.ts:461:    expect(existsSync(resolve(REPO_ROOT, '.claude-plugin/skills/runtime-proof'))).toBe(false);
tests/runner/run-relative-path.test.ts:14:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/run-relative-path.test.ts:15:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/run-relative-path.test.ts:16:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/run-relative-path.test.ts:17:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/run-relative-path.test.ts:23:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/runner/runner-relay-provenance.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/runner-relay-provenance.test.ts:7:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/runner-relay-provenance.test.ts:8:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/runner-relay-provenance.test.ts:9:import { resolveRelayDecision } from '../../src/runtime/relay-selection.js';
tests/runner/runner-relay-provenance.test.ts:10:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/runner-relay-provenance.test.ts:25:const FIXTURE_PATH = resolve('generated/flows/runtime-proof/circuit.json');
tests/contracts/build-report-schemas.test.ts:342:            file_refs: ['src/runtime/runner.ts'],
tests/runner/router-routing-invariants.test.ts:15:import { classifyTaskAgainstRoutables, deriveRoutingForTesting } from '../../src/runtime/router.js';
tests/contracts/compile-schematic-to-flow.test.ts:7:} from '../../src/runtime/compile-schematic-to-flow.js';
tests/contracts/relay-transcript-schema.test.ts:11:import { reduce } from '../../src/runtime/reducer.js';
tests/unit/runtime/event-log-round-trip.test.ts:15:} from '../../../src/runtime/manifest-snapshot-writer.js';
tests/unit/runtime/event-log-round-trip.test.ts:16:import { reduce } from '../../../src/runtime/reducer.js';
tests/unit/runtime/event-log-round-trip.test.ts:17:import { appendAndDerive, bootstrapRun, initRunFolder } from '../../../src/runtime/runner.js';
tests/unit/runtime/event-log-round-trip.test.ts:22:} from '../../../src/runtime/snapshot-writer.js';
tests/unit/runtime/event-log-round-trip.test.ts:23:import { readRunTrace } from '../../../src/runtime/trace-reader.js';
tests/unit/runtime/event-log-round-trip.test.ts:24:import { appendTraceEntry, traceEntryLogPath } from '../../../src/runtime/trace-writer.js';
tests/unit/emit-flows-drift.test.ts:22:const runtimeProofClaudeDir = resolve(projectRoot, '.claude-plugin/skills/runtime-proof');
tests/unit/emit-flows-drift.test.ts:23:const runtimeProofCodexDir = resolve(projectRoot, 'plugins/circuit/flows/runtime-proof');
tests/unit/emit-flows-drift.test.ts:105:    expect(combined).toContain('.claude-plugin/skills/runtime-proof');
tests/unit/emit-flows-drift.test.ts:106:    expect(combined).toContain('plugins/circuit/flows/runtime-proof');
tests/unit/emit-flows-drift.test.ts:123:      'removed internal host mirror .claude-plugin/skills/runtime-proof',
tests/unit/emit-flows-drift.test.ts:126:      'removed internal host mirror plugins/circuit/flows/runtime-proof',
tests/unit/runtime/progress-projector.test.ts:6:import { projectTraceEntryToProgress } from '../../../src/runtime/progress-projector.js';
```

## Runtime symbol and path references

```bash
rg -n "src/runtime|runtime/runner|runtime/step-handlers|runCompiledFlow|resumeCompiledFlowCheckpoint|RelayFn|ProgressReporter|relay-selection|selection-resolver|relay-support|write-capable-worker-disclosure|run-relative-path" README.md commands plugins .claude-plugin generated docs specs scripts src tests package.json -g "!docs/architecture/v2-runtime-import-inventory.md"
```

```text
commands/run.md:206:- `src/runtime/router.ts` (current deterministic classifier)
commands/build.md:117:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
tests/helpers/failure-message.ts:20:import type { StepHandlerResult } from '../../src/runtime/step-handlers/types.js';
scripts/policy/flow-kind-policy.d.mts:6: *   - src/runtime/policy/flow-kind-policy.ts — runtime-level
specs/reference/legacy-circuit/review-characterization.md:173:existing step kinds at `src/runtime/runner.ts` are `dispatch` and
specs/reference/legacy-circuit/review-characterization.md:230:adapter surface (`src/runtime/adapters/`). The shape is cited here for
docs/flows/authoring-model.md:19:- `src/runtime/compile-schematic-to-flow.ts` for schematic to compiled-flow projection.
scripts/policy/flow-kind-policy.mjs:3:// Consumed by src/runtime/policy/flow-kind-policy.ts, which wraps these
scripts/policy/flow-kind-policy.mjs:236: * in src/runtime/policy/flow-kind-policy.ts so this stays Zod-free and
tests/helpers/failure-message.test.ts:17:import type { StepHandlerResult } from '../../src/runtime/step-handlers/types.js';
commands/explore.md:111:- `src/runtime/` (current runner)
src/flows/build/command.md:117:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
commands/fix.md:123:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
scripts/release/emit-current-capabilities.mjs:499:    evidence: ['src/runtime/router.ts'],
scripts/release/emit-current-capabilities.mjs:544:    evidence: ['src/schemas/connector.ts', 'src/runtime/relay-selection.ts'],
scripts/release/emit-current-capabilities.mjs:702:      evidence: ['src/runtime/runner.ts', 'src/cli/circuit.ts'],
scripts/release/emit-current-capabilities.mjs:717:      evidence: ['src/runtime/snapshot-writer.ts', 'src/runtime/runner.ts', 'src/cli/handoff.ts'],
scripts/release/emit-current-capabilities.mjs:733:      evidence: ['src/runtime/router.ts', 'tests/contracts/flow-router.test.ts'],
scripts/release/emit-current-capabilities.mjs:776:        'src/runtime/write-capable-worker-disclosure.ts',
scripts/release/emit-current-capabilities.mjs:777:        'src/runtime/runner.ts',
scripts/release/emit-current-capabilities.mjs:778:        'src/runtime/operator-summary-writer.ts',
scripts/release/emit-current-capabilities.mjs:799:      evidence: ['src/runtime/compile-schematic-to-flow.ts'],
src/flows/build/writers/verification.ts:17:import { resolveRunRelative } from '../../../shared/run-relative-path.js';
specs/invariants.json:630:        { "path": "tests/runner/run-relative-path.test.ts", "kind": "test_title" }
docs/architecture/v2-phase-4-notes.md:87:compiled-flow bytes supplied to `runCompiledFlowV2`.
scripts/release/capture-golden-run-proofs.mjs:16:import { writeComposeReport } from '../../dist/runtime/runner.js';
src/flows/build/writers/checkpoint-brief.ts:25:import { resolveRunRelative } from '../../../shared/run-relative-path.js';
plugins/circuit/skills/run/SKILL.md:194:- `src/runtime/router.ts` (current deterministic classifier)
specs/reports.json:75:      "description": "Authoring-layer schematic shape for assembling reusable flow blocks into runnable compiled flows. Captures schematic steps, stage bindings, execution labels, typed evidence contracts, contract aliases, named route targets, and per-depth route_overrides. Compiled to generated/flows/<id>/circuit.json (and per-mode <mode>.json siblings) by src/runtime/compile-schematic-to-flow.ts at build time.",
specs/reports.json:252:      "trust_boundary": "operator-local derived state; state.json is written only by the reducer-derived snapshot writer at src/runtime/snapshot-writer.ts (never by step executors). A byte-match against a fresh reducer pass over run.trace is the re-entry check. Slice 27c lands the writer; re-entry byte-match enforcement in resume lands in Slice 27d+ per plan.",
specs/reports.json:279:      "trust_boundary": "operator-local persisted state; written once at bootstrap by the manifest snapshot writer at src/runtime/manifest-snapshot-writer.ts. Hash algorithm: SHA-256 over the exact persisted manifest snapshot bytes (`algorithm: 'sha256-raw'`), per ADR-0001 Addendum B §Stage 1.5 Close Criteria #8. Parse-time superRefine rejects any snapshot whose declared hash disagrees with sha256 over decoded bytes_base64; a second reader cannot be tricked into accepting a tampered byte-body under the declared hash.",
specs/reports.json:832:      "trust_boundary": "engine-computed at Close by the registered explore.result@v1 compose writer from schema-parsed compose.json and review-verdict.json plus flow-declared evidence link paths; terminal report — no in-run readers; cross-run reader is the run result consumer only; path-distinct from run.result so the engine's result-writer (src/runtime/result-writer.ts RESULT-I1 — single writer to result.json) and the orchestrator's close-step (flow-semantic aggregate at explore-result.json) do not collide",
docs/architecture/v2-migration-plan.md:12:`src/runtime/`, `src/cli/`, `src/schemas/`, `src/flows/`, `docs/contracts/`,
docs/architecture/v2-migration-plan.md:128:`src/runtime/compile-schematic-to-flow.ts`, `src/schemas/step.ts`, flow
docs/architecture/v2-migration-plan.md:176:Files likely involved: old `src/runtime/*`, old runner imports, CLI runtime
docs/architecture/v2-checkpoint-4.10.md:21:`src/runtime/progress-projector.ts` remains as the old trace-to-progress
docs/architecture/v2-checkpoint-4.10.md:30:It no longer imports `src/runtime/progress-projector.ts`.
generated/release/current-capabilities.json:520:      "evidence": ["src/schemas/connector.ts", "src/runtime/relay-selection.ts"],
generated/release/current-capabilities.json:536:      "evidence": ["src/schemas/connector.ts", "src/runtime/relay-selection.ts"],
generated/release/current-capabilities.json:552:      "evidence": ["src/schemas/connector.ts", "src/runtime/relay-selection.ts"],
generated/release/current-capabilities.json:569:      "evidence": ["src/runtime/runner.ts", "src/cli/circuit.ts"],
generated/release/current-capabilities.json:586:      "evidence": ["src/runtime/snapshot-writer.ts", "src/runtime/runner.ts", "src/cli/handoff.ts"],
generated/release/current-capabilities.json:603:      "evidence": ["src/runtime/router.ts", "tests/contracts/flow-router.test.ts"],
generated/release/current-capabilities.json:1647:      "evidence": ["src/runtime/compile-schematic-to-flow.ts"],
generated/release/current-capabilities.json:1662:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1677:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1692:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1707:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1722:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1737:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1752:      "evidence": ["src/runtime/router.ts"],
generated/release/current-capabilities.json:1805:        "src/runtime/write-capable-worker-disclosure.ts",
generated/release/current-capabilities.json:1806:        "src/runtime/runner.ts",
generated/release/current-capabilities.json:1807:        "src/runtime/operator-summary-writer.ts"
docs/architecture/v2-checkpoint-4.1.1.md:25:  `src/runtime/relay-support.ts`, so `core-v2` no longer imports
docs/architecture/v2-checkpoint-4.1.1.md:26:  `src/runtime/step-handlers/relay.ts` directly.
docs/architecture/v2-checkpoint-4.1.1.md:27:- A generated Review flow smoke test now runs through `runCompiledFlowV2` with
docs/architecture/v2-checkpoint-4.1.1.md:32:- `src/runtime/runner.ts` remains the production CLI runner.
docs/architecture/v2-checkpoint-4.1.1.md:33:- `src/runtime/step-handlers/relay.ts` remains for the old runtime path and old
docs/architecture/v2-checkpoint-4.1.1.md:35:- `src/runtime/runner-types.ts` remains because `RelayFn` is still shared by the
plugins/circuit/skills/build/SKILL.md:121:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
docs/architecture/v2-checkpoint-4.12.md:14:- `src/shared/relay-selection.ts`
docs/architecture/v2-checkpoint-4.12.md:23:`src/runtime/relay-selection.ts` re-exports those helpers for compatibility.
docs/architecture/v2-checkpoint-4.12.md:29:`src/runtime/relay-selection.ts` still owns retained relayer resolution,
scripts/emit-flows.mjs:5:// src/runtime/compile-schematic-to-flow.ts (consumed here through
docs/architecture/v2-checkpoint-4.14.md:14:- `src/shared/write-capable-worker-disclosure.ts`
docs/architecture/v2-checkpoint-4.14.md:22:`src/runtime/write-capable-worker-disclosure.ts` remains as a compatibility
plugins/circuit/skills/explore/SKILL.md:116:- `src/runtime/` (current runner)
docs/architecture/v2-deletion-plan.md:50:| `src/runtime/runner.ts` | retained execution path | The CLI still imports `runCompiledFlow` for unsupported modes, rollback, arbitrary fixtures, `composeWriter`, and checkpoint resume. Release proof scripts and many runner tests still use it. |
docs/architecture/v2-deletion-plan.md:51:| `src/runtime/runner-types.ts` | compatibility re-export plus retained runtime types | core-v2 imports shared relay/progress/run callback types from `src/shared/relay-runtime-types.ts`. Keep this file until retained runtime and tests stop importing the old surface. |
docs/architecture/v2-deletion-plan.md:52:| `src/runtime/step-handlers/checkpoint.ts` | checkpoint pause/resume and retained checkpoint modes | v2 handles fresh safe checkpoint choices, but checkpoint waiting and resume stay retained-runtime-owned. |
docs/architecture/v2-deletion-plan.md:53:| `src/runtime/step-handlers/compose.ts` | retained fallback and programmatic compose writer hook | core-v2 uses catalog writers, but `main(..., { composeWriter })` intentionally falls back to retained runtime. |
docs/architecture/v2-deletion-plan.md:54:| `src/runtime/step-handlers/relay.ts` | retained relay handler and oracle tests | core-v2 no longer imports this file directly, but retained runtime and handler tests still do. |
docs/architecture/v2-deletion-plan.md:55:| `src/runtime/step-handlers/sub-run.ts` | retained fallback and oracle tests | core-v2 has sub-run coverage, but unsupported fallback paths and old tests still rely on the old handler. |
docs/architecture/v2-deletion-plan.md:56:| `src/runtime/step-handlers/fanout.ts` and `src/runtime/step-handlers/fanout/*` | retained fallback and fanout oracle tests | core-v2 has fanout slices, but old fanout behavior remains the comparison oracle. |
docs/architecture/v2-deletion-plan.md:57:| `src/runtime/step-handlers/verification.ts` | retained fallback and verification oracle tests | core-v2 can run flow-owned verification writers, but old verification tests remain useful until migration. |
docs/architecture/v2-deletion-plan.md:58:| `src/runtime/step-handlers/recovery-route.ts` | retained runner recovery behavior | core-v2 has bounded recovery tests, but old runner tests still cover the retained path. |
docs/architecture/v2-deletion-plan.md:59:| `src/runtime/step-handlers/shared.ts`, `src/runtime/step-handlers/types.ts`, `src/runtime/step-handlers/index.ts` | retained handler support | Delete only with the old handler cluster. |
docs/architecture/v2-deletion-plan.md:67:These files live under `src/runtime/`, but they are not simply old graph-runner
docs/architecture/v2-deletion-plan.md:72:| `src/runtime/compile-schematic-to-flow.ts` | keep / compiler infrastructure | `scripts/emit-flows.mjs`, compiler tests, and generated flow output still use it. |
docs/architecture/v2-deletion-plan.md:73:| `src/runtime/catalog-derivations.ts` | keep / catalog infrastructure | Router, generated surfaces, and catalog tests depend on catalog-derived data. |
docs/architecture/v2-deletion-plan.md:74:| `src/runtime/registries/**` | keep / later move | Flow packages, v2 report validation, writer discovery, cross-report validators, and shape hints depend on these registries. |
docs/architecture/v2-deletion-plan.md:75:| `src/runtime/connectors/**` | keep / later move | core-v2 reuses real connector subprocesses, relay materialization, argv validation, and shared connector helpers. |
docs/architecture/v2-deletion-plan.md:76:| `src/runtime/relay-support.ts` | compatibility re-export | Relay prompt and check helpers moved to `src/shared/relay-support.ts` in Phase 4.13. Keep this wrapper until retained relay handler imports and old tests stop using the old path. |
docs/architecture/v2-deletion-plan.md:77:| `src/runtime/config-loader.ts` | keep / later move | CLI config discovery feeds both retained runtime and core-v2 connector resolution. |
docs/architecture/v2-deletion-plan.md:78:| `src/runtime/router.ts` | keep / later move | Natural-language flow selection still uses the current router. |
docs/architecture/v2-deletion-plan.md:79:| `src/runtime/relay-selection.ts` | retained relay decision bridge | Selection-depth helpers moved to `src/shared/relay-selection.ts` in Phase 4.12. Keep this file for retained relayer resolution, connector bridge behavior, old relay handler imports, and relay provenance tests. |
docs/architecture/v2-deletion-plan.md:80:| `src/runtime/selection-resolver.ts` | compatibility re-export | Selection precedence logic moved to `src/shared/selection-resolver.ts` in Phase 4.11. Keep this wrapper until retained runtime tests and external imports stop using the old path. |
docs/architecture/v2-deletion-plan.md:81:| `src/runtime/result-writer.ts` | retain until old result tests migrate | core-v2 has its own result writer, but retained runtime and old result tests still use this one. |
docs/architecture/v2-deletion-plan.md:82:| `src/runtime/manifest-snapshot-writer.ts` | retain until old resume/status tests migrate | core-v2 has raw-byte snapshots, but old runner resume/status tests still use this writer. |
docs/architecture/v2-deletion-plan.md:83:| `src/runtime/snapshot-writer.ts` | retain for state snapshots and continuity | Used by retained runner, checkpoint handler, `append-and-derive`, `cli/handoff`, event-log round-trip tests, fresh-run-root tests, release evidence, and state snapshot behavior. |
docs/architecture/v2-deletion-plan.md:84:| `src/runtime/operator-summary-writer.ts` | keep / later move | CLI writes operator summaries for both v2 and retained runs. |
docs/architecture/v2-deletion-plan.md:85:| `src/runtime/run-status-projection.ts` | keep | This is now the compatibility projector for both v1 and v2 run folders. |
docs/architecture/v2-deletion-plan.md:86:| `src/runtime/progress-projector.ts` | retained trace-to-progress projection | core-v2 imports shared helpers from `src/shared/progress-output.ts`. Keep this file for old trace projection, retained runtime imports, and old progress tests. |
docs/architecture/v2-deletion-plan.md:87:| `src/runtime/reducer.ts`, `src/runtime/append-and-derive.ts`, `src/runtime/trace-reader.ts`, `src/runtime/trace-writer.ts` | retain until trace/projection tests migrate | Old trace infrastructure remains the v1 oracle and status/progress source for retained runs. |
docs/architecture/v2-deletion-plan.md:88:| `src/runtime/policy/flow-kind-policy.ts` | keep | Generated-surface and fixture policy, not old execution. |
docs/architecture/v2-deletion-plan.md:89:| `src/runtime/write-capable-worker-disclosure.ts` | compatibility re-export | Disclosure helper moved to `src/shared/write-capable-worker-disclosure.ts` in Phase 4.14. Keep this wrapper while retained runtime and operator summary imports use the old path. |
docs/architecture/v2-deletion-plan.md:90:| `src/runtime/run-relative-path.ts` | compatibility re-export | Run-relative path helper moved to `src/shared/run-relative-path.ts` in Phase 4.15. Keep this wrapper while retained runtime, connector materialization, old handlers, projection, and operator summary imports use the old path. |
docs/architecture/v2-deletion-plan.md:107:| `runtime/runner` | `src/cli/circuit.ts`, release proof script, many `tests/runner/*`, selected contract tests | retained execution | Keep until unsupported modes, rollback, `composeWriter`, fixtures, and checkpoint resume have explicit replacement or retained-module ownership. |
docs/architecture/v2-deletion-plan.md:108:| `runtime/runner-types` | retained runtime, `src/cli/circuit.ts`, tests | compatibility re-export | core-v2 no longer imports this file. Keep until retained runtime and tests stop importing the old type surface. |
docs/architecture/v2-deletion-plan.md:109:| `runtime/step-handlers` | direct handler tests and retained runner | retained execution oracle | Migrate tests only after v2 owns the behavior or the behavior stays retained by policy. |
docs/architecture/v2-deletion-plan.md:112:| `runtime/relay-support` | old relay handler and compatibility imports | compatibility re-export | core-v2 no longer imports this file. Shared helper ownership now lives in `src/shared/relay-support.ts`. |
docs/architecture/v2-deletion-plan.md:113:| `runtime/relay-selection` | retained relay handler, old runner, and old relay tests | retained relay decision bridge | core-v2 no longer imports this file. Keep until retained relayer resolution and connector bridge behavior move or stay behind an explicit retained module. |
docs/architecture/v2-deletion-plan.md:114:| `runtime/selection-resolver` | retained tests and compatibility imports | compatibility re-export | Neutral ownership now lives in `src/shared/selection-resolver.ts`; keep wrapper until old-path imports migrate. |
docs/architecture/v2-deletion-plan.md:140:- `src/shared/selection-resolver.ts`
docs/architecture/v2-deletion-plan.md:141:- `src/shared/relay-selection.ts`
docs/architecture/v2-deletion-plan.md:142:- `src/shared/relay-support.ts`
docs/architecture/v2-deletion-plan.md:143:- `src/shared/write-capable-worker-disclosure.ts`
docs/architecture/v2-deletion-plan.md:144:- `src/shared/run-relative-path.ts`
docs/architecture/v2-deletion-plan.md:173:find src/runtime -type f | sort
docs/architecture/v2-deletion-plan.md:175:rg -n "runCompiledFlow|resumeCompiledFlowCheckpoint|RelayFn|ProgressReporter|deriveResolvedSelection|resolveSelection" src tests scripts docs
docs/architecture/v2-deletion-plan.md:188:| Move shared relay/progress types out of `src/runtime/runner-types.ts` | Done in Phase 4.9 for `RelayFn`, `RelayInput`, `ProgressReporter`, and `RuntimeEvidencePolicy`. `runner-types.ts` remains as a compatibility re-export plus retained runtime invocation/result types. | Keep full validation green while retained runtime and tests continue importing the old surface. |
docs/architecture/v2-deletion-plan.md:189:| Move progress helper functions out of `src/runtime/progress-projector.ts` | Done in Phase 4.10 for `progressDisplay` and `reportProgress`. `progress-projector.ts` re-exports them for compatibility and still owns old trace-to-progress projection. | Keep progress schema tests, old progress-projector tests, CLI v2 progress tests, and full validation green. |
docs/architecture/v2-deletion-plan.md:190:| Move relay selection support to a neutral module | Mostly done in Phases 4.11 and 4.12 for selection ownership: `src/shared/selection-resolver.ts` owns `resolveSelectionForRelay`, and `src/shared/relay-selection.ts` owns depth-bound selection derivation. `src/runtime/relay-selection.ts` remains for retained relayer resolution and connector bridge behavior. | Config loader tests, selection contract tests, relay provenance tests, core-v2 connector tests, CLI custom connector precedence tests, full `npm run verify`. |
docs/architecture/v2-deletion-plan.md:191:| Move run-relative path helper out of `src/runtime/run-relative-path.ts` | Done in Phase 4.15 for `resolveRunRelative`. Flow writers and shared relay support now import `src/shared/run-relative-path.ts`; the runtime file remains a compatibility re-export for retained runtime surfaces. | Keep run-relative path containment tests, materializer tests, report writer tests, CLI v2 tests, and full validation green. |
tests/core-v2/default-executors-v2.test.ts:5:import { runCompiledFlowV2 } from '../../src/core-v2/run/compiled-flow-runner.js';
tests/core-v2/default-executors-v2.test.ts:18:      const result = await runCompiledFlowV2({
src/flows/sweep/writers/verification.ts:19:import { resolveRunRelative } from '../../../shared/run-relative-path.js';
src/shared/relay-selection.ts:6:import type { RelayFn } from './relay-runtime-types.js';
src/shared/relay-selection.ts:7:import { resolveSelectionForRelay } from './selection-resolver.js';
src/shared/relay-selection.ts:10:  readonly relayer?: RelayFn;
docs/architecture/v2-checkpoint-4.1.md:42:- `src/runtime/runner.ts`
docs/architecture/v2-checkpoint-4.1.md:43:- `src/runtime/runner-types.ts`
docs/architecture/v2-checkpoint-4.1.md:44:- `src/runtime/step-handlers/checkpoint.ts`
docs/architecture/v2-checkpoint-4.1.md:45:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-checkpoint-4.1.md:46:- `src/runtime/step-handlers/verification.ts`
docs/architecture/v2-checkpoint-4.1.md:47:- `src/runtime/relay-selection.ts`
docs/architecture/v2-checkpoint-4.1.md:48:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-checkpoint-4.1.md:49:- `src/runtime/result-writer.ts`
plugins/circuit/skills/fix/SKILL.md:127:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
docs/architecture/v2-checkpoint-4.7.md:49:Several files under `src/runtime/` are not old execution code and should be
docs/architecture/v2-checkpoint-4.15.md:14:- `src/shared/run-relative-path.ts`
docs/architecture/v2-checkpoint-4.15.md:20:`src/runtime/run-relative-path.ts` remains as a compatibility re-export.
docs/architecture/v2-checkpoint-4.15.md:56:- `npx vitest run tests/runner/run-relative-path.test.ts tests/runner/materializer-schema-parse.test.ts tests/runner/relay-handler-direct.test.ts tests/runner/build-report-writer.test.ts tests/runner/fix-report-writer.test.ts tests/runner/explore-report-writer.test.ts tests/runner/sweep-runtime-wiring.test.ts tests/runner/migrate-runtime-wiring.test.ts tests/core-v2/connectors-v2.test.ts tests/runner/cli-v2-runtime.test.ts`: passed.
docs/architecture/v2-checkpoint-4.13.md:14:- `src/shared/relay-support.ts`
docs/architecture/v2-checkpoint-4.13.md:24:`src/runtime/relay-support.ts` remains as a compatibility re-export.
docs/architecture/v2-checkpoint-4.13.md:33:- `src/runtime/registries/shape-hints/registry.ts`
docs/architecture/v2-checkpoint-4.13.md:34:- `src/runtime/run-relative-path.ts`
src/shared/relay-runtime-types.ts:8:export interface RelayFn {
src/shared/relay-runtime-types.ts:18:export type ProgressReporter = (event: ProgressEvent) => void;
src/flows/fix/command.md:123:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
src/shared/progress-output.ts:2:import type { ProgressReporter } from './relay-runtime-types.js';
src/shared/progress-output.ts:6:export function reportProgress(progress: ProgressReporter | undefined, event: ProgressEvent): void {
plugins/circuit/commands/run.md:205:- `src/runtime/router.ts` (current deterministic classifier)
docs/positioning-and-strategy.md:64:| Customize skills at step / flow / setup level | **Strongly supported** | `selection-resolver.ts` resolves across config layers; `SkillOverride` modes: `inherit | replace | append | remove` |
src/shared/relay-support.ts:4:import { resolveRunRelative } from './run-relative-path.js';
plugins/circuit/commands/build.md:116:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
docs/architecture/v2-checkpoint-4.2.md:18:This routes only supported fresh runs through `runCompiledFlowV2(...)`.
docs/architecture/v2-checkpoint-4.2.md:42:The opt-in path passes raw generated manifest bytes into `runCompiledFlowV2`.
docs/architecture/v2-worklog.md:17:- `src/runtime/`
docs/architecture/v2-worklog.md:18:- `src/runtime/connectors/`
docs/architecture/v2-worklog.md:19:- `src/runtime/step-handlers/`
docs/architecture/v2-worklog.md:188:- `src/runtime/result-writer.ts`
docs/architecture/v2-worklog.md:301:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:350:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:398:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:399:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:400:- `src/runtime/result-writer.ts`
docs/architecture/v2-worklog.md:401:- `src/runtime/step-handlers/`
docs/architecture/v2-worklog.md:476:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:525:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:587:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:588:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-worklog.md:642:- `src/runtime/**`
docs/architecture/v2-worklog.md:643:- current imports referencing `src/runtime/`
docs/architecture/v2-worklog.md:669:- `src/runtime/runner.ts` remains live for retained fallback, rollback,
docs/architecture/v2-worklog.md:672:- Several `src/runtime/` modules are shared infrastructure and should be moved
docs/architecture/v2-worklog.md:685:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:686:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:688:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:715:- `selection-resolver.ts` is live selection infrastructure through
docs/architecture/v2-worklog.md:716:  `relay-selection.ts`, not just a test oracle.
docs/architecture/v2-worklog.md:725:shared relay/progress callback types out of `src/runtime/runner-types.ts`.
docs/architecture/v2-worklog.md:729:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:740:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:763:Behavior changed? No runtime behavior changed. `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:779:the shared progress output helpers out of `src/runtime/progress-projector.ts`.
docs/architecture/v2-worklog.md:783:- `src/runtime/progress-projector.ts`
docs/architecture/v2-worklog.md:791:- `src/runtime/progress-projector.ts`
docs/architecture/v2-worklog.md:818:- `src/runtime/progress-projector.ts` remains live for retained runtime and old
docs/architecture/v2-worklog.md:827:precedence resolver out of `src/runtime/selection-resolver.ts`.
docs/architecture/v2-worklog.md:831:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:832:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:839:- `src/shared/selection-resolver.ts`
docs/architecture/v2-worklog.md:840:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:841:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:865:lives in `src/shared/selection-resolver.ts`; the old runtime
docs/architecture/v2-worklog.md:866:`selection-resolver.ts` file re-exports it for compatibility.
docs/architecture/v2-worklog.md:871:- `src/runtime/relay-selection.ts` remains live for retained relay decision
docs/architecture/v2-worklog.md:875:leaving retained relayer resolution in `runtime/relay-selection.ts`.
docs/architecture/v2-worklog.md:879:Goal: reduce core-v2's dependency on `src/runtime/relay-selection.ts` by moving
docs/architecture/v2-worklog.md:885:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:886:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:887:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:895:- `src/shared/relay-selection.ts`
docs/architecture/v2-worklog.md:896:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:918:`src/shared/relay-selection.ts`; `src/runtime/relay-selection.ts` re-exports
docs/architecture/v2-worklog.md:924:- `src/runtime/relay-selection.ts` remains live for retained relayer resolution,
docs/architecture/v2-worklog.md:928:Next recommended action: continue with relay-support helper extraction, still
docs/architecture/v2-worklog.md:933:Goal: reduce core-v2's dependency on `src/runtime/relay-support.ts` by moving
docs/architecture/v2-worklog.md:938:- `src/runtime/relay-support.ts`
docs/architecture/v2-worklog.md:939:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:940:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-worklog.md:946:- `src/shared/relay-support.ts`
docs/architecture/v2-worklog.md:947:- `src/runtime/relay-support.ts`
docs/architecture/v2-worklog.md:968:`NO_VERDICT_SENTINEL` now live in `src/shared/relay-support.ts`;
docs/architecture/v2-worklog.md:969:`src/runtime/relay-support.ts` re-exports them for retained runtime
docs/architecture/v2-worklog.md:983:Goal: reduce core-v2's dependency on `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:988:- `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:990:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:991:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-worklog.md:996:- `src/shared/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:997:- `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-worklog.md:1018:flow helpers now live in `src/shared/write-capable-worker-disclosure.ts`;
docs/architecture/v2-worklog.md:1019:`src/runtime/write-capable-worker-disclosure.ts` re-exports them for retained
docs/architecture/v2-worklog.md:1027:Next recommended action: inspect `src/runtime/run-relative-path.ts` as the next
docs/architecture/v2-worklog.md:1034:`src/runtime/run-relative-path.ts` without changing path safety semantics.
docs/architecture/v2-worklog.md:1038:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-worklog.md:1039:- `src/shared/relay-support.ts`
docs/architecture/v2-worklog.md:1041:- `tests/runner/run-relative-path.test.ts`
docs/architecture/v2-worklog.md:1046:- `src/shared/run-relative-path.ts`
docs/architecture/v2-worklog.md:1047:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-worklog.md:1048:- `src/shared/relay-support.ts`
docs/architecture/v2-worklog.md:1050:- `tests/runner/run-relative-path.test.ts`
docs/architecture/v2-worklog.md:1060:- `npx vitest run tests/runner/run-relative-path.test.ts tests/runner/materializer-schema-parse.test.ts tests/runner/relay-handler-direct.test.ts tests/runner/build-report-writer.test.ts tests/runner/fix-report-writer.test.ts tests/runner/explore-report-writer.test.ts tests/runner/sweep-runtime-wiring.test.ts tests/runner/migrate-runtime-wiring.test.ts tests/core-v2/connectors-v2.test.ts tests/runner/cli-v2-runtime.test.ts`:
docs/architecture/v2-worklog.md:1065:in `src/shared/run-relative-path.ts`; `src/runtime/run-relative-path.ts`
docs/architecture/v2-worklog.md:1087:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1098:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1142:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1155:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-worklog.md:1300:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:1301:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:1310:- `src/runtime/relay-support.ts`
docs/architecture/v2-worklog.md:1311:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-worklog.md:1337:- `RelayFn` still lives in `src/runtime/runner-types.ts` and should move to a
docs/architecture/v2-worklog.md:1679:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-worklog.md:1736:- `src/runtime/`
docs/architecture/v2-worklog.md:1737:- `src/runtime/runner.ts`
docs/architecture/v2-worklog.md:1738:- `src/runtime/runner-types.ts`
docs/architecture/v2-worklog.md:1739:- `src/runtime/step-handlers/`
docs/architecture/v2-worklog.md:1740:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-worklog.md:1741:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-worklog.md:1742:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-worklog.md:1743:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:1744:- `src/runtime/registries/`
docs/architecture/v2-worklog.md:1776:  CLI execution still imports `runCompiledFlow`.
docs/architecture/v2-worklog.md:1777:- Some files under `src/runtime/` are still live compiler, catalog, registry,
docs/architecture/v2-worklog.md:1833:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-worklog.md:1916:- `src/runtime/step-handlers/sub-run.ts`
docs/architecture/v2-worklog.md:1917:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-worklog.md:1918:- `src/runtime/step-handlers/fanout/branch-resolution.ts`
docs/architecture/v2-worklog.md:1919:- `src/runtime/step-handlers/fanout/join-policy.ts`
docs/architecture/v2-worklog.md:1920:- `src/runtime/relay-selection.ts`
docs/architecture/v2-worklog.md:1921:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-worklog.md:1922:- `src/runtime/connectors/codex.ts`
src/core-v2/run/compiled-flow-runner.ts:8:  ProgressReporter,
src/core-v2/run/compiled-flow-runner.ts:9:  RelayFn,
src/core-v2/run/compiled-flow-runner.ts:38:  readonly relayer?: RelayFn;
src/core-v2/run/compiled-flow-runner.ts:40:  readonly progress?: ProgressReporter;
src/core-v2/run/compiled-flow-runner.ts:65:export async function runCompiledFlowV2(
src/core-v2/run/compiled-flow-runner.ts:97:      childRunner: options.childRunner ?? runCompiledFlowV2,
docs/architecture/v2-checkpoint-4.11.md:14:- `src/shared/selection-resolver.ts`
docs/architecture/v2-checkpoint-4.11.md:21:`src/runtime/selection-resolver.ts` remains as a compatibility re-export.
docs/architecture/v2-checkpoint-4.11.md:25:`src/runtime/relay-selection.ts` now imports selection precedence from the
docs/architecture/v2-checkpoint-4.11.md:29:The full `relay-selection.ts` move is intentionally deferred because it also
plugins/circuit/commands/explore.md:110:- `src/runtime/` (current runner)
tests/properties/visible/flow-router-tiebreak.test.ts:3:// src/runtime/router.ts.
tests/properties/visible/flow-router-tiebreak.test.ts:32:import type { RoutablePackage } from '../../../src/runtime/catalog-derivations.js';
tests/properties/visible/flow-router-tiebreak.test.ts:33:import { classifyTaskAgainstRoutables } from '../../../src/runtime/router.js';
docs/contracts/selection.md:142:  `src/runtime/connectors/*.ts` for connector-specific honoring.
docs/contracts/selection.md:233:  (`src/shared/selection-resolver.ts`, Slice 85) folding an ordered
src/core-v2/run/run-context.ts:4:  ProgressReporter,
src/core-v2/run/run-context.ts:5:  RelayFn,
src/core-v2/run/run-context.ts:39:  readonly relayer?: RelayFn;
src/core-v2/run/run-context.ts:41:  readonly progress?: ProgressReporter;
src/flows/fix/writers/verification.ts:18:import { resolveRunRelative } from '../../../shared/run-relative-path.js';
docs/contracts/skill.md:74:  - `description` — selection-resolver input; "when should I use
docs/architecture/v2-checkpoint-4.md:30:- `src/runtime/runner.ts`
docs/architecture/v2-checkpoint-4.md:31:- `src/runtime/runner-types.ts`
docs/architecture/v2-checkpoint-4.md:32:- `src/runtime/step-handlers/checkpoint.ts`
docs/architecture/v2-checkpoint-4.md:33:- `src/runtime/step-handlers/compose.ts`
docs/architecture/v2-checkpoint-4.md:34:- `src/runtime/step-handlers/relay.ts`
docs/architecture/v2-checkpoint-4.md:35:- `src/runtime/step-handlers/sub-run.ts`
docs/architecture/v2-checkpoint-4.md:36:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-checkpoint-4.md:37:- `src/runtime/step-handlers/fanout/aggregate.ts`
docs/architecture/v2-checkpoint-4.md:38:- `src/runtime/step-handlers/fanout/branch-resolution.ts`
docs/architecture/v2-checkpoint-4.md:39:- `src/runtime/step-handlers/fanout/join-policy.ts`
docs/architecture/v2-checkpoint-4.md:40:- `src/runtime/step-handlers/fanout/types.ts`
docs/architecture/v2-checkpoint-4.md:41:- `src/runtime/step-handlers/verification.ts`
docs/architecture/v2-checkpoint-4.md:42:- `src/runtime/step-handlers/recovery-route.ts`
docs/architecture/v2-checkpoint-4.md:43:- `src/runtime/step-handlers/shared.ts`
docs/architecture/v2-checkpoint-4.md:44:- `src/runtime/step-handlers/types.ts`
docs/architecture/v2-checkpoint-4.md:46:The deletion should be a narrow approved slice, not a whole-tree `src/runtime/`
docs/architecture/v2-checkpoint-4.md:53:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-checkpoint-4.md:54:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-checkpoint-4.md:55:- `src/runtime/registries/**`
docs/architecture/v2-checkpoint-4.md:56:- `src/runtime/connectors/**`
docs/architecture/v2-checkpoint-4.md:57:- `src/runtime/config-loader.ts`
docs/architecture/v2-checkpoint-4.md:58:- `src/runtime/router.ts`
docs/architecture/v2-checkpoint-4.md:59:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.md:60:- `src/runtime/snapshot-writer.ts`
docs/architecture/v2-checkpoint-4.md:61:- `src/runtime/operator-summary-writer.ts`
docs/architecture/v2-checkpoint-4.md:62:- `src/runtime/progress-projector.ts`
docs/architecture/v2-checkpoint-4.md:63:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-checkpoint-4.md:64:- `src/runtime/reducer.ts`
docs/architecture/v2-checkpoint-4.md:65:- `src/runtime/trace-reader.ts`
docs/architecture/v2-checkpoint-4.md:66:- `src/runtime/trace-writer.ts`
docs/architecture/v2-checkpoint-4.md:67:- `src/runtime/append-and-derive.ts`
docs/architecture/v2-checkpoint-4.md:68:- `src/runtime/policy/flow-kind-policy.ts`
docs/architecture/v2-checkpoint-4.md:69:- `src/runtime/write-capable-worker-disclosure.ts`
docs/architecture/v2-checkpoint-4.md:70:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-checkpoint-4.md:82:| `runtime/runner` | production CLI, release proof script, old runner tests, a few contract tests | replace with v2 before deleting runner |
docs/architecture/v2-checkpoint-4.md:83:| `runtime/step-handlers` | direct handler tests and property tests | delete or rewrite after v2 executor coverage is accepted |
docs/architecture/v2-checkpoint-4.md:87:| `runtime/relay-selection` | old relay provenance tests | replace with v2 connector/config tests |
docs/architecture/v2-checkpoint-4.md:88:| `runtime/selection-resolver` | flow model/effort contract test | replace with v2 config precedence tests |
docs/architecture/v2-checkpoint-4.md:94:rg -n "runCompiledFlow|executeCompiledFlow|compileSchematicToFlow|CompiledFlow|flow-schematic|runtime/runner|runtime/step-handlers|runtime/catalog-derivations|runtime/registries|relay-selection|selection-resolver" src tests docs specs scripts commands plugins .claude-plugin generated README.md package.json
docs/architecture/v2-checkpoint-4.md:95:rg -n "from ['\"].*runtime/(runner|step-handlers|catalog-derivations|registries|relay-selection|selection-resolver)|from ['\"].*runtime/(compile-schematic-to-flow)" src tests scripts
docs/architecture/v2-checkpoint-4.md:96:rg -l "from ['\"].*runtime/runner" src tests scripts
docs/architecture/v2-checkpoint-4.md:97:rg -l "from ['\"].*runtime/step-handlers" src tests scripts
docs/architecture/v2-checkpoint-4.md:99:rg -l "from ['\"].*runtime/(catalog-derivations|relay-selection|selection-resolver|compile-schematic-to-flow)" src tests scripts
docs/architecture/v2-checkpoint-4.md:209:- Deleting all of `src/runtime/` would remove live compiler/catalog/report/config
docs/architecture/v2-checkpoint-4.md:234:1. route production CLI run execution through `runCompiledFlowV2`;
docs/architecture/v2-checkpoint-4.8.md:16:First, `src/runtime/selection-resolver.ts` is not just a test oracle. It is
docs/architecture/v2-checkpoint-4.8.md:18:core-v2 relay through `src/runtime/relay-selection.ts`.
docs/architecture/v2-checkpoint-4.8.md:20:Second, `src/runtime/progress-projector.ts` is not only old runtime/test
docs/architecture/v2-checkpoint-4.8.md:33:find src/runtime -type f | sort
docs/architecture/v2-checkpoint-4.8.md:35:rg -n "runCompiledFlow|resumeCompiledFlowCheckpoint|RelayFn|ProgressReporter|deriveResolvedSelection|resolveSelection" src tests scripts docs
docs/architecture/v2-checkpoint-4.8.md:47:1. Move shared relay/progress types out of `src/runtime/runner-types.ts`.
docs/architecture/v2-checkpoint-4.8.md:48:2. Move shared progress helper functions out of `src/runtime/progress-projector.ts`.
docs/architecture/v2-checkpoint-4.8.md:49:3. Move relay selection support out of `src/runtime/relay-selection.ts` and
docs/architecture/v2-checkpoint-4.8.md:50:   `src/runtime/selection-resolver.ts`.
tests/properties/visible/cross-report-validator.test.ts:16:import { reportPathForSchemaInCompiledFlow } from '../../../src/runtime/registries/close-writers/shared.js';
tests/properties/visible/cross-report-validator.test.ts:17:import { runCrossReportValidator } from '../../../src/runtime/registries/cross-report-validators.js';
plugins/circuit/commands/fix.md:122:- `src/runtime/router.ts` (router bypass behavior for explicit flow names)
src/core-v2/run/child-runner.ts:3:  ProgressReporter,
src/core-v2/run/child-runner.ts:4:  RelayFn,
src/core-v2/run/child-runner.ts:56:  readonly relayer?: RelayFn;
src/core-v2/run/child-runner.ts:58:  readonly progress?: ProgressReporter;
docs/contracts/step.md:144:  `src/shared/run-relative-path.ts` before reading or writing. The old
docs/contracts/step.md:145:  `src/runtime/run-relative-path.ts` path is a retained compatibility wrapper.
docs/architecture/v2-rigor-audit.md:11:| Trace sequence authority | `src/runtime/runner.ts`, `src/schemas/run.ts`, `docs/contracts/run.md` | Trace corruption, duplicate sequence numbers, status projection drift | Reducer, progress projector, run status, reports | Runner `push()` assigns sequence numbers before append | keep | `trace/trace-store.ts` | `tests/runner/push-sequence-authority.test.ts`, `tests/contracts/runtrace-schema.test.ts` | One component must own sequence assignment. |
docs/architecture/v2-rigor-audit.md:12:| Run bootstrap rules | `src/runtime/runner.ts`, `src/schemas/run.ts`, `docs/contracts/run.md` | Ambiguous run identity, missing manifest snapshot, invalid resume base | CLI, run reducer, status reader | `run.bootstrapped` first entry, manifest snapshot writer, strict trace schema | keep | `run/run-context.ts` and trace store | Run trace schema tests, status projection tests | Bootstrap should stay explicit and single. |
docs/architecture/v2-rigor-audit.md:13:| Run close rules | `src/runtime/runner.ts`, `src/runtime/result-writer.ts`, `src/schemas/run.ts` | Runs that keep accepting entries after completion, wrong terminal result | CLI, status projection, operator summary | `run.closed`, result writer, trace close validation | keep | `run/graph-runner.ts` and `run/result-writer.ts` | Run trace and runner tests | Close should be a graph-runner responsibility, with result writing isolated. |
docs/architecture/v2-rigor-audit.md:14:| Resume rules | `src/runtime/runner.ts`, checkpoint handler, run status projection | Resuming the wrong checkpoint, stale request reuse, mismatched manifest | CLI resume path, checkpoint waiting state | Saved manifest, checkpoint request validation, resume choice checks | keep | `run/resume.ts` | Checkpoint and status projection tests | Keep behavior. Split resume from main runner. |
docs/architecture/v2-rigor-audit.md:15:| Connector capability rules | `docs/contracts/connector.md`, `src/schemas/connector.ts`, `src/runtime/connectors/` | Wrong connector writes, sandbox bypass, unsafe argv, unknown provider effort | Relay runtime, config resolution, tests | Schema checks, argv guards, subprocess flags, provider effort allowlists | keep | `connectors/resolver.ts` and connector modules | Connector schema, Codex, custom connector, identity tests | This is load-bearing and should not be loosened for migration speed. |
docs/architecture/v2-rigor-audit.md:16:| Selection/config precedence | `src/runtime/selection-resolver.ts`, `src/runtime/relay-selection.ts`, `docs/contracts/selection.md`, `docs/contracts/config.md` | Ambiguous model/effort/connector choice, hidden overrides | Relay prompt builder, CLI config loader | Layered config fold with applied provenance | keep | `domain/selection.ts` plus connector resolver | Config loader and selection tests | Preserve precedence. Simplify by making provenance a v2 first-class value. |
docs/architecture/v2-rigor-audit.md:18:| Schematic step validation | `src/schemas/flow-schematic.ts`, `src/runtime/compile-schematic-to-flow.ts` | Missing kind-specific fields, invalid reads/writes/checks | Compiler, flow packages | Flat optional authoring shape plus manual cross-field validation | simplify | Phase 5 authoring schemas, then adapter/compiler output validation | Flow schematic and compiler tests | Keep validation strength, reduce optional-field reasoning. |
docs/architecture/v2-rigor-audit.md:21:| Report schema validation | Flow package `reports.ts`, `src/runtime/registries/*`, connector materializer | Invalid report trusted downstream, bad relay result accepted | Relay executor, report readers, generated manifests | Flow-owned schemas and runtime parsing | keep | Flow-owned validators called by executors | Flow report schema tests and relay tests | Preserve flow package ownership. |
docs/architecture/v2-rigor-audit.md:22:| Checkpoint behavior | `src/runtime/step-handlers/checkpoint.ts`, checkpoint writers, Build writer | Bad pause/resume, wrong auto-resolution, invalid checkpoint report | Runner, CLI resume, status projection | Handler policy, checkpoint files, trace entries, flow-owned writers | simplify | `executors/checkpoint.ts`, `run/resume.ts`, flow-owned policy | Checkpoint handler, Build checkpoint tests | Preserve behavior but remove generic knowledge of Build-specific report shape. |
docs/architecture/v2-rigor-audit.md:23:| Fanout behavior | `src/runtime/step-handlers/fanout.ts`, `src/runtime/step-handlers/fanout/*` | Branch loss, partial failure mishandling, missing aggregate report, leaked worktree | Explore and Sweep flows, run status, report consumers | Large handler plus helper modules | simplify | `fanout/branch-expansion.ts`, `branch-execution.ts`, `worktree.ts`, `join-policy.ts`, `aggregate-report.ts`, `cleanup.ts` | Fanout runtime and property tests | Behavior is load-bearing; file shape needs decomposition. |
docs/architecture/v2-rigor-audit.md:24:| Sub-run behavior | `src/runtime/step-handlers/sub-run.ts` | Child run ambiguity, missing copied result, parent/child trace confusion | Migrate/Sweep flows, parent runner | Child run folder creation, child resolver, copied report/result | keep | `executors/sub-run.ts` plus `run/graph-runner.ts` child context | Sub-run runtime and recursion tests | Preserve identity and materialization rules. |
docs/architecture/v2-rigor-audit.md:31:| Run file path safety | `src/schemas/scalars.ts`, `src/runtime/run-relative-path.ts`, step schema | Path traversal, symlink escape, write collision | Runtime writers, connectors, reports | Run-relative path parser and containment checks | keep | `run-files/paths.ts` and `run-file-store.ts` | Scalar and runner path tests | Keep explicit paths in executable manifests. |
docs/architecture/v2-rigor-audit.md:32:| Progress/status projection | `src/runtime/reducer.ts`, `src/runtime/progress-projector.ts`, `src/runtime/run-status-projection.ts` | Independent truth stores disagree with trace | CLI progress, run status, operator summary | Reducer and projection modules read trace and files | simplify | `projections/status.ts`, `progress.ts`, `task-state.ts`, `user-input.ts` | Progress projector and status tests | Preserve trace-first rule. Split projection from runner wording. |
docs/architecture/v2-rigor-audit.md:33:| Manifest snapshot and hash | `src/runtime/manifest-snapshot-writer.ts`, runner bootstrap | Resume against different flow bytes, impossible run audit | Resume path, status readers, tests | Snapshot writer and bootstrap metadata | keep | `manifest/` plus `run/run-context.ts` | Runner and resume tests | v2 should snapshot the executable manifest actually run. |
docs/contracts/connector.md:126:    `src/runtime/connectors/codex.ts`; ADR-0009 §Consequences.Enabling is
docs/contracts/connector.md:175:  `src/runtime/connectors/custom.ts`.
tests/properties/visible/fanout-join-policy.test.ts:3:// `evaluateFanoutJoinPolicy` helper in src/runtime/step-handlers/fanout.ts.
tests/properties/visible/fanout-join-policy.test.ts:33:} from '../../../src/runtime/step-handlers/fanout.js';
src/runtime/relay-selection.ts:12:import type { RelayFn } from './runner-types.js';
src/runtime/relay-selection.ts:18:} from '../shared/relay-selection.js';
src/runtime/relay-selection.ts:23:  readonly explicitRelayer?: RelayFn;
src/runtime/relay-selection.ts:30:  readonly relayer: RelayFn;
src/runtime/relay-selection.ts:52:async function relayerForBuiltin(name: EnabledConnector): Promise<RelayFn> {
src/runtime/relay-selection.ts:83:async function relayerForCustom(descriptor: CustomConnectorDescriptor): Promise<RelayFn> {
src/runtime/relay-selection.ts:92:async function relayerForResolvedConnector(connector: ResolvedConnector): Promise<RelayFn> {
src/runtime/relay-selection.ts:127:async function decideRelayer(connector: ResolvedConnector, role: RelayRole): Promise<RelayFn> {
docs/architecture/v2-checkpoint-3.md:11:-> runCompiledFlowV2
docs/architecture/v2-checkpoint-3.md:156:- `runCompiledFlowV2` lives in source as an opt-in internal path. That is useful
docs/architecture/v2-checkpoint-3.md:189:- Changed `runCompiledFlowV2` to compute `manifest_hash` from raw
docs/architecture/v2-checkpoint-3.md:211:- `runCompiledFlowV2` now accepts raw compiled-flow bytes only, parses the
src/core-v2/run/graph-runner.ts:7:  ProgressReporter,
src/core-v2/run/graph-runner.ts:8:  RelayFn,
src/core-v2/run/graph-runner.ts:48:  readonly relayer?: RelayFn;
src/core-v2/run/graph-runner.ts:50:  readonly progress?: ProgressReporter;
docs/architecture/v2-checkpoint-1.md:136:- `src/runtime/runner.ts`
docs/architecture/v2-checkpoint-1.md:137:- `src/runtime/compile-schematic-to-flow.ts`
docs/architecture/v2-checkpoint-1.md:138:- `src/runtime/selection-resolver.ts`
docs/architecture/v2-checkpoint-1.md:139:- `src/runtime/relay-selection.ts`
docs/architecture/v2-checkpoint-1.md:140:- `src/runtime/catalog-derivations.ts`
docs/architecture/v2-checkpoint-1.md:141:- `src/runtime/reducer.ts`
docs/architecture/v2-checkpoint-1.md:142:- `src/runtime/progress-projector.ts`
docs/architecture/v2-checkpoint-1.md:143:- `src/runtime/run-status-projection.ts`
docs/architecture/v2-checkpoint-1.md:144:- `src/runtime/run-relative-path.ts`
docs/architecture/v2-checkpoint-1.md:145:- `src/runtime/manifest-snapshot-writer.ts`
docs/architecture/v2-checkpoint-1.md:146:- `src/runtime/router.ts`
docs/architecture/v2-checkpoint-1.md:147:- `src/runtime/connectors/codex.ts`
docs/architecture/v2-checkpoint-1.md:148:- `src/runtime/connectors/claude-code.ts`
docs/architecture/v2-checkpoint-1.md:149:- `src/runtime/connectors/custom.ts`
docs/architecture/v2-checkpoint-1.md:150:- `src/runtime/step-handlers/checkpoint.ts`
docs/architecture/v2-checkpoint-1.md:151:- `src/runtime/step-handlers/sub-run.ts`
docs/architecture/v2-checkpoint-1.md:152:- `src/runtime/step-handlers/fanout.ts`
docs/architecture/v2-checkpoint-1.md:153:- `src/runtime/step-handlers/fanout/aggregate.ts`
docs/architecture/v2-checkpoint-1.md:154:- `src/runtime/step-handlers/fanout/branch-resolution.ts`
docs/architecture/v2-checkpoint-1.md:155:- `src/runtime/step-handlers/fanout/join-policy.ts`
docs/architecture/v2-checkpoint-1.md:156:- `src/runtime/step-handlers/fanout/types.ts`
docs/architecture/v2-checkpoint-4.9.md:18:- `RelayFn`
docs/architecture/v2-checkpoint-4.9.md:20:- `ProgressReporter`
docs/architecture/v2-checkpoint-4.9.md:23:`src/runtime/runner-types.ts` remains as a compatibility re-export and still
docs/architecture/v2-checkpoint-4.9.md:28:core-v2 no longer imports `src/runtime/runner-types.ts` for relay/progress
docs/architecture/v2-checkpoint-4.9.md:38:`src/runtime/runner-types.ts` or `src/runtime/runner.ts`.
src/runtime/progress-projector.ts:17:import { resolveRunRelative } from './run-relative-path.js';
src/runtime/progress-projector.ts:18:import type { ProgressReporter } from './runner-types.js';
src/runtime/progress-projector.ts:83:  readonly progress: ProgressReporter | undefined;
src/runtime/progress-projector.ts:127:  readonly progress?: ProgressReporter;
src/runtime/progress-projector.ts:184:  readonly progress: ProgressReporter | undefined;
src/runtime/relay-support.ts:7:} from '../shared/relay-support.js';
src/runtime/run-status-projection.ts:16:import { resolveRunRelative } from './run-relative-path.js';
src/runtime/compile-schematic-to-flow.ts:71:        `schematic item '${item.id}' has verification kind but writes '${item.output}'; no verification writer is registered for that schema (see src/runtime/registries/verification-writers/registry.ts)`,
src/runtime/compile-schematic-to-flow.ts:78:        `schematic item '${item.id}' has checkpoint kind writing report '${item.output}'; no checkpoint writer is registered for that schema (see src/runtime/registries/checkpoint-writers/registry.ts)`,
src/runtime/selection-resolver.ts:4:} from '../shared/selection-resolver.js';
src/runtime/step-handlers/sub-run.ts:7:import { resolveRunRelative } from '../run-relative-path.js';
src/runtime/step-handlers/types.ts:11:  RelayFn,
src/runtime/step-handlers/types.ts:40:  readonly relayer?: RelayFn;
src/runtime/step-handlers/types.ts:52:  // `runCompiledFlow`. Tests injecting a stub childRunner can avoid the full
src/runtime/runner.ts:46:} from './relay-selection.js';
src/runtime/runner.ts:48:import { resolveRunRelative } from './run-relative-path.js';
src/runtime/runner.ts:57:  ProgressReporter,
src/runtime/runner.ts:58:  RelayFn,
src/runtime/runner.ts:75:} from './write-capable-worker-disclosure.js';
src/runtime/runner.ts:84:  RelayFn,
src/runtime/runner.ts:392:  readonly progress: ProgressReporter | undefined;
src/runtime/runner.ts:441:// under src/runtime/registries/compose-writers/ and is registered by
src/runtime/runner.ts:443:// src/runtime/registries/close-writers/. The runner stays flow-
src/runtime/runner.ts:520:  readonly relayer?: RelayFn;
src/runtime/runner.ts:532:  readonly progress?: ProgressReporter;
src/runtime/runner.ts:540:    throw new Error(`runCompiledFlow: flow ${flow.id} declares no entry_modes`);
src/runtime/runner.ts:545:      throw new Error(`runCompiledFlow: flow ${flow.id} entry_modes[0] unreadable`);
src/runtime/runner.ts:552:      `runCompiledFlow: flow ${flow.id} declares no entry_mode named '${entryModeName}'`,
src/runtime/runner.ts:741:// src/runtime/step-handlers/.
src/runtime/runner.ts:868:        `runCompiledFlow: route target '${currentStepId}' is not a known step id (fixture/reduction mismatch)`,
src/runtime/runner.ts:941:        childRunner: ctx.childRunner ?? runCompiledFlow,
src/runtime/runner.ts:1046:        `runCompiledFlow: step '${step.id}' selected route '${routeTaken}' but the compiled step has no target for that route`,
src/runtime/runner.ts:1055:          `runCompiledFlow: route target '${nextRoute}' is not a known step id (fixture/reduction mismatch)`,
src/runtime/runner.ts:1215:export async function runCompiledFlow(inv: CompiledFlowInvocation): Promise<CompiledFlowRunResult> {
src/runtime/runner.ts:1219:export async function resumeCompiledFlowCheckpoint(
src/runtime/run-relative-path.ts:1:export { resolveRunRelative } from '../shared/run-relative-path.js';
src/runtime/runner-types.ts:11:  ProgressReporter,
src/runtime/runner-types.ts:12:  RelayFn,
src/runtime/runner-types.ts:16:  ProgressReporter,
src/runtime/runner-types.ts:17:  RelayFn,
src/runtime/runner-types.ts:94:  relayer?: RelayFn;
src/runtime/runner-types.ts:107:  // own `runCompiledFlow`. Tests inject deterministic child-run stubs so they
src/runtime/runner-types.ts:118:  progress?: ProgressReporter;
src/runtime/runner-types.ts:126:  relayer?: RelayFn;
src/runtime/runner-types.ts:132:  progress?: ProgressReporter;
src/runtime/step-handlers/checkpoint.ts:11:import { resolveRunRelative } from '../run-relative-path.js';
src/runtime/step-handlers/checkpoint.ts:109:// means adding a builder under src/runtime/registries/checkpoint-writers/.
src/flows/review/writers/result.ts:16:import { resolveRunRelative } from '../../../shared/run-relative-path.js';
tests/parity/core-v2-parity-helpers.ts:13:import { runCompiledFlowV2 } from '../../src/core-v2/run/compiled-flow-runner.js';
tests/parity/core-v2-parity-helpers.ts:166:  return await runCompiledFlowV2({
src/runtime/operator-summary-writer.ts:8:import { resolveRunRelative } from './run-relative-path.js';
src/runtime/operator-summary-writer.ts:13:} from './write-capable-worker-disclosure.js';
src/runtime/step-handlers/shared.ts:3:import { resolveRunRelative } from '../run-relative-path.js';
src/runtime/registries/compose-writers/types.ts:17:// src/runtime/registries/close-writers/. The two registries are intentionally
src/core-v2/executors/relay.ts:13:import { deriveResolvedSelection } from '../../shared/relay-selection.js';
src/core-v2/executors/relay.ts:14:import { composeRelayPrompt, evaluateRelayCheck } from '../../shared/relay-support.js';
src/schemas/result.ts:15:// src/runtime/result-writer.ts); this schema only enforces shape.
src/core-v2/projections/progress.ts:10:import type { ProgressReporter } from '../../shared/relay-runtime-types.js';
src/core-v2/projections/progress.ts:15:} from '../../shared/write-capable-worker-disclosure.js';
src/core-v2/projections/progress.ts:75:  readonly progress: ProgressReporter | undefined;
src/core-v2/projections/progress.ts:165:  readonly progress: ProgressReporter | undefined;
src/runtime/write-capable-worker-disclosure.ts:5:} from '../shared/write-capable-worker-disclosure.js';
src/runtime/step-handlers/fanout/branch-resolution.ts:3:import { resolveRunRelative } from '../../run-relative-path.js';
src/flows/migrate/writers/verification.ts:19:import { resolveRunRelative } from '../../../shared/run-relative-path.js';
src/flows/explore/command.md:111:- `src/runtime/` (current runner)
tests/runner/fix-report-writer.test.ts:22:import { writeComposeReport } from '../../src/runtime/runner.js';
src/flows/types.ts:112:  // When true, the relay-selection layer threads the run's effective
src/runtime/connectors/relay-materializer.ts:8:import { resolveRunRelative } from '../run-relative-path.js';
src/runtime/connectors/relay-materializer.ts:28:// Why live in `src/runtime/connectors/` and not `src/runtime/` proper.
src/runtime/connectors/relay-materializer.ts:31:// scope is `src/runtime/connectors/**`, and this module's only external
src/runtime/connectors/relay-materializer.ts:55:  // derives them in `runCompiledFlow`: connector provenance is
src/runtime/connectors/relay-materializer.ts:93:// `src/runtime/runner.ts::evaluateRelayCheck` + the `parseReport`
src/runtime/connectors/relay-materializer.ts:97:// registry at `src/runtime/registries/report-schemas.ts`; unknown schema names
src/runtime/connectors/shared.ts:15:// This module stays under `src/runtime/connectors/**` so Check 29's
tests/contracts/flow-router.test.ts:3:import { ROUTABLE_WORKFLOWS, classifyCompiledFlowTask } from '../../src/runtime/router.js';
src/flows/explore/contract.md:369:`src/runtime/registries/report-schemas.ts`. The canonical report at
src/flows/explore/contract.md:387:`src/runtime/registries/report-schemas.ts` carries the strict
src/flows/explore/contract.md:394:`src/runtime/runner.ts` name the exact JSON shapes the connectors must
tests/runner/fanout-handler-direct.test.ts:4:// the handler transitively through full runCompiledFlow runs. Neither
tests/runner/fanout-handler-direct.test.ts:18:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/fanout-handler-direct.test.ts:25:} from '../../src/runtime/runner.js';
tests/runner/fanout-handler-direct.test.ts:26:import { runFanoutStep } from '../../src/runtime/step-handlers/fanout.js';
tests/runner/fanout-handler-direct.test.ts:27:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/fix-runtime-wiring.test.ts:4:// CompiledFlow) and runs it through `runCompiledFlow` with stubbed relayers
tests/runner/fix-runtime-wiring.test.ts:17:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/fix-runtime-wiring.test.ts:18:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/fix-runtime-wiring.test.ts:21:  type RelayFn,
tests/runner/fix-runtime-wiring.test.ts:22:  runCompiledFlow,
tests/runner/fix-runtime-wiring.test.ts:24:} from '../../src/runtime/runner.js';
tests/runner/fix-runtime-wiring.test.ts:47:      'runCompiledFlow closes the lite Fix flow via real CompiledFlow with stubbed relayers and a fast verification command',
tests/runner/fix-runtime-wiring.test.ts:98:function relayer(): RelayFn {
tests/runner/fix-runtime-wiring.test.ts:159:    const outcome = await runCompiledFlow({
src/runtime/step-handlers/fanout.ts:9:import type { RelayStep } from '../relay-support.js';
src/runtime/step-handlers/fanout.ts:11:import { resolveRunRelative } from '../run-relative-path.js';
src/runtime/step-handlers/relay.ts:9:import { deriveResolvedSelection, resolveRelayDecision } from '../relay-selection.js';
src/runtime/step-handlers/relay.ts:16:} from '../relay-support.js';
src/runtime/step-handlers/relay.ts:17:import { resolveRunRelative } from '../run-relative-path.js';
tests/contracts/codex-host-plugin.test.ts:17:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/contracts/codex-host-plugin.test.ts:18:import type { RelayInput } from '../../src/runtime/runner.js';
tests/contracts/compile-schematic-to-flow.test.ts:7:} from '../../src/runtime/compile-schematic-to-flow.js';
tests/runner/terminal-outcome-mapping.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/terminal-outcome-mapping.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/terminal-outcome-mapping.test.ts:9:  type RelayFn,
tests/runner/terminal-outcome-mapping.test.ts:10:  runCompiledFlow,
tests/runner/terminal-outcome-mapping.test.ts:12:} from '../../src/runtime/runner.js';
tests/runner/terminal-outcome-mapping.test.ts:13:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/terminal-outcome-mapping.test.ts:377:function unusedRelayer(): RelayFn {
tests/runner/terminal-outcome-mapping.test.ts:405:      const outcome = await runCompiledFlow({
tests/runner/terminal-outcome-mapping.test.ts:489:      const outcome = await runCompiledFlow({
tests/runner/terminal-outcome-mapping.test.ts:522:    const outcome = await runCompiledFlow({
tests/runner/terminal-outcome-mapping.test.ts:548:    const outcome = await runCompiledFlow({
tests/runner/checkpoint-handler-direct.test.ts:16:import { runCheckpointStep } from '../../src/runtime/step-handlers/checkpoint.js';
tests/runner/checkpoint-handler-direct.test.ts:17:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/checkpoint-handler-direct.test.ts:18:import { traceEntryLogPath } from '../../src/runtime/trace-writer.js';
tests/runner/runtime-smoke.test.ts:14:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/runtime-smoke.test.ts:15:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/runtime-smoke.test.ts:16:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/runtime-smoke.test.ts:17:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/runtime-smoke.test.ts:23:// composes the runtime boundary via `runCompiledFlow`.
tests/runner/runtime-smoke.test.ts:49:// The stub uses the structured `RelayFn` descriptor shape and binds
tests/runner/runtime-smoke.test.ts:55:function stubRelayer(): RelayFn {
tests/runner/runtime-smoke.test.ts:93:    const outcome = await runCompiledFlow({
tests/runner/runtime-smoke.test.ts:153:    const outcome = await runCompiledFlow({
tests/runner/runtime-smoke.test.ts:209:    const runA = await runCompiledFlow({
tests/runner/runtime-smoke.test.ts:220:    const runB = await runCompiledFlow({
tests/runner/runtime-smoke.test.ts:249:      // load, schema parse, runCompiledFlow composition, JSON
tests/contracts/codex-connector-schema.test.ts:15:} from '../../src/runtime/connectors/codex.js';
tests/contracts/codex-connector-schema.test.ts:22://   (A) `src/runtime/connectors/codex.ts` module shape + capability-
tests/contracts/codex-connector-schema.test.ts:40:describe('Codex connector — src/runtime/connectors/codex.ts module shape', () => {
src/cli/circuit.ts:6:import { runCompiledFlowV2 } from '../core-v2/run/compiled-flow-runner.js';
src/cli/circuit.ts:26:  type RelayFn,
src/cli/circuit.ts:27:  resumeCompiledFlowCheckpoint,
src/cli/circuit.ts:28:  runCompiledFlow,
src/cli/circuit.ts:29:} from '../runtime/runner.js';
src/cli/circuit.ts:112:  relayer?: RelayFn;
src/cli/circuit.ts:400:  // Validator: src/runtime/policy/flow-kind-policy.ts.
src/cli/circuit.ts:640:    const outcome = await resumeCompiledFlowCheckpoint({
src/cli/circuit.ts:800:    const v2Result = await runCompiledFlowV2({
src/cli/circuit.ts:864:  const outcome = await runCompiledFlow(invocation);
tests/runner/fanout-runtime.test.ts:6:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/fanout-runtime.test.ts:12:  type RelayFn,
tests/runner/fanout-runtime.test.ts:14:  runCompiledFlow,
tests/runner/fanout-runtime.test.ts:15:} from '../../src/runtime/runner.js';
tests/runner/fanout-runtime.test.ts:53:function unusedRelayer(): RelayFn {
tests/runner/fanout-runtime.test.ts:390:  readonly relayer: RelayFn;
tests/runner/fanout-runtime.test.ts:394:  const outcome = await runCompiledFlow({
tests/runner/fanout-runtime.test.ts:409:function relayReturning(resultBody: string): RelayFn {
tests/runner/fanout-runtime.test.ts:423:  readonly outcome: Awaited<ReturnType<typeof runCompiledFlow>>;
tests/runner/fanout-runtime.test.ts:506:    const outcome = await runCompiledFlow({
tests/runner/fanout-runtime.test.ts:574:    const outcome = await runCompiledFlow({
tests/runner/fanout-runtime.test.ts:670:    const relayer: RelayFn = {
tests/runner/fanout-runtime.test.ts:687:    const outcome = await runCompiledFlow({
tests/runner/fanout-runtime.test.ts:904:    const outcome = await runCompiledFlow({
tests/runner/fanout-runtime.test.ts:1036:    const outcome = await runCompiledFlow({
tests/runner/fanout-runtime.test.ts:1088:    const outcome = await runCompiledFlow({
tests/runner/fanout-runtime.test.ts:1157:    const outcome = await runCompiledFlow({
tests/runner/check-evaluation.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/check-evaluation.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/check-evaluation.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/check-evaluation.test.ts:24:// Tests below exercise the four cases through `runCompiledFlow` end-to-end
tests/runner/check-evaluation.test.ts:26:// integration against the runCompiledFlow loop's flow control is part of
tests/runner/check-evaluation.test.ts:42:function relayerWith(resultBody: string): RelayFn {
tests/runner/check-evaluation.test.ts:81:    const outcome = await runCompiledFlow({
tests/runner/check-evaluation.test.ts:119:    const outcome = await runCompiledFlow({
tests/runner/check-evaluation.test.ts:185:    const outcome = await runCompiledFlow({
tests/runner/check-evaluation.test.ts:246:    const outcome = await runCompiledFlow({
tests/runner/check-evaluation.test.ts:279:    const outcome = await runCompiledFlow({
tests/runner/check-evaluation.test.ts:366:      const outcome = await runCompiledFlow({
tests/runner/check-evaluation.test.ts:411:    const outcome = await runCompiledFlow({
tests/runner/check-evaluation.test.ts:448:    const outcome = await runCompiledFlow({
tests/contracts/build-report-schemas.test.ts:342:            file_refs: ['src/runtime/runner.ts'],
src/flows/explore/writers/close.ts:15:import { resolveRunRelative } from '../../../shared/run-relative-path.js';
tests/runner/migrate-runtime-wiring.test.ts:15:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/migrate-runtime-wiring.test.ts:16:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/migrate-runtime-wiring.test.ts:17:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/migrate-runtime-wiring.test.ts:23:  type RelayFn,
tests/runner/migrate-runtime-wiring.test.ts:24:  runCompiledFlow,
tests/runner/migrate-runtime-wiring.test.ts:25:} from '../../src/runtime/runner.js';
tests/runner/migrate-runtime-wiring.test.ts:106:): RelayFn {
tests/runner/migrate-runtime-wiring.test.ts:278:    const outcome = await runCompiledFlow({
tests/runner/migrate-runtime-wiring.test.ts:367:    const outcome = await runCompiledFlow({
tests/runner/migrate-runtime-wiring.test.ts:394:    const outcome = await runCompiledFlow({
tests/runner/close-builder-registry.test.ts:7:// runCompiledFlow, and asserts the new builder fires. If the runner ever
tests/runner/close-builder-registry.test.ts:21:import { findCloseBuilder } from '../../src/runtime/registries/close-writers/registry.js';
tests/runner/close-builder-registry.test.ts:22:import type { CloseBuilder } from '../../src/runtime/registries/close-writers/types.js';
tests/runner/close-builder-registry.test.ts:23:import { runCompiledFlow, writePrototypeComposeReport } from '../../src/runtime/runner.js';
tests/runner/close-builder-registry.test.ts:167:    const outcome = await runCompiledFlow({
tests/runner/pass-route-cycle-guard.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/pass-route-cycle-guard.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/pass-route-cycle-guard.test.ts:8:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/pass-route-cycle-guard.test.ts:9:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/pass-route-cycle-guard.test.ts:41:function unusedRelayer(): RelayFn {
tests/runner/pass-route-cycle-guard.test.ts:74:    const outcome = await runCompiledFlow({
tests/runner/explore-report-writer.test.ts:13:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-report-writer.test.ts:14:import { type RelayFn, type RelayInput, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/explore-report-writer.test.ts:42:      'default runCompiledFlow explore path writes explore.brief@v1 and explore.analysis@v1 reports that parse through their schemas',
tests/runner/explore-report-writer.test.ts:48:function stubRelayer(): RelayFn {
tests/runner/explore-report-writer.test.ts:115:function incompleteReviewRelayer(): RelayFn {
tests/runner/explore-report-writer.test.ts:151:function extraKeyReviewRelayer(): RelayFn {
tests/runner/explore-report-writer.test.ts:193:function extraKeyComposeRelayer(): RelayFn {
tests/runner/explore-report-writer.test.ts:219:function incompleteComposeRelayer(): RelayFn {
tests/runner/explore-report-writer.test.ts:248:    const outcome = await runCompiledFlow({
tests/runner/explore-report-writer.test.ts:315:    const outcome = await runCompiledFlow({
tests/runner/explore-report-writer.test.ts:340:    const outcome = await runCompiledFlow({
tests/runner/explore-report-writer.test.ts:371:    const outcome = await runCompiledFlow({
tests/runner/explore-report-writer.test.ts:399:    const outcome = await runCompiledFlow({
tests/runner/explore-report-writer.test.ts:427:    const outcome = await runCompiledFlow({
tests/runner/explore-report-writer.test.ts:459:    const outcome = await runCompiledFlow({
tests/runner/explore-report-writer.test.ts:491:    const outcome = await runCompiledFlow({
tests/runner/explore-report-writer.test.ts:523:    const outcome = await runCompiledFlow({
tests/contracts/relay-transcript-schema.test.ts:11:import { reduce } from '../../src/runtime/reducer.js';
tests/runner/codex-relay-roundtrip.test.ts:8:import { type CodexRelayResult, relayCodex } from '../../src/runtime/connectors/codex.js';
tests/runner/codex-relay-roundtrip.test.ts:9:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/codex-relay-roundtrip.test.ts:10:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/codex-relay-roundtrip.test.ts:11:import { reduce } from '../../src/runtime/reducer.js';
tests/runner/codex-relay-roundtrip.test.ts:12:import { appendAndDerive, bootstrapRun } from '../../src/runtime/runner.js';
tests/runner/codex-relay-roundtrip.test.ts:13:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/codex-relay-roundtrip.test.ts:60://   (a) src/runtime/connectors/codex.ts — relayCodex + parseCodexStdout
tests/runner/codex-relay-roundtrip.test.ts:62://   (b) src/runtime/connectors/shared.ts — sha256Hex + RelayResult
tests/runner/codex-relay-roundtrip.test.ts:64://   (c) src/runtime/connectors/relay-materializer.ts — five-trace_entry
tests/runner/codex-relay-roundtrip.test.ts:77:  resolve('src/runtime/connectors/codex.ts'),
tests/runner/codex-relay-roundtrip.test.ts:78:  resolve('src/runtime/connectors/shared.ts'),
tests/runner/codex-relay-roundtrip.test.ts:79:  resolve('src/runtime/connectors/relay-materializer.ts'),
tests/runner/codex-relay-roundtrip.test.ts:80:  resolve('src/runtime/runner.ts'),
tests/runner/codex-relay-roundtrip.test.ts:81:  resolve('src/runtime/registries/report-schemas.ts'),
tests/runner/custom-connector-runtime.test.ts:3:import { relayCustom } from '../../src/runtime/connectors/custom.js';
tests/runner/runner-relay-connector-identity.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/runner-relay-connector-identity.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/runner-relay-connector-identity.test.ts:8:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/runner-relay-connector-identity.test.ts:13:// Connector-identity plumbing through `runCompiledFlow`. `RelayFn` is a
tests/runner/runner-relay-connector-identity.test.ts:21:// carries connector identity end-to-end through `runCompiledFlow`.
tests/runner/runner-relay-connector-identity.test.ts:26:// This test exercises the `runCompiledFlow` seam on top of that — the
tests/runner/runner-relay-connector-identity.test.ts:28:// calls `materializeRelay` directly and bypasses `runCompiledFlow`.
tests/runner/runner-relay-connector-identity.test.ts:43:function codexShapedStub(): RelayFn {
tests/runner/runner-relay-connector-identity.test.ts:77:describe('RelayFn descriptor carries connector identity into relay.started', () => {
tests/runner/runner-relay-connector-identity.test.ts:81:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:28:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/review-runtime-wiring.test.ts:29:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/review-runtime-wiring.test.ts:30:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/review-runtime-wiring.test.ts:82:function relayerWith(result: ReviewRelayResult): RelayFn {
tests/runner/review-runtime-wiring.test.ts:86:function relayerWithBody(body: string): RelayFn {
tests/runner/review-runtime-wiring.test.ts:159:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:202:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:242:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:294:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:363:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:421:      const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:469:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:512:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:564:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:594:    const outcome = await runCompiledFlow({
tests/runner/review-runtime-wiring.test.ts:647:      const outcome = await runCompiledFlow({
tests/contracts/engine-flow-boundary.test.ts:1:// Architecture boundary: src/runtime/ may not import from any
tests/contracts/engine-flow-boundary.test.ts:14:const RUNTIME_ROOT = 'src/runtime';
tests/contracts/engine-flow-boundary.test.ts:69:  it('no file under src/runtime/ imports a flow source other than the catalog or types', () => {
tests/contracts/engine-flow-boundary.test.ts:76:      'src/runtime walk returned unexpectedly few files — discovery loop is likely broken',
tests/contracts/flow-kind-policy.test.ts:12:} from '../../src/runtime/policy/flow-kind-policy.js';
tests/contracts/flow-model-effort.test.ts:6:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/contracts/flow-model-effort.test.ts:7:import { type RelayFn, type RelayInput, runCompiledFlow } from '../../src/runtime/runner.js';
tests/contracts/flow-model-effort.test.ts:14:import { resolveSelectionForRelay } from '../../src/shared/selection-resolver.js';
tests/contracts/flow-model-effort.test.ts:265:    const relayer: RelayFn = {
tests/contracts/flow-model-effort.test.ts:279:    const outcome = await runCompiledFlow({
tests/runner/relay-shape-hint-registry.test.ts:20:} from '../../src/runtime/registries/shape-hints/registry.js';
tests/runner/relay-shape-hint-registry.test.ts:21:import type { RelayStep } from '../../src/runtime/registries/shape-hints/types.js';
tests/runner/runner-relay-provenance.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/runner-relay-provenance.test.ts:7:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/runner-relay-provenance.test.ts:8:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/runner-relay-provenance.test.ts:9:import { resolveRelayDecision } from '../../src/runtime/relay-selection.js';
tests/runner/runner-relay-provenance.test.ts:10:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/runner-relay-provenance.test.ts:16:// Relay-trace_entry provenance plumbing through `runCompiledFlow`.
tests/runner/runner-relay-provenance.test.ts:61:function stubRelayer(): RelayFn {
tests/runner/runner-relay-provenance.test.ts:100:    const outcome = await runCompiledFlow({
tests/runner/runner-relay-provenance.test.ts:346:    const outcome = await runCompiledFlow({
tests/runner/runner-relay-provenance.test.ts:382:    const outcome = await runCompiledFlow({
tests/runner/runner-relay-provenance.test.ts:429:    const outcome = await runCompiledFlow({
tests/runner/runner-relay-provenance.test.ts:474:    const outcome = await runCompiledFlow({
tests/runner/runner-relay-provenance.test.ts:503:    const outcome = await runCompiledFlow({
tests/runner/runner-relay-provenance.test.ts:534:    const outcome = await runCompiledFlow({
tests/runner/runner-relay-provenance.test.ts:563:    const outcome = await runCompiledFlow({
tests/runner/runner-relay-provenance.test.ts:590:    const outcome = await runCompiledFlow({
tests/runner/compose-builder-registry.test.ts:5:// fresh schema's report end-to-end via runCompiledFlow — no runner.ts
tests/runner/compose-builder-registry.test.ts:15:import { findComposeBuilder } from '../../src/runtime/registries/compose-writers/registry.js';
tests/runner/compose-builder-registry.test.ts:16:import type { ComposeBuilder } from '../../src/runtime/registries/compose-writers/types.js';
tests/runner/compose-builder-registry.test.ts:17:import { runCompiledFlow, writeComposeReport } from '../../src/runtime/runner.js';
tests/runner/compose-builder-registry.test.ts:124:    const outcome = await runCompiledFlow({
tests/runner/compose-builder-registry.test.ts:148:    const outcome = await runCompiledFlow({
src/flows/explore/writers/decision.ts:12:import { resolveRunRelative } from '../../../shared/run-relative-path.js';
tests/runner/run-relative-path.test.ts:14:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/run-relative-path.test.ts:15:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/run-relative-path.test.ts:16:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/run-relative-path.test.ts:17:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/run-relative-path.test.ts:21:import { resolveRunRelative } from '../../src/shared/run-relative-path.js';
tests/runner/run-relative-path.test.ts:46:function relayerWithCapture(capture: string[]): RelayFn {
tests/runner/run-relative-path.test.ts:104:        runCompiledFlow({
tests/runner/run-relative-path.test.ts:133:      runCompiledFlow({
tests/runner/run-relative-path.test.ts:213:      runCompiledFlow({
tests/runner/run-relative-path.test.ts:240:      runCompiledFlow({
tests/runner/explore-tournament-runtime.test.ts:6:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-tournament-runtime.test.ts:8:  type RelayFn,
tests/runner/explore-tournament-runtime.test.ts:10:  resumeCompiledFlowCheckpoint,
tests/runner/explore-tournament-runtime.test.ts:11:  runCompiledFlow,
tests/runner/explore-tournament-runtime.test.ts:12:} from '../../src/runtime/runner.js';
tests/runner/explore-tournament-runtime.test.ts:44:function tournamentRelayer(): RelayFn {
tests/runner/explore-tournament-runtime.test.ts:172:    const waiting = await runCompiledFlow({
tests/runner/explore-tournament-runtime.test.ts:226:    const resumed = await resumeCompiledFlowCheckpoint({
tests/runner/explore-tournament-runtime.test.ts:261:    const outcome = await runCompiledFlow({
tests/contracts/orphan-blocks.test.ts:24:} from '../../src/runtime/compile-schematic-to-flow.js';
tests/contracts/orphan-blocks.test.ts:25:import { runCompiledFlow, writePrototypeComposeReport } from '../../src/runtime/runner.js';
tests/contracts/orphan-blocks.test.ts:187:    const outcome = await runCompiledFlow({
tests/contracts/orphan-blocks.test.ts:301:    const outcome = await runCompiledFlow({
tests/contracts/orphan-blocks.test.ts:381:    const outcome = await runCompiledFlow({
tests/contracts/orphan-blocks.test.ts:466:    const outcome = await runCompiledFlow({
tests/contracts/orphan-blocks.test.ts:556:    const outcome = await runCompiledFlow({
tests/runner/router-routing-invariants.test.ts:15:import { classifyTaskAgainstRoutables, deriveRoutingForTesting } from '../../src/runtime/router.js';
tests/runner/sub-run-handler-direct.test.ts:20:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/sub-run-handler-direct.test.ts:26:} from '../../src/runtime/runner.js';
tests/runner/sub-run-handler-direct.test.ts:27:import { runSubRunStep } from '../../src/runtime/step-handlers/sub-run.js';
tests/runner/sub-run-handler-direct.test.ts:28:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/unit/compile-schematic-per-mode.test.ts:10:import { compileSchematicToCompiledFlow } from '../../src/runtime/compile-schematic-to-flow.js';
tests/runner/materializer-schema-parse.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/materializer-schema-parse.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/materializer-schema-parse.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/materializer-schema-parse.test.ts:37:// add `writes.report`. Cases exercise through the full `runCompiledFlow`
tests/runner/materializer-schema-parse.test.ts:68:function relayerWith(resultBody: string): RelayFn {
tests/runner/materializer-schema-parse.test.ts:125:    const outcome = await runCompiledFlow({
tests/runner/materializer-schema-parse.test.ts:167:    const outcome = await runCompiledFlow({
tests/runner/materializer-schema-parse.test.ts:244:    const outcome = await runCompiledFlow({
tests/runner/materializer-schema-parse.test.ts:329:    const outcome = await runCompiledFlow({
tests/runner/materializer-schema-parse.test.ts:381:    const outcome = await runCompiledFlow({
tests/runner/handler-throw-recovery.test.ts:11:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/handler-throw-recovery.test.ts:12:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/handler-throw-recovery.test.ts:13:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/handler-throw-recovery.test.ts:14:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/handler-throw-recovery.test.ts:38:function stubRelayer(): RelayFn {
tests/runner/handler-throw-recovery.test.ts:57:      'runCompiledFlow resolves with outcome=aborted, step.aborted + run.closed trace_entries, and a parseable result.json',
tests/runner/handler-throw-recovery.test.ts:88:    const outcome = await runCompiledFlow({
tests/runner/handler-throw-recovery.test.ts:163:    const outcome = await runCompiledFlow({
tests/runner/handler-throw-recovery.test.ts:179:    // raw throw out of runCompiledFlow. The compose handler has its OWN
tests/contracts/explore-report-composition.test.ts:5:import { findCloseBuilder } from '../../src/runtime/registries/close-writers/registry.js';
tests/contracts/explore-report-composition.test.ts:6:import { findComposeBuilder } from '../../src/runtime/registries/compose-writers/registry.js';
tests/contracts/explore-report-composition.test.ts:7:import { parseReport } from '../../src/runtime/registries/report-schemas.js';
tests/runner/agent-connector-smoke.test.ts:4:import { relayClaudeCode, sha256Hex } from '../../src/runtime/connectors/claude-code.js';
tests/runner/operator-summary-writer.test.ts:6:import { writeOperatorSummary } from '../../src/runtime/operator-summary-writer.js';
tests/runner/build-runtime-wiring.test.ts:12:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/build-runtime-wiring.test.ts:13:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/build-runtime-wiring.test.ts:14:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/build-runtime-wiring.test.ts:50:): RelayFn {
tests/runner/build-runtime-wiring.test.ts:124:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:169:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:199:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:234:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:264:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:337:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:376:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:402:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:434:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:473:    const outcome = await runCompiledFlow({
tests/runner/build-runtime-wiring.test.ts:505:      runCompiledFlow({
tests/runner/push-sequence-authority.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/push-sequence-authority.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/push-sequence-authority.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/push-sequence-authority.test.ts:13:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/push-sequence-authority.test.ts:39:function stubRelayer(): RelayFn {
tests/runner/push-sequence-authority.test.ts:76:    const outcome = await runCompiledFlow({
tests/runner/sub-run-runtime.test.ts:6:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/sub-run-runtime.test.ts:12:  type RelayFn,
tests/runner/sub-run-runtime.test.ts:13:  runCompiledFlow,
tests/runner/sub-run-runtime.test.ts:14:} from '../../src/runtime/runner.js';
tests/runner/sub-run-runtime.test.ts:51:function unusedRelayer(): RelayFn {
tests/runner/sub-run-runtime.test.ts:250:    const outcome = await runCompiledFlow({
tests/runner/sub-run-runtime.test.ts:326:    const outcome = await runCompiledFlow({
tests/runner/sub-run-runtime.test.ts:364:    const outcome = await runCompiledFlow({
tests/runner/extract-json-object.test.ts:3:import { extractJsonObject } from '../../src/runtime/connectors/shared.js';
tests/runner/cross-report-validators.test.ts:6:import { reportPathForSchemaInCompiledFlow } from '../../src/runtime/registries/close-writers/shared.js';
tests/runner/cross-report-validators.test.ts:7:import { runCrossReportValidator } from '../../src/runtime/registries/cross-report-validators.js';
tests/runner/relay-handler-direct.test.ts:4:// runCompiledFlow runs, but the handler's own surface — check
tests/runner/relay-handler-direct.test.ts:16:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/relay-handler-direct.test.ts:17:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/relay-handler-direct.test.ts:18:import { runRelayStep } from '../../src/runtime/step-handlers/relay.js';
tests/runner/relay-handler-direct.test.ts:19:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/build-checkpoint-exec.test.ts:8:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/build-checkpoint-exec.test.ts:9:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/build-checkpoint-exec.test.ts:11:  type RelayFn,
tests/runner/build-checkpoint-exec.test.ts:13:  resumeCompiledFlowCheckpoint,
tests/runner/build-checkpoint-exec.test.ts:14:  runCompiledFlow,
tests/runner/build-checkpoint-exec.test.ts:15:} from '../../src/runtime/runner.js';
tests/runner/build-checkpoint-exec.test.ts:332:    const outcome = await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:366:    const outcome = await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:406:    await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:418:    const resumed = await resumeCompiledFlowCheckpoint({
tests/runner/build-checkpoint-exec.test.ts:461:    await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:474:      resumeCompiledFlowCheckpoint({
tests/runner/build-checkpoint-exec.test.ts:488:    await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:502:      resumeCompiledFlowCheckpoint({
tests/runner/build-checkpoint-exec.test.ts:516:    await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:555:      resumeCompiledFlowCheckpoint({
tests/runner/build-checkpoint-exec.test.ts:569:    await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:625:      resumeCompiledFlowCheckpoint({
tests/runner/build-checkpoint-exec.test.ts:639:    const relayer: RelayFn = {
tests/runner/build-checkpoint-exec.test.ts:653:    await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:684:    const resumed = await resumeCompiledFlowCheckpoint({
tests/runner/build-checkpoint-exec.test.ts:724:    const relayer: RelayFn = {
tests/runner/build-checkpoint-exec.test.ts:738:    await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:750:    const resumed = await resumeCompiledFlowCheckpoint({
tests/runner/build-checkpoint-exec.test.ts:793:    await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:805:    const resumed = await resumeCompiledFlowCheckpoint({
tests/runner/build-checkpoint-exec.test.ts:826:    await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:837:    const resumed = await resumeCompiledFlowCheckpoint({
tests/runner/build-checkpoint-exec.test.ts:855:    const outcome = await runCompiledFlow({
tests/runner/build-checkpoint-exec.test.ts:882:    const outcome = await runCompiledFlow({
tests/runner/sweep-runtime-wiring.test.ts:15:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/sweep-runtime-wiring.test.ts:16:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/sweep-runtime-wiring.test.ts:17:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/sweep-runtime-wiring.test.ts:101:): RelayFn {
tests/runner/sweep-runtime-wiring.test.ts:188:    const outcome = await runCompiledFlow({
tests/runner/sweep-runtime-wiring.test.ts:299:    const outcome = await runCompiledFlow({
tests/runner/sweep-runtime-wiring.test.ts:333:    const outcome = await runCompiledFlow({
tests/runner/sweep-runtime-wiring.test.ts:361:    const outcome = await runCompiledFlow({
tests/runner/fanout-real-recursion.test.ts:12:// on the CompiledFlowInvocation, the runner defaults to `runCompiledFlow`
tests/runner/fanout-real-recursion.test.ts:13:// itself (per src/runtime/runner.ts:633), so each branch recurses
tests/runner/fanout-real-recursion.test.ts:24:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/fanout-real-recursion.test.ts:25:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/fanout-real-recursion.test.ts:28:  type RelayFn,
tests/runner/fanout-real-recursion.test.ts:30:  runCompiledFlow,
tests/runner/fanout-real-recursion.test.ts:31:} from '../../src/runtime/runner.js';
tests/runner/fanout-real-recursion.test.ts:45:      'each branch recurses through real runCompiledFlow with a fresh RunId and a sibling run-folder, each child emits its own trace, parent admits via aggregate-only join',
tests/runner/fanout-real-recursion.test.ts:47:      'integration test of fanout + real recursive runCompiledFlow rather than handler-isolation unit test',
tests/runner/fanout-real-recursion.test.ts:57:function acceptingRelayer(): RelayFn {
tests/runner/fanout-real-recursion.test.ts:141:      'real-recursion fanout test parent — two branches, each recurses into the child via real runCompiledFlow.',
tests/runner/fanout-real-recursion.test.ts:221:  it('runs each branch via real runCompiledFlow (no childRunner stub) and admits via aggregate-only', async () => {
tests/runner/fanout-real-recursion.test.ts:235:    // KEY: NO `childRunner` field — runner defaults to `runCompiledFlow`
tests/runner/fanout-real-recursion.test.ts:237:    const outcome = await runCompiledFlow({
tests/unit/runtime/progress-projector.test.ts:6:import { projectTraceEntryToProgress } from '../../../src/runtime/progress-projector.js';
tests/unit/runtime/event-log-round-trip.test.ts:15:} from '../../../src/runtime/manifest-snapshot-writer.js';
tests/unit/runtime/event-log-round-trip.test.ts:16:import { reduce } from '../../../src/runtime/reducer.js';
tests/unit/runtime/event-log-round-trip.test.ts:17:import { appendAndDerive, bootstrapRun, initRunFolder } from '../../../src/runtime/runner.js';
tests/unit/runtime/event-log-round-trip.test.ts:22:} from '../../../src/runtime/snapshot-writer.js';
tests/unit/runtime/event-log-round-trip.test.ts:23:import { readRunTrace } from '../../../src/runtime/trace-reader.js';
tests/unit/runtime/event-log-round-trip.test.ts:24:import { appendTraceEntry, traceEntryLogPath } from '../../../src/runtime/trace-writer.js';
tests/runner/codex-connector-smoke.test.ts:3:import { relayCodex } from '../../src/runtime/connectors/codex.js';
tests/runner/codex-connector-smoke.test.ts:4:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-e2e-parity.test.ts:7:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/explore-e2e-parity.test.ts:12:import { validateCompiledFlowKindPolicy } from '../../src/runtime/policy/flow-kind-policy.js';
tests/runner/explore-e2e-parity.test.ts:13:import { type RelayFn, type RelayInput, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/explore-e2e-parity.test.ts:22:// branch runs the real explore fixture through `runCompiledFlow` with the
tests/runner/explore-e2e-parity.test.ts:50:  'src/runtime/connectors/claude-code.ts',
tests/runner/explore-e2e-parity.test.ts:51:  'src/runtime/connectors/shared.ts',
tests/runner/explore-e2e-parity.test.ts:52:  'src/runtime/connectors/relay-materializer.ts',
tests/runner/explore-e2e-parity.test.ts:53:  'src/runtime/runner.ts',
tests/runner/explore-e2e-parity.test.ts:54:  'src/runtime/registries/report-schemas.ts',
tests/runner/explore-e2e-parity.test.ts:128:      'runCompiledFlow closes the explore fixture under real relayClaudeCode with 2x five-trace_entry transcripts and a byte-shape golden on explore-result.json',
tests/runner/explore-e2e-parity.test.ts:134:function deterministicRelayer(): RelayFn {
tests/runner/explore-e2e-parity.test.ts:283:      const outcome = await runCompiledFlow({
tests/runner/explore-e2e-parity.test.ts:330:      const outcome = await runCompiledFlow({
tests/runner/explore-e2e-parity.test.ts:381:        // CompiledFlowRunResult.relayResults (populated by runCompiledFlow;
tests/runner/agent-relay-roundtrip.test.ts:9:} from '../../src/runtime/connectors/claude-code.js';
tests/runner/agent-relay-roundtrip.test.ts:10:import { materializeRelay } from '../../src/runtime/connectors/relay-materializer.js';
tests/runner/agent-relay-roundtrip.test.ts:11:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/agent-relay-roundtrip.test.ts:12:import { reduce } from '../../src/runtime/reducer.js';
tests/runner/agent-relay-roundtrip.test.ts:13:import { appendAndDerive, bootstrapRun } from '../../src/runtime/runner.js';
tests/runner/agent-relay-roundtrip.test.ts:14:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/run-status-projection.test.ts:6:import { sha256Hex } from '../../src/runtime/connectors/shared.js';
tests/runner/run-status-projection.test.ts:7:import { writeManifestSnapshot } from '../../src/runtime/manifest-snapshot-writer.js';
tests/runner/run-status-projection.test.ts:8:import { projectRunStatusFromRunFolder } from '../../src/runtime/run-status-projection.js';
tests/runner/run-status-projection.test.ts:9:import { appendTraceEntry } from '../../src/runtime/trace-writer.js';
tests/runner/cli-router.test.ts:9:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/cli-router.test.ts:10:import type { RelayFn, RelayInput } from '../../src/runtime/runner.js';
tests/runner/cli-router.test.ts:52:function relayerWithBody(body: string): RelayFn {
tests/runner/cli-router.test.ts:76:function tournamentRelayer(): RelayFn {
tests/runner/cli-router.test.ts:153:function migrateCliRelayer(): RelayFn {
tests/runner/cli-router.test.ts:350:  relayer: RelayFn,
tests/runner/cli-router.test.ts:375:  relayer: RelayFn,
tests/runner/fresh-run-root.test.ts:14:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/fresh-run-root.test.ts:15:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/fresh-run-root.test.ts:16:import { manifestSnapshotPath } from '../../src/runtime/manifest-snapshot-writer.js';
tests/runner/fresh-run-root.test.ts:17:import { resultPath } from '../../src/runtime/result-writer.js';
tests/runner/fresh-run-root.test.ts:19:  type RelayFn,
tests/runner/fresh-run-root.test.ts:22:  runCompiledFlow,
tests/runner/fresh-run-root.test.ts:23:} from '../../src/runtime/runner.js';
tests/runner/fresh-run-root.test.ts:24:import { snapshotPath } from '../../src/runtime/snapshot-writer.js';
tests/runner/fresh-run-root.test.ts:25:import { traceEntryLogPath } from '../../src/runtime/trace-writer.js';
tests/runner/fresh-run-root.test.ts:54:function stubRelayer(): RelayFn {
tests/runner/fresh-run-root.test.ts:74:  await runCompiledFlow({
tests/runner/build-report-writer.test.ts:17:  runCompiledFlow,
tests/runner/build-report-writer.test.ts:19:} from '../../src/runtime/runner.js';
tests/runner/build-report-writer.test.ts:34:      'default runCompiledFlow path writes build.plan@v1 and build.result@v1 reports that parse through their schemas',
tests/runner/build-report-writer.test.ts:334:        changed_files: ['src/runtime/runner.ts'],
tests/runner/build-report-writer.test.ts:418:    const outcome = await runCompiledFlow({
tests/runner/build-report-writer.test.ts:450:    const outcome = await runCompiledFlow({
tests/runner/build-report-writer.test.ts:471:    const outcome = await runCompiledFlow({
tests/runner/build-report-writer.test.ts:492:    const outcome = await runCompiledFlow({
tests/runner/build-report-writer.test.ts:523:    const outcome = await runCompiledFlow({
tests/runner/build-report-writer.test.ts:544:    const outcome = await runCompiledFlow({
tests/runner/build-report-writer.test.ts:565:    const outcome = await runCompiledFlow({
tests/runner/build-report-writer.test.ts:586:    const outcome = await runCompiledFlow({
tests/runner/config-loader.test.ts:11:} from '../../src/runtime/config-loader.js';
tests/runner/config-loader.test.ts:12:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/config-loader.test.ts:13:import type { RelayFn, RelayInput } from '../../src/runtime/runner.js';
tests/runner/config-loader.test.ts:182:    const relayer: RelayFn = {
tests/runner/config-loader.test.ts:259:    const relayer: RelayFn = {
tests/runner/terminal-verdict-derivation.test.ts:10:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/terminal-verdict-derivation.test.ts:11:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/terminal-verdict-derivation.test.ts:12:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/terminal-verdict-derivation.test.ts:19:// runCompiledFlow:
tests/runner/terminal-verdict-derivation.test.ts:44:function fixedRelayer(verdict: string): RelayFn {
tests/runner/terminal-verdict-derivation.test.ts:57:function sequenceRelayer(verdicts: string[]): RelayFn {
tests/runner/terminal-verdict-derivation.test.ts:104:    const outcome = await runCompiledFlow({
tests/runner/terminal-verdict-derivation.test.ts:199:    const outcome = await runCompiledFlow({
tests/runner/terminal-verdict-derivation.test.ts:228:    const outcome = await runCompiledFlow({
tests/runner/terminal-verdict-derivation.test.ts:293:    const outcome = await runCompiledFlow({
tests/runner/verification-handler-direct.test.ts:25:import type { RunState, StepHandlerContext } from '../../src/runtime/step-handlers/types.js';
tests/runner/verification-handler-direct.test.ts:26:import { runVerificationStep } from '../../src/runtime/step-handlers/verification.js';
tests/runner/build-verification-exec.test.ts:16:import { type ComposeWriterFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/build-verification-exec.test.ts:165:    const outcome = await runCompiledFlow({
tests/runner/build-verification-exec.test.ts:205:    const outcome = await runCompiledFlow({
tests/runner/build-verification-exec.test.ts:239:    const outcome = await runCompiledFlow({
tests/runner/build-verification-exec.test.ts:269:    const outcome = await runCompiledFlow({
tests/runner/build-verification-exec.test.ts:313:    const lexical = await runCompiledFlow({
tests/runner/build-verification-exec.test.ts:349:    const symlinked = await runCompiledFlow({
tests/runner/build-verification-exec.test.ts:383:      const outcome = await runCompiledFlow({
tests/runner/build-verification-exec.test.ts:416:      const outcome = await runCompiledFlow({
tests/runner/build-verification-exec.test.ts:456:    const outcome = await runCompiledFlow({
tests/runner/relay-invocation-failure.test.ts:6:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/relay-invocation-failure.test.ts:7:import { type RelayFn, runCompiledFlow } from '../../src/runtime/runner.js';
tests/runner/relay-invocation-failure.test.ts:8:import { readRunTrace } from '../../src/runtime/trace-reader.js';
tests/runner/relay-invocation-failure.test.ts:40:function throwingRelayer(): RelayFn {
tests/runner/relay-invocation-failure.test.ts:64:    const outcome = await runCompiledFlow({
tests/runner/catalog-derivations.test.ts:20:} from '../../src/runtime/catalog-derivations.js';
tests/runner/catalog-derivations.test.ts:21:import type { CheckpointBriefBuilder } from '../../src/runtime/registries/checkpoint-writers/types.js';
tests/runner/catalog-derivations.test.ts:22:import type { CloseBuilder } from '../../src/runtime/registries/close-writers/types.js';
tests/runner/catalog-derivations.test.ts:23:import type { ComposeBuilder } from '../../src/runtime/registries/compose-writers/types.js';
tests/runner/catalog-derivations.test.ts:24:import type { StructuralShapeHint } from '../../src/runtime/registries/shape-hints/types.js';
tests/runner/catalog-derivations.test.ts:25:import type { VerificationBuilder } from '../../src/runtime/registries/verification-writers/types.js';
tests/runner/catalog-derivations.test.ts:461:      '../../src/runtime/registries/compose-writers/registry.js'
tests/runner/catalog-derivations.test.ts:464:      '../../src/runtime/registries/close-writers/registry.js'
tests/runner/catalog-derivations.test.ts:467:      '../../src/runtime/registries/verification-writers/registry.js'
tests/runner/catalog-derivations.test.ts:470:      '../../src/runtime/registries/checkpoint-writers/registry.js'
tests/runner/sub-run-real-recursion.test.ts:8:// the runner defaults to `runCompiledFlow` itself, and the parent's
tests/runner/sub-run-real-recursion.test.ts:25:import type { ClaudeCodeRelayInput } from '../../src/runtime/connectors/claude-code.js';
tests/runner/sub-run-real-recursion.test.ts:26:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/sub-run-real-recursion.test.ts:29:  type RelayFn,
tests/runner/sub-run-real-recursion.test.ts:30:  runCompiledFlow,
tests/runner/sub-run-real-recursion.test.ts:31:} from '../../src/runtime/runner.js';
tests/runner/sub-run-real-recursion.test.ts:45:      'real runCompiledFlow recurses into the child with a fresh RunId and a sibling run-folder, child emits its own trace, parent admits child verdict',
tests/runner/sub-run-real-recursion.test.ts:47:      'integration test of sub-run + real recursive runCompiledFlow rather than handler-isolation unit test',
tests/runner/sub-run-real-recursion.test.ts:59:function acceptingRelayer(): RelayFn {
tests/runner/sub-run-real-recursion.test.ts:125:      'real-recursion test parent — single sub-run step recurses into the child via real runCompiledFlow.',
tests/runner/sub-run-real-recursion.test.ts:144:        title: 'Sub-run — recurse into child via real runCompiledFlow',
tests/runner/sub-run-real-recursion.test.ts:178:  it('runs the child via real runCompiledFlow (no childRunner stub) and admits the child verdict', async () => {
tests/runner/sub-run-real-recursion.test.ts:192:    // KEY: NO `childRunner` field — runner defaults to `runCompiledFlow`
tests/runner/sub-run-real-recursion.test.ts:194:    const outcome = await runCompiledFlow({
tests/runner/cli-v2-runtime.test.ts:32:import type { RelayResult } from '../../src/runtime/connectors/shared.js';
tests/runner/cli-v2-runtime.test.ts:33:import type { ComposeWriterFn, RelayFn, RelayInput } from '../../src/runtime/runner.js';
tests/runner/cli-v2-runtime.test.ts:172:function relayerWithBody(body: string, connectorName = 'claude-code'): RelayFn {
tests/runner/cli-v2-runtime.test.ts:192:function generatedFixRelayer(): RelayFn {
tests/runner/cli-v2-runtime.test.ts:219:function generatedExploreRelayer(): RelayFn {
tests/runner/cli-v2-runtime.test.ts:242:function generatedMigrateRelayer(): RelayFn {
tests/runner/cli-v2-runtime.test.ts:278:function generatedSweepRelayer(): RelayFn {
tests/runner/cli-v2-runtime.test.ts:303:function tournamentRelayer(): RelayFn {
tests/runner/cli-v2-runtime.test.ts:629:    readonly relayer?: RelayFn;
tests/runner/cli-v2-runtime.test.ts:666:  options: { readonly relayer?: RelayFn } = {},
tests/runner/cli-v2-runtime.test.ts:694:  options: { readonly relayer?: RelayFn; readonly configCwd?: string } = {},
tests/runner/cli-v2-runtime.test.ts:737:    readonly relayer?: RelayFn;
tests/runner/cli-v2-runtime.test.ts:776:    readonly relayer?: RelayFn;
tests/runner/cli-v2-runtime.test.ts:817:    readonly relayer?: RelayFn;
tests/runner/cli-v2-runtime.test.ts:856:    readonly relayer?: RelayFn;
tests/runner/cli-v2-runtime.test.ts:1582:      readonly relayer: RelayFn;
tests/runner/cli-v2-runtime.test.ts:1741:      readonly relayer: RelayFn;
tests/runner/cli-v2-runtime.test.ts:2010:      readonly relayer: RelayFn;
tests/runner/cli-v2-runtime.test.ts:2150:      readonly relayer: RelayFn;
```
